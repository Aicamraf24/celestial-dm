package com.celestialdimension;

import java.util.function.Function;
import net.minecraft.core.Registry;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;

public final class ModBlocks {
    public static int COUNT = 0;

    public static final Block CELESTIAL_GRASS = reg("celestial_grass", Block::new,
            BlockBehaviour.Properties.of().strength(0.6f).sound(SoundType.GRASS));
    public static final Block CELESTIAL_DIRT = reg("celestial_dirt", Block::new,
            BlockBehaviour.Properties.of().strength(0.5f).sound(SoundType.GRAVEL));
    public static final Block CELESTIAL_STONE = reg("celestial_stone", Block::new,
            BlockBehaviour.Properties.of().strength(1.5f, 6.0f).sound(SoundType.STONE).requiresCorrectToolForDrops());
    public static final Block ANCIENT_STONE = reg("ancient_stone", Block::new,
            BlockBehaviour.Properties.of().strength(2.0f, 8.0f).sound(SoundType.DEEPSLATE).requiresCorrectToolForDrops());
    public static final Block CELESTIAL_MARBLE = reg("celestial_marble", Block::new,
            BlockBehaviour.Properties.of().strength(1.5f, 6.0f).sound(SoundType.STONE).requiresCorrectToolForDrops());
    public static final Block CELESTIAL_BRICKS = reg("celestial_bricks", Block::new,
            BlockBehaviour.Properties.of().strength(1.5f, 6.0f).sound(SoundType.STONE).requiresCorrectToolForDrops());
    public static final Block AZURE_CRYSTAL_GLASS = reg("azure_crystal_glass", Block::new,
            BlockBehaviour.Properties.of().strength(0.4f).sound(SoundType.AMETHYST).lightLevel(s -> 4));
    public static final Block LUMINOUS_CRYSTAL = reg("luminous_crystal", p -> new SparkleBlock(p, ParticleTypes.END_ROD),
            BlockBehaviour.Properties.of().strength(1.0f).sound(SoundType.AMETHYST).lightLevel(s -> 12).requiresCorrectToolForDrops());
    public static final Block SACRED_CRYSTAL = reg("sacred_crystal", p -> new SparkleBlock(p, ParticleTypes.END_ROD),
            BlockBehaviour.Properties.of().strength(2.0f, 8.0f).sound(SoundType.AMETHYST).lightLevel(s -> 15).requiresCorrectToolForDrops());
    public static final Block SOLID_CLOUD = reg("solid_cloud", Block::new,
            BlockBehaviour.Properties.of().strength(0.3f).sound(SoundType.WOOL));
    public static final Block CELESTIAL_PLANKS = reg("celestial_planks", Block::new,
            BlockBehaviour.Properties.of().strength(2.0f, 3.0f).sound(SoundType.WOOD));
    public static final Block CELESTIAL_LOG = reg("celestial_log", RotatedPillarBlock::new,
            BlockBehaviour.Properties.of().strength(2.0f).sound(SoundType.WOOD));
    public static final Block CELESTIAL_LEAVES = reg("celestial_leaves", Block::new,
            BlockBehaviour.Properties.of().strength(0.2f).sound(SoundType.GRASS));
    public static final Block LUMINOUS_FLOWER_BLOCK = reg("luminous_flower_block", p -> new SparkleBlock(p, ParticleTypes.END_ROD),
            BlockBehaviour.Properties.of().strength(0.2f).sound(SoundType.GRASS).lightLevel(s -> 8));
    public static final Block CELESTIAL_SAND = reg("celestial_sand", Block::new,
            BlockBehaviour.Properties.of().strength(0.5f).sound(SoundType.SAND));
    public static final Block TEMPLE_TILES = reg("temple_tiles", Block::new,
            BlockBehaviour.Properties.of().strength(2.0f, 8.0f).sound(SoundType.STONE).requiresCorrectToolForDrops());
    public static final Block RUIN_BRICKS = reg("ruin_bricks", Block::new,
            BlockBehaviour.Properties.of().strength(2.0f, 8.0f).sound(SoundType.STONE).requiresCorrectToolForDrops());
    public static final Block ESSENCE_ORE = reg("essence_ore", Block::new,
            BlockBehaviour.Properties.of().strength(3.0f, 3.0f).sound(SoundType.STONE).requiresCorrectToolForDrops());
    public static final Block ESSENCE_BLOCK = reg("essence_block", p -> new SparkleBlock(p, ParticleTypes.END_ROD),
            BlockBehaviour.Properties.of().strength(3.0f, 6.0f).sound(SoundType.AMETHYST).lightLevel(s -> 10).requiresCorrectToolForDrops());
    public static final Block ETHER_ORE = reg("ether_ore", Block::new,
            BlockBehaviour.Properties.of().strength(4.5f, 6.0f).sound(SoundType.STONE).requiresCorrectToolForDrops());
    public static final Block AURORA_CRYSTAL_BLOCK = reg("aurora_crystal_block", p -> new SparkleBlock(p, ParticleTypes.END_ROD),
            BlockBehaviour.Properties.of().strength(3.0f, 6.0f).sound(SoundType.AMETHYST).lightLevel(s -> 9).requiresCorrectToolForDrops());
    public static final Block PORTAL_FRAME = reg("portal_frame", Block::new,
            BlockBehaviour.Properties.of().strength(5.0f, 12.0f).sound(SoundType.STONE).lightLevel(s -> 6).requiresCorrectToolForDrops());

    public static final Block CELESTIAL_PORTAL = regNoItem("celestial_portal", CelestialPortalBlock::new,
            BlockBehaviour.Properties.of().strength(-1.0f, 3600000.0f).noCollision().noOcclusion()
                    .lightLevel(s -> 11).sound(SoundType.GLASS));

    public static final Block DRAGON_ALTAR = reg("dragon_altar", p -> new SparkleBlock(p, ParticleTypes.ENCHANT),
            BlockBehaviour.Properties.of().strength(50.0f, 1200.0f).sound(SoundType.STONE).lightLevel(s -> 12).requiresCorrectToolForDrops());

    private static Block regNoItem(String name, Function<BlockBehaviour.Properties, Block> factory, BlockBehaviour.Properties props) {
        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, CelestialDimension.id(name));
        Block block = factory.apply(props.setId(blockKey));
        Registry.register(BuiltInRegistries.BLOCK, blockKey, block);
        COUNT++;
        return block;
    }

    private static Block reg(String name, Function<BlockBehaviour.Properties, Block> factory, BlockBehaviour.Properties props) {
        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, CelestialDimension.id(name));
        Block block = factory.apply(props.setId(blockKey));
        Registry.register(BuiltInRegistries.BLOCK, blockKey, block);

        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, CelestialDimension.id(name));
        Registry.register(BuiltInRegistries.ITEM, itemKey,
                new BlockItem(block, new Item.Properties().setId(itemKey).useBlockDescriptionPrefix()));
        COUNT++;
        return block;
    }

    public static void init() {
    }

    private ModBlocks() {
    }
}
