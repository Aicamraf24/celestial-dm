package com.celestialdimension;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.item.ItemStack;
import com.celestialdimension.entity.CelestialDragon;

/** Invocacion del Dragon Celestial: clic derecho en el Altar del Dragon con un Fragmento Solar. */
public final class ModBoss {
    public static void init() {
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (!(level instanceof ServerLevel sl)) {
                return InteractionResult.PASS;
            }
            BlockPos pos = hit.getBlockPos();
            if (!sl.getBlockState(pos).is(ModBlocks.DRAGON_ALTAR)) {
                return InteractionResult.PASS;
            }
            ItemStack stack = player.getItemInHand(hand);
            if (!stack.is(ModItems.SOLAR_FRAGMENT)) {
                player.displayClientMessage(Component.translatable("message.celestial_dimension.altar_needs_fragment"), true);
                return InteractionResult.PASS;
            }
            boolean exists = !sl.getEntitiesOfClass(CelestialDragon.class, player.getBoundingBox().inflate(128.0)).isEmpty();
            if (exists) {
                player.displayClientMessage(Component.translatable("message.celestial_dimension.dragon_exists"), true);
                return InteractionResult.SUCCESS;
            }
            CelestialDragon dragon = ModEntities.CELESTIAL_DRAGON.create(sl, EntitySpawnReason.MOB_SUMMONED);
            if (dragon == null) {
                return InteractionResult.PASS;
            }
            dragon.setPos(pos.getX() + 0.5, pos.getY() + 6.0, pos.getZ() + 0.5);
            sl.addFreshEntity(dragon);
            sl.sendParticles(ParticleTypes.FIREWORK, pos.getX() + 0.5, pos.getY() + 3.0, pos.getZ() + 0.5, 100, 3.0, 3.0, 3.0, 0.3);
            if (!player.isCreative()) {
                stack.shrink(1);
            }
            return InteractionResult.SUCCESS;
        });
    }

    private ModBoss() {
    }
}
