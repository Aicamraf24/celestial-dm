package com.celestialdimension;

import com.celestialdimension.entity.CelestialDragon;
import com.celestialdimension.entity.CelestialGriffin;
import com.celestialdimension.entity.CelestialHarpy;
import com.celestialdimension.entity.CloudSpirit;
import com.celestialdimension.entity.CrystalGolem;
import com.celestialdimension.entity.GuardianAngel;
import com.celestialdimension.entity.LuminousDeer;
import com.celestialdimension.entity.SkySerpent;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;

public final class ModEntities {
    public static final EntityType<GuardianAngel> GUARDIAN_ANGEL = reg("guardian_angel",
            EntityType.Builder.<GuardianAngel>of(GuardianAngel::new, MobCategory.CREATURE).sized(0.8f, 2.1f),
            GuardianAngel.attrs());
    public static final EntityType<CelestialGriffin> CELESTIAL_GRIFFIN = reg("celestial_griffin",
            EntityType.Builder.<CelestialGriffin>of(CelestialGriffin::new, MobCategory.CREATURE).sized(1.4f, 1.4f),
            CelestialGriffin.attrs());
    public static final EntityType<CelestialDragon> CELESTIAL_DRAGON = reg("celestial_dragon",
            EntityType.Builder.<CelestialDragon>of(CelestialDragon::new, MobCategory.MONSTER).sized(3.0f, 3.0f).fireImmune(),
            CelestialDragon.attrs());
    public static final EntityType<CloudSpirit> CLOUD_SPIRIT = reg("cloud_spirit",
            EntityType.Builder.<CloudSpirit>of(CloudSpirit::new, MobCategory.CREATURE).sized(0.6f, 1.0f),
            CloudSpirit.attrs());
    public static final EntityType<CrystalGolem> CRYSTAL_GOLEM = reg("crystal_golem",
            EntityType.Builder.<CrystalGolem>of(CrystalGolem::new, MobCategory.MONSTER).sized(1.4f, 2.8f),
            CrystalGolem.attrs());
    public static final EntityType<CelestialHarpy> CELESTIAL_HARPY = reg("celestial_harpy",
            EntityType.Builder.<CelestialHarpy>of(CelestialHarpy::new, MobCategory.MONSTER).sized(0.7f, 1.4f),
            CelestialHarpy.attrs());
    public static final EntityType<LuminousDeer> LUMINOUS_DEER = reg("luminous_deer",
            EntityType.Builder.<LuminousDeer>of(LuminousDeer::new, MobCategory.CREATURE).sized(0.9f, 1.9f),
            LuminousDeer.attrs());
    public static final EntityType<SkySerpent> SKY_SERPENT = reg("sky_serpent",
            EntityType.Builder.<SkySerpent>of(SkySerpent::new, MobCategory.MONSTER).sized(0.8f, 0.8f),
            SkySerpent.attrs());

    private static <T extends LivingEntity> EntityType<T> reg(String name, EntityType.Builder<T> builder,
                                                              AttributeSupplier.Builder attrs) {
        ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, CelestialDimension.id(name));
        EntityType<T> type = Registry.register(BuiltInRegistries.ENTITY_TYPE, key, builder.build(key));
        FabricDefaultAttributeRegistry.register(type, attrs);
        return type;
    }

    public static void init() {
    }

    private ModEntities() {
    }
}
