package com.celestialdimension.client;

import java.util.Map;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/** Modelo generico: anima por convencion de nombres (head, jaw, wing_*, leg_*, arm_*, tail*, seg*). */
public class CelestialModel extends EntityModel<CelestialRenderState> {
    private final Map<String, ModelPart> parts;

    public CelestialModel(ModelPart root, Map<String, ModelPart> parts) {
        super(root);
        this.parts = parts;
    }

    private ModelPart g(String n) {
        return parts.get(n);
    }

    @Override
    public void setupAnim(CelestialRenderState s) {
        super.setupAnim(s);
        float age = s.ageInTicks;
        float pos = s.walkAnimationPos;
        float spd = Math.min(1.0f, s.walkAnimationSpeed);

        ModelPart head = g("head");
        if (head != null) {
            head.yRot = s.yRot * Mth.DEG_TO_RAD;
            head.xRot = s.xRot * Mth.DEG_TO_RAD;
        }
        ModelPart jaw = g("jaw");
        if (jaw != null) {
            jaw.xRot = s.attack * 0.7f + (s.flying ? 0.0f : 0.0f);
        }

        for (int i = 0; i < 4; i++) {
            ModelPart leg = g("leg_" + i);
            if (leg != null) {
                float ph = (i == 0 || i == 3) ? 0.0f : Mth.PI;
                leg.xRot = s.flying ? 0.7f : Mth.cos(pos * 0.6662f + ph) * 1.4f * spd;
            }
        }
        ModelPart ll = g("leg_l");
        ModelPart lr = g("leg_r");
        if (ll != null) ll.xRot = s.flying ? 0.5f : Mth.cos(pos * 0.6662f + Mth.PI) * 1.2f * spd;
        if (lr != null) lr.xRot = s.flying ? 0.5f : Mth.cos(pos * 0.6662f) * 1.2f * spd;

        ModelPart al = g("arm_l");
        ModelPart ar = g("arm_r");
        if (al != null) al.xRot = Mth.cos(pos * 0.6662f) * 1.0f * spd - s.attack * 1.6f;
        if (ar != null) ar.xRot = Mth.cos(pos * 0.6662f + Mth.PI) * 1.0f * spd - s.attack * 1.6f;

        float flap = s.flying ? Mth.sin(age * 0.9f) * 0.8f : Mth.sin(age * 0.12f) * 0.08f;
        float tip = s.flying ? Mth.sin(age * 0.9f - 0.8f) * 0.5f : 0.0f;
        if (g("wing_l") != null) g("wing_l").zRot = -flap;
        if (g("wing_r") != null) g("wing_r").zRot = flap;
        if (g("wing_l2") != null) g("wing_l2").zRot = -tip;
        if (g("wing_r2") != null) g("wing_r2").zRot = tip;

        String[] tails = {"tail", "tail2", "tail3", "tail4"};
        for (int i = 0; i < tails.length; i++) {
            ModelPart t = g(tails[i]);
            if (t != null) {
                t.yRot = Mth.sin(age * 0.08f + i * 0.7f) * 0.22f;
            }
        }
        for (int i = 0; i < 6; i++) {
            ModelPart sg = g("seg" + i);
            if (sg != null) {
                sg.yRot = Mth.sin(age * 0.18f - i * 0.7f) * 0.35f;
            }
        }
    }
}
