package com.celestialdimension.client;

import com.celestialdimension.CelestialDimension;
import com.celestialdimension.entity.CelestialCreature;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Mob;

public class CelestialRenderer<T extends Mob> extends MobRenderer<T, CelestialRenderState, CelestialModel> {
    private final Identifier texture;
    private final float scale;

    public CelestialRenderer(EntityRendererProvider.Context ctx, String name, float shadow, float scale) {
        super(ctx, build(ctx, name), shadow);
        this.texture = Identifier.fromNamespaceAndPath(CelestialDimension.MOD_ID, "textures/entity/" + name + ".png");
        this.scale = scale;
    }

    private static CelestialModel build(EntityRendererProvider.Context ctx, String name) {
        ModelPart root = ctx.bakeLayer(CelestialDimensionClient.layer(name));
        return new CelestialModel(root, CreatureModels.parts(name, root));
    }

    @Override
    public CelestialRenderState createRenderState() {
        return new CelestialRenderState();
    }

    @Override
    public Identifier getTextureLocation(CelestialRenderState state) {
        return texture;
    }

    @Override
    public void extractRenderState(T entity, CelestialRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.attack = entity.getAttackAnim(partialTick);
        state.flying = entity instanceof CelestialCreature c && c.isFlyingNow();
    }

    @Override
    protected void scale(CelestialRenderState state, PoseStack poseStack) {
        poseStack.scale(scale, scale, scale);
    }
}
