package com.celestialdimension.client;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Generado por tools_stage5a.py: geometria de las criaturas (las texturas PNG se pintan con el mismo diseno). */
public final class CreatureModels {
    private static LayerDefinition layer_guardian_angel() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F), PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(24, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F), PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition p_halo = p_head.addOrReplaceChild("halo", CubeListBuilder.create().texOffs(56, 0).addBox(-3.0F, -10.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition p_leg_l = root.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(80, 0).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F), PartPose.offset(2.0F, 12.0F, 0.0F));
        PartDefinition p_leg_r = root.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(96, 0).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F), PartPose.offset(-2.0F, 12.0F, 0.0F));
        PartDefinition p_arm_l = root.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(112, 0).addBox(-1.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F), PartPose.offset(5.0F, 2.0F, 0.0F));
        PartDefinition p_arm_r = root.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(0, 16).addBox(-3.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F), PartPose.offset(-5.0F, 2.0F, 0.0F));
        PartDefinition p_wing_l = root.addOrReplaceChild("wing_l", CubeListBuilder.create().texOffs(16, 16).addBox(0.0F, -12.0F, 0.0F, 14.0F, 18.0F, 1.0F), PartPose.offset(3.0F, 2.0F, 2.0F));
        PartDefinition p_wing_l2 = p_wing_l.addOrReplaceChild("wing_l2", CubeListBuilder.create().texOffs(46, 16).addBox(0.0F, -10.0F, 0.0F, 10.0F, 14.0F, 1.0F), PartPose.offset(14.0F, 0.0F, 0.0F));
        PartDefinition p_wing_r = root.addOrReplaceChild("wing_r", CubeListBuilder.create().texOffs(68, 16).addBox(-14.0F, -12.0F, 0.0F, 14.0F, 18.0F, 1.0F), PartPose.offset(-3.0F, 2.0F, 2.0F));
        PartDefinition p_wing_r2 = p_wing_r.addOrReplaceChild("wing_r2", CubeListBuilder.create().texOffs(98, 16).addBox(-10.0F, -10.0F, 0.0F, 10.0F, 14.0F, 1.0F), PartPose.offset(-14.0F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 128, 64);
    }

    private static LayerDefinition layer_celestial_griffin() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-5.0F, -5.0F, -9.0F, 10.0F, 10.0F, 18.0F), PartPose.offset(0.0F, 14.0F, 0.0F));
        PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(56, 0).addBox(-3.0F, -6.0F, -6.0F, 6.0F, 6.0F, 6.0F), PartPose.offset(0.0F, 10.0F, -9.0F));
        PartDefinition p_beak = p_head.addOrReplaceChild("beak", CubeListBuilder.create().texOffs(80, 0).addBox(-1.0F, -3.0F, -9.0F, 2.0F, 3.0F, 3.0F), PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition p_leg_0 = root.addOrReplaceChild("leg_0", CubeListBuilder.create().texOffs(90, 0).addBox(-1.0F, 0.0F, -1.0F, 3.0F, 5.0F, 3.0F), PartPose.offset(-4.0F, 19.0F, -6.0F));
        PartDefinition p_leg_1 = root.addOrReplaceChild("leg_1", CubeListBuilder.create().texOffs(102, 0).addBox(-1.0F, 0.0F, -1.0F, 3.0F, 5.0F, 3.0F), PartPose.offset(4.0F, 19.0F, -6.0F));
        PartDefinition p_leg_2 = root.addOrReplaceChild("leg_2", CubeListBuilder.create().texOffs(0, 28).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 5.0F, 4.0F), PartPose.offset(-4.0F, 19.0F, 7.0F));
        PartDefinition p_leg_3 = root.addOrReplaceChild("leg_3", CubeListBuilder.create().texOffs(16, 28).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 5.0F, 4.0F), PartPose.offset(4.0F, 19.0F, 7.0F));
        PartDefinition p_wing_l = root.addOrReplaceChild("wing_l", CubeListBuilder.create().texOffs(32, 28).addBox(0.0F, -1.0F, -3.0F, 14.0F, 1.0F, 9.0F), PartPose.offset(4.0F, 9.0F, -3.0F));
        PartDefinition p_wing_l2 = p_wing_l.addOrReplaceChild("wing_l2", CubeListBuilder.create().texOffs(78, 28).addBox(0.0F, -1.0F, -2.0F, 10.0F, 1.0F, 7.0F), PartPose.offset(14.0F, 0.0F, 0.0F));
        PartDefinition p_wing_r = root.addOrReplaceChild("wing_r", CubeListBuilder.create().texOffs(0, 38).addBox(-14.0F, -1.0F, -3.0F, 14.0F, 1.0F, 9.0F), PartPose.offset(-4.0F, 9.0F, -3.0F));
        PartDefinition p_wing_r2 = p_wing_r.addOrReplaceChild("wing_r2", CubeListBuilder.create().texOffs(46, 38).addBox(-10.0F, -1.0F, -2.0F, 10.0F, 1.0F, 7.0F), PartPose.offset(-14.0F, 0.0F, 0.0F));
        PartDefinition p_tail = root.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(80, 38).addBox(-1.0F, -1.0F, 0.0F, 3.0F, 3.0F, 8.0F), PartPose.offset(0.0F, 12.0F, 9.0F));
        PartDefinition p_tail2 = p_tail.addOrReplaceChild("tail2", CubeListBuilder.create().texOffs(102, 38).addBox(-2.0F, -2.0F, 0.0F, 4.0F, 4.0F, 3.0F), PartPose.offset(0.0F, 0.0F, 8.0F));
        return LayerDefinition.create(mesh, 128, 64);
    }

    private static LayerDefinition layer_celestial_dragon() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-6.0F, -6.0F, -12.0F, 12.0F, 12.0F, 24.0F), PartPose.offset(0.0F, 12.0F, 0.0F));
        PartDefinition p_neck = root.addOrReplaceChild("neck", CubeListBuilder.create().texOffs(72, 0).addBox(-3.0F, -3.0F, -8.0F, 6.0F, 6.0F, 8.0F), PartPose.offsetAndRotation(0.0F, 9.0F, -12.0F, -0.5F, 0.0F, 0.0F));
        PartDefinition p_head = p_neck.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 36).addBox(-4.0F, -3.0F, -8.0F, 8.0F, 6.0F, 8.0F), PartPose.offset(0.0F, 0.0F, -8.0F));
        PartDefinition p_jaw = p_head.addOrReplaceChild("jaw", CubeListBuilder.create().texOffs(32, 36).addBox(-3.0F, 0.0F, -7.0F, 6.0F, 2.0F, 7.0F), PartPose.offset(0.0F, 3.0F, 0.0F));
        PartDefinition p_horn_l = p_head.addOrReplaceChild("horn_l", CubeListBuilder.create().texOffs(58, 36).addBox(0.0F, -6.0F, -1.0F, 2.0F, 6.0F, 2.0F), PartPose.offset(3.0F, -3.0F, -2.0F));
        PartDefinition p_horn_r = p_head.addOrReplaceChild("horn_r", CubeListBuilder.create().texOffs(66, 36).addBox(-2.0F, -6.0F, -1.0F, 2.0F, 6.0F, 2.0F), PartPose.offset(-3.0F, -3.0F, -2.0F));
        PartDefinition p_leg_0 = root.addOrReplaceChild("leg_0", CubeListBuilder.create().texOffs(74, 36).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 8.0F, 4.0F), PartPose.offset(-5.0F, 16.0F, -8.0F));
        PartDefinition p_leg_1 = root.addOrReplaceChild("leg_1", CubeListBuilder.create().texOffs(90, 36).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 8.0F, 4.0F), PartPose.offset(5.0F, 16.0F, -8.0F));
        PartDefinition p_leg_2 = root.addOrReplaceChild("leg_2", CubeListBuilder.create().texOffs(106, 36).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 8.0F, 4.0F), PartPose.offset(-5.0F, 16.0F, 8.0F));
        PartDefinition p_leg_3 = root.addOrReplaceChild("leg_3", CubeListBuilder.create().texOffs(0, 50).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 8.0F, 4.0F), PartPose.offset(5.0F, 16.0F, 8.0F));
        PartDefinition p_wing_l = root.addOrReplaceChild("wing_l", CubeListBuilder.create().texOffs(16, 50).addBox(0.0F, -1.0F, -3.0F, 20.0F, 1.0F, 14.0F), PartPose.offset(6.0F, 8.0F, -6.0F));
        PartDefinition p_wing_l2 = p_wing_l.addOrReplaceChild("wing_l2", CubeListBuilder.create().texOffs(0, 65).addBox(0.0F, -1.0F, -2.0F, 16.0F, 1.0F, 10.0F), PartPose.offset(20.0F, 0.0F, 0.0F));
        PartDefinition p_wing_r = root.addOrReplaceChild("wing_r", CubeListBuilder.create().texOffs(52, 65).addBox(-20.0F, -1.0F, -3.0F, 20.0F, 1.0F, 14.0F), PartPose.offset(-6.0F, 8.0F, -6.0F));
        PartDefinition p_wing_r2 = p_wing_r.addOrReplaceChild("wing_r2", CubeListBuilder.create().texOffs(0, 80).addBox(-16.0F, -1.0F, -2.0F, 16.0F, 1.0F, 10.0F), PartPose.offset(-20.0F, 0.0F, 0.0F));
        PartDefinition p_tail = root.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(52, 80).addBox(-4.0F, -3.0F, 0.0F, 8.0F, 6.0F, 10.0F), PartPose.offset(0.0F, 12.0F, 12.0F));
        PartDefinition p_tail2 = p_tail.addOrReplaceChild("tail2", CubeListBuilder.create().texOffs(88, 80).addBox(-3.0F, -2.0F, 0.0F, 6.0F, 4.0F, 10.0F), PartPose.offset(0.0F, 0.0F, 10.0F));
        PartDefinition p_tail3 = p_tail2.addOrReplaceChild("tail3", CubeListBuilder.create().texOffs(0, 96).addBox(-2.0F, -1.0F, 0.0F, 4.0F, 3.0F, 10.0F), PartPose.offset(0.0F, 0.0F, 10.0F));
        PartDefinition p_tail4 = p_tail3.addOrReplaceChild("tail4", CubeListBuilder.create().texOffs(28, 96).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 8.0F), PartPose.offset(0.0F, 0.0F, 10.0F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    private static LayerDefinition layer_cloud_spirit() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -3.0F, -3.0F, 6.0F, 6.0F, 6.0F), PartPose.offset(0.0F, 17.0F, 0.0F));
        PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(24, 0).addBox(-3.0F, -6.0F, -3.0F, 6.0F, 6.0F, 6.0F), PartPose.offset(0.0F, 14.0F, 0.0F));
        PartDefinition p_tail = root.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(48, 0).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 4.0F, 4.0F), PartPose.offset(0.0F, 20.0F, 0.0F));
        PartDefinition p_tail2 = p_tail.addOrReplaceChild("tail2", CubeListBuilder.create().texOffs(0, 12).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F), PartPose.offset(0.0F, 4.0F, 0.0F));
        PartDefinition p_arm_l = root.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(8, 12).addBox(0.0F, -1.0F, -1.0F, 3.0F, 2.0F, 2.0F), PartPose.offset(3.0F, 16.0F, 0.0F));
        PartDefinition p_arm_r = root.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(18, 12).addBox(-3.0F, -1.0F, -1.0F, 3.0F, 2.0F, 2.0F), PartPose.offset(-3.0F, 16.0F, 0.0F));
        PartDefinition p_wing_l = root.addOrReplaceChild("wing_l", CubeListBuilder.create().texOffs(28, 12).addBox(0.0F, -3.0F, 0.0F, 6.0F, 6.0F, 1.0F), PartPose.offset(2.0F, 16.0F, 3.0F));
        PartDefinition p_wing_r = root.addOrReplaceChild("wing_r", CubeListBuilder.create().texOffs(42, 12).addBox(-6.0F, -3.0F, 0.0F, 6.0F, 6.0F, 1.0F), PartPose.offset(-2.0F, 16.0F, 3.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    private static LayerDefinition layer_crystal_golem() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-8.0F, -12.0F, -5.0F, 16.0F, 24.0F, 10.0F), PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(52, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F), PartPose.offset(0.0F, -12.0F, 0.0F));
        PartDefinition p_leg_l = root.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(84, 0).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 12.0F, 6.0F), PartPose.offset(5.0F, 12.0F, 0.0F));
        PartDefinition p_leg_r = root.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(0, 34).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 12.0F, 6.0F), PartPose.offset(-5.0F, 12.0F, 0.0F));
        PartDefinition p_arm_l = root.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(24, 34).addBox(-3.0F, -2.0F, -3.0F, 6.0F, 22.0F, 6.0F), PartPose.offset(11.0F, -8.0F, 0.0F));
        PartDefinition p_arm_r = root.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(48, 34).addBox(-3.0F, -2.0F, -3.0F, 6.0F, 22.0F, 6.0F), PartPose.offset(-11.0F, -8.0F, 0.0F));
        PartDefinition p_crystal_1 = p_body.addOrReplaceChild("crystal_1", CubeListBuilder.create().texOffs(72, 34).addBox(-6.0F, -12.0F, 5.0F, 4.0F, 12.0F, 4.0F), PartPose.offset(0.0F, -8.0F, 0.0F));
        PartDefinition p_crystal_2 = p_body.addOrReplaceChild("crystal_2", CubeListBuilder.create().texOffs(88, 34).addBox(2.0F, -16.0F, 5.0F, 4.0F, 16.0F, 4.0F), PartPose.offset(0.0F, -8.0F, 0.0F));
        PartDefinition p_crystal_3 = p_head.addOrReplaceChild("crystal_3", CubeListBuilder.create().texOffs(104, 34).addBox(-1.0F, -5.0F, -1.0F, 2.0F, 5.0F, 2.0F), PartPose.offset(0.0F, -8.0F, 0.0F));
        return LayerDefinition.create(mesh, 128, 64);
    }

    private static LayerDefinition layer_celestial_harpy() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, 0.0F, -2.0F, 6.0F, 9.0F, 4.0F), PartPose.offset(0.0F, 8.0F, 0.0F));
        PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(20, 0).addBox(-3.0F, -6.0F, -3.0F, 6.0F, 6.0F, 6.0F), PartPose.offset(0.0F, 8.0F, 0.0F));
        PartDefinition p_beak = p_head.addOrReplaceChild("beak", CubeListBuilder.create().texOffs(44, 0).addBox(-1.0F, -3.0F, -5.0F, 2.0F, 2.0F, 2.0F), PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition p_crest = p_head.addOrReplaceChild("crest", CubeListBuilder.create().texOffs(52, 0).addBox(-1.0F, -8.0F, -2.0F, 2.0F, 2.0F, 4.0F), PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition p_leg_l = root.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(64, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 7.0F, 2.0F), PartPose.offset(2.0F, 17.0F, 0.0F));
        PartDefinition p_leg_r = root.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(72, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 7.0F, 2.0F), PartPose.offset(-2.0F, 17.0F, 0.0F));
        PartDefinition p_wing_l = root.addOrReplaceChild("wing_l", CubeListBuilder.create().texOffs(80, 0).addBox(0.0F, 0.0F, -2.0F, 16.0F, 1.0F, 8.0F), PartPose.offset(3.0F, 9.0F, 2.0F));
        PartDefinition p_wing_l2 = p_wing_l.addOrReplaceChild("wing_l2", CubeListBuilder.create().texOffs(0, 13).addBox(0.0F, 0.0F, -2.0F, 12.0F, 1.0F, 6.0F), PartPose.offset(16.0F, 0.0F, 0.0F));
        PartDefinition p_wing_r = root.addOrReplaceChild("wing_r", CubeListBuilder.create().texOffs(36, 13).addBox(-16.0F, 0.0F, -2.0F, 16.0F, 1.0F, 8.0F), PartPose.offset(-3.0F, 9.0F, 2.0F));
        PartDefinition p_wing_r2 = p_wing_r.addOrReplaceChild("wing_r2", CubeListBuilder.create().texOffs(84, 13).addBox(-12.0F, 0.0F, -2.0F, 12.0F, 1.0F, 6.0F), PartPose.offset(-16.0F, 0.0F, 0.0F));
        PartDefinition p_tail = root.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(0, 22).addBox(-2.0F, 0.0F, 0.0F, 4.0F, 1.0F, 8.0F), PartPose.offset(0.0F, 16.0F, 2.0F));
        return LayerDefinition.create(mesh, 128, 64);
    }

    private static LayerDefinition layer_luminous_deer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -4.0F, -8.0F, 6.0F, 8.0F, 16.0F), PartPose.offset(0.0F, 12.0F, 0.0F));
        PartDefinition p_neck = root.addOrReplaceChild("neck", CubeListBuilder.create().texOffs(44, 0).addBox(-2.0F, -10.0F, -3.0F, 4.0F, 10.0F, 4.0F), PartPose.offset(0.0F, 10.0F, -6.0F));
        PartDefinition p_head = p_neck.addOrReplaceChild("head", CubeListBuilder.create().texOffs(60, 0).addBox(-2.0F, -4.0F, -4.0F, 4.0F, 4.0F, 6.0F), PartPose.offset(0.0F, -10.0F, -1.0F));
        PartDefinition p_antler_l = p_head.addOrReplaceChild("antler_l", CubeListBuilder.create().texOffs(80, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 1.0F), PartPose.offset(1.0F, -4.0F, -1.0F));
        PartDefinition p_antler_l2 = p_antler_l.addOrReplaceChild("antler_l2", CubeListBuilder.create().texOffs(84, 0).addBox(0.0F, -3.0F, 0.0F, 3.0F, 1.0F, 1.0F), PartPose.offset(0.0F, -4.0F, 0.0F));
        PartDefinition p_antler_r = p_head.addOrReplaceChild("antler_r", CubeListBuilder.create().texOffs(92, 0).addBox(-1.0F, -6.0F, 0.0F, 1.0F, 6.0F, 1.0F), PartPose.offset(-1.0F, -4.0F, -1.0F));
        PartDefinition p_antler_r2 = p_antler_r.addOrReplaceChild("antler_r2", CubeListBuilder.create().texOffs(96, 0).addBox(-3.0F, -3.0F, 0.0F, 3.0F, 1.0F, 1.0F), PartPose.offset(0.0F, -4.0F, 0.0F));
        PartDefinition p_leg_0 = root.addOrReplaceChild("leg_0", CubeListBuilder.create().texOffs(104, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F), PartPose.offset(-2.0F, 16.0F, -6.0F));
        PartDefinition p_leg_1 = root.addOrReplaceChild("leg_1", CubeListBuilder.create().texOffs(112, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F), PartPose.offset(2.0F, 16.0F, -6.0F));
        PartDefinition p_leg_2 = root.addOrReplaceChild("leg_2", CubeListBuilder.create().texOffs(120, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F), PartPose.offset(-2.0F, 16.0F, 6.0F));
        PartDefinition p_leg_3 = root.addOrReplaceChild("leg_3", CubeListBuilder.create().texOffs(0, 24).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F), PartPose.offset(2.0F, 16.0F, 6.0F));
        PartDefinition p_tail = root.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(8, 24).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 3.0F), PartPose.offset(0.0F, 9.0F, 8.0F));
        return LayerDefinition.create(mesh, 128, 64);
    }

    private static LayerDefinition layer_sky_serpent() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -3.0F, -8.0F, 6.0F, 6.0F, 8.0F), PartPose.offset(0.0F, 16.0F, -14.0F));
        PartDefinition p_jaw = p_head.addOrReplaceChild("jaw", CubeListBuilder.create().texOffs(28, 0).addBox(-2.0F, 0.0F, -7.0F, 4.0F, 1.0F, 7.0F), PartPose.offset(0.0F, 3.0F, 0.0F));
        PartDefinition p_seg0 = root.addOrReplaceChild("seg0", CubeListBuilder.create().texOffs(50, 0).addBox(-3.0F, -3.0F, 0.0F, 6.0F, 6.0F, 8.0F), PartPose.offset(0.0F, 16.0F, -14.0F));
        PartDefinition p_seg1 = p_seg0.addOrReplaceChild("seg1", CubeListBuilder.create().texOffs(78, 0).addBox(-3.0F, -3.0F, 0.0F, 6.0F, 6.0F, 8.0F), PartPose.offset(0.0F, 0.0F, 8.0F));
        PartDefinition p_seg2 = p_seg1.addOrReplaceChild("seg2", CubeListBuilder.create().texOffs(0, 14).addBox(-3.0F, -3.0F, 0.0F, 6.0F, 6.0F, 8.0F), PartPose.offset(0.0F, 0.0F, 8.0F));
        PartDefinition p_seg3 = p_seg2.addOrReplaceChild("seg3", CubeListBuilder.create().texOffs(28, 14).addBox(-2.0F, -2.0F, 0.0F, 4.0F, 4.0F, 8.0F), PartPose.offset(0.0F, 0.0F, 8.0F));
        PartDefinition p_seg4 = p_seg3.addOrReplaceChild("seg4", CubeListBuilder.create().texOffs(52, 14).addBox(-2.0F, -2.0F, 0.0F, 4.0F, 4.0F, 8.0F), PartPose.offset(0.0F, 0.0F, 8.0F));
        PartDefinition p_seg5 = p_seg4.addOrReplaceChild("seg5", CubeListBuilder.create().texOffs(76, 14).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 8.0F), PartPose.offset(0.0F, 0.0F, 8.0F));
        PartDefinition p_wing_l = root.addOrReplaceChild("wing_l", CubeListBuilder.create().texOffs(0, 28).addBox(0.0F, -1.0F, -2.0F, 12.0F, 1.0F, 6.0F), PartPose.offset(3.0F, 14.0F, -10.0F));
        PartDefinition p_wing_r = root.addOrReplaceChild("wing_r", CubeListBuilder.create().texOffs(36, 28).addBox(-12.0F, -1.0F, -2.0F, 12.0F, 1.0F, 6.0F), PartPose.offset(-3.0F, 14.0F, -10.0F));
        return LayerDefinition.create(mesh, 128, 64);
    }

    private static Map<String, ModelPart> parts_guardian_angel(ModelPart root) {
        Map<String, ModelPart> m = new HashMap<>();
        m.put("body", root.getChild("body"));
        m.put("head", root.getChild("head"));
        m.put("halo", root.getChild("head").getChild("halo"));
        m.put("leg_l", root.getChild("leg_l"));
        m.put("leg_r", root.getChild("leg_r"));
        m.put("arm_l", root.getChild("arm_l"));
        m.put("arm_r", root.getChild("arm_r"));
        m.put("wing_l", root.getChild("wing_l"));
        m.put("wing_l2", root.getChild("wing_l").getChild("wing_l2"));
        m.put("wing_r", root.getChild("wing_r"));
        m.put("wing_r2", root.getChild("wing_r").getChild("wing_r2"));
        return m;
    }

    private static Map<String, ModelPart> parts_celestial_griffin(ModelPart root) {
        Map<String, ModelPart> m = new HashMap<>();
        m.put("body", root.getChild("body"));
        m.put("head", root.getChild("head"));
        m.put("beak", root.getChild("head").getChild("beak"));
        m.put("leg_0", root.getChild("leg_0"));
        m.put("leg_1", root.getChild("leg_1"));
        m.put("leg_2", root.getChild("leg_2"));
        m.put("leg_3", root.getChild("leg_3"));
        m.put("wing_l", root.getChild("wing_l"));
        m.put("wing_l2", root.getChild("wing_l").getChild("wing_l2"));
        m.put("wing_r", root.getChild("wing_r"));
        m.put("wing_r2", root.getChild("wing_r").getChild("wing_r2"));
        m.put("tail", root.getChild("tail"));
        m.put("tail2", root.getChild("tail").getChild("tail2"));
        return m;
    }

    private static Map<String, ModelPart> parts_celestial_dragon(ModelPart root) {
        Map<String, ModelPart> m = new HashMap<>();
        m.put("body", root.getChild("body"));
        m.put("neck", root.getChild("neck"));
        m.put("head", root.getChild("neck").getChild("head"));
        m.put("jaw", root.getChild("neck").getChild("head").getChild("jaw"));
        m.put("horn_l", root.getChild("neck").getChild("head").getChild("horn_l"));
        m.put("horn_r", root.getChild("neck").getChild("head").getChild("horn_r"));
        m.put("leg_0", root.getChild("leg_0"));
        m.put("leg_1", root.getChild("leg_1"));
        m.put("leg_2", root.getChild("leg_2"));
        m.put("leg_3", root.getChild("leg_3"));
        m.put("wing_l", root.getChild("wing_l"));
        m.put("wing_l2", root.getChild("wing_l").getChild("wing_l2"));
        m.put("wing_r", root.getChild("wing_r"));
        m.put("wing_r2", root.getChild("wing_r").getChild("wing_r2"));
        m.put("tail", root.getChild("tail"));
        m.put("tail2", root.getChild("tail").getChild("tail2"));
        m.put("tail3", root.getChild("tail").getChild("tail2").getChild("tail3"));
        m.put("tail4", root.getChild("tail").getChild("tail2").getChild("tail3").getChild("tail4"));
        return m;
    }

    private static Map<String, ModelPart> parts_cloud_spirit(ModelPart root) {
        Map<String, ModelPart> m = new HashMap<>();
        m.put("body", root.getChild("body"));
        m.put("head", root.getChild("head"));
        m.put("tail", root.getChild("tail"));
        m.put("tail2", root.getChild("tail").getChild("tail2"));
        m.put("arm_l", root.getChild("arm_l"));
        m.put("arm_r", root.getChild("arm_r"));
        m.put("wing_l", root.getChild("wing_l"));
        m.put("wing_r", root.getChild("wing_r"));
        return m;
    }

    private static Map<String, ModelPart> parts_crystal_golem(ModelPart root) {
        Map<String, ModelPart> m = new HashMap<>();
        m.put("body", root.getChild("body"));
        m.put("head", root.getChild("head"));
        m.put("leg_l", root.getChild("leg_l"));
        m.put("leg_r", root.getChild("leg_r"));
        m.put("arm_l", root.getChild("arm_l"));
        m.put("arm_r", root.getChild("arm_r"));
        m.put("crystal_1", root.getChild("body").getChild("crystal_1"));
        m.put("crystal_2", root.getChild("body").getChild("crystal_2"));
        m.put("crystal_3", root.getChild("head").getChild("crystal_3"));
        return m;
    }

    private static Map<String, ModelPart> parts_celestial_harpy(ModelPart root) {
        Map<String, ModelPart> m = new HashMap<>();
        m.put("body", root.getChild("body"));
        m.put("head", root.getChild("head"));
        m.put("beak", root.getChild("head").getChild("beak"));
        m.put("crest", root.getChild("head").getChild("crest"));
        m.put("leg_l", root.getChild("leg_l"));
        m.put("leg_r", root.getChild("leg_r"));
        m.put("wing_l", root.getChild("wing_l"));
        m.put("wing_l2", root.getChild("wing_l").getChild("wing_l2"));
        m.put("wing_r", root.getChild("wing_r"));
        m.put("wing_r2", root.getChild("wing_r").getChild("wing_r2"));
        m.put("tail", root.getChild("tail"));
        return m;
    }

    private static Map<String, ModelPart> parts_luminous_deer(ModelPart root) {
        Map<String, ModelPart> m = new HashMap<>();
        m.put("body", root.getChild("body"));
        m.put("neck", root.getChild("neck"));
        m.put("head", root.getChild("neck").getChild("head"));
        m.put("antler_l", root.getChild("neck").getChild("head").getChild("antler_l"));
        m.put("antler_l2", root.getChild("neck").getChild("head").getChild("antler_l").getChild("antler_l2"));
        m.put("antler_r", root.getChild("neck").getChild("head").getChild("antler_r"));
        m.put("antler_r2", root.getChild("neck").getChild("head").getChild("antler_r").getChild("antler_r2"));
        m.put("leg_0", root.getChild("leg_0"));
        m.put("leg_1", root.getChild("leg_1"));
        m.put("leg_2", root.getChild("leg_2"));
        m.put("leg_3", root.getChild("leg_3"));
        m.put("tail", root.getChild("tail"));
        return m;
    }

    private static Map<String, ModelPart> parts_sky_serpent(ModelPart root) {
        Map<String, ModelPart> m = new HashMap<>();
        m.put("head", root.getChild("head"));
        m.put("jaw", root.getChild("head").getChild("jaw"));
        m.put("seg0", root.getChild("seg0"));
        m.put("seg1", root.getChild("seg0").getChild("seg1"));
        m.put("seg2", root.getChild("seg0").getChild("seg1").getChild("seg2"));
        m.put("seg3", root.getChild("seg0").getChild("seg1").getChild("seg2").getChild("seg3"));
        m.put("seg4", root.getChild("seg0").getChild("seg1").getChild("seg2").getChild("seg3").getChild("seg4"));
        m.put("seg5", root.getChild("seg0").getChild("seg1").getChild("seg2").getChild("seg3").getChild("seg4").getChild("seg5"));
        m.put("wing_l", root.getChild("wing_l"));
        m.put("wing_r", root.getChild("wing_r"));
        return m;
    }

    public static LayerDefinition layer(String name) {
        switch (name) {
            case "guardian_angel": return layer_guardian_angel();
            case "celestial_griffin": return layer_celestial_griffin();
            case "celestial_dragon": return layer_celestial_dragon();
            case "cloud_spirit": return layer_cloud_spirit();
            case "crystal_golem": return layer_crystal_golem();
            case "celestial_harpy": return layer_celestial_harpy();
            case "luminous_deer": return layer_luminous_deer();
            case "sky_serpent": return layer_sky_serpent();
            default: throw new IllegalArgumentException("Modelo desconocido: " + name);
        }
    }

    public static Map<String, ModelPart> parts(String name, ModelPart root) {
        switch (name) {
            case "guardian_angel": return parts_guardian_angel(root);
            case "celestial_griffin": return parts_celestial_griffin(root);
            case "celestial_dragon": return parts_celestial_dragon(root);
            case "cloud_spirit": return parts_cloud_spirit(root);
            case "crystal_golem": return parts_crystal_golem(root);
            case "celestial_harpy": return parts_celestial_harpy(root);
            case "luminous_deer": return parts_luminous_deer(root);
            case "sky_serpent": return parts_sky_serpent(root);
            default: throw new IllegalArgumentException("Modelo desconocido: " + name);
        }
    }

    private CreatureModels() {
    }
}
