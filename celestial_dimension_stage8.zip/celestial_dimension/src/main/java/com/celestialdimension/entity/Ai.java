package com.celestialdimension.entity;

import java.util.EnumSet;
import java.util.function.Consumer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public final class Ai {
    public static FlyingPathNavigation flyingNav(Mob mob, Level level) {
        return new FlyingPathNavigation(mob, level);
    }

    /** Ataque aereo: orbita sobre el objetivo y se lanza en picado periodicamente. */
    public static class AerialAttackGoal extends Goal {
        private final Mob mob;
        private final double speed;
        private final double hover;
        private final Consumer<LivingEntity> onHit;
        private int cooldown;

        public AerialAttackGoal(Mob mob, double speed, double hover, Consumer<LivingEntity> onHit) {
            this.mob = mob;
            this.speed = speed;
            this.hover = hover;
            this.onHit = onHit;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = mob.getTarget();
            return t != null && t.isAlive();
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public void start() {
            mob.setNoGravity(true);
        }

        @Override
        public void stop() {
            mob.setNoGravity(false);
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity t = mob.getTarget();
            if (t == null) {
                return;
            }
            if (cooldown > 0) {
                cooldown--;
            }
            boolean dive = (mob.tickCount % 100) > 55;
            Vec3 dest = dive
                    ? t.position().add(0, t.getBbHeight() * 0.5, 0)
                    : t.position().add(Math.cos(mob.tickCount * 0.07) * 4, hover, Math.sin(mob.tickCount * 0.07) * 4);
            Vec3 d = dest.subtract(mob.position());
            double len = d.length();
            if (len > 0.5) {
                Vec3 v = d.scale(speed / len);
                mob.setDeltaMovement(mob.getDeltaMovement().scale(0.75).add(v.scale(0.25)));
            }
            float yaw = (float) (Mth.atan2(t.getZ() - mob.getZ(), t.getX() - mob.getX()) * Mth.RAD_TO_DEG) - 90.0f;
            mob.setYRot(yaw);
            mob.setYBodyRot(yaw);
            mob.setYHeadRot(yaw);
            double reach = mob.getBbWidth() + t.getBbWidth() + 1.0;
            if (cooldown <= 0 && mob.distanceToSqr(t) < reach * reach && mob.level() instanceof ServerLevel sl) {
                t.hurtServer(sl, sl.damageSources().mobAttack(mob), (float) mob.getAttributeValue(Attributes.ATTACK_DAMAGE));
                onHit.accept(t);
                cooldown = 25;
            }
        }
    }

    private Ai() {
    }
}
