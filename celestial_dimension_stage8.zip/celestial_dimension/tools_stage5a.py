import os, json, zlib, struct, random, math
ROOT = "/home/claude/cd/celestial_dimension"
NS = "celestial_dimension"
RES = f"{ROOT}/src/main/resources"
AS = f"{RES}/assets/{NS}"
JV = f"{ROOT}/src/main/java/com/celestialdimension"
def wj(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "w", encoding="utf-8").write(json.dumps(obj, indent=2, ensure_ascii=False) + "\n")
def png(path, W, H, px):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    raw = b"".join(b"\x00" + b"".join(bytes(px[y][x]) for x in range(W)) for y in range(H))
    def ch(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    open(path, "wb").write(b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", W, H, 8, 6, 0, 0, 0))
                           + ch(b"IDAT", zlib.compress(raw, 9)) + ch(b"IEND", b""))
def cl(v): return max(0, min(255, int(v)))

# ---------------- especificaciones ----------------
# parte: (nombre, padre, (x,y,z,w,h,d), (px,py,pz), zona[, (rx,ry,rz)])
SPECS = {}
SPECS["guardian_angel"] = dict(size=(128, 64), pal={
  "robe": ((238, 240, 255), "plain"), "skin": ((250, 222, 200), "plain"), "gold": ((255, 215, 90), "plain"),
  "wing": ((225, 238, 255), "feather"), "eye": ((90, 170, 255), "plain")}, parts=[
  ("body", None, (-4, 0, -2, 8, 12, 4), (0, 0, 0), "robe"),
  ("head", None, (-4, -8, -4, 8, 8, 8), (0, 0, 0), "skin"),
  ("halo", "head", (-3, -10, -3, 6, 1, 6), (0, 0, 0), "gold"),
  ("leg_l", None, (-2, 0, -2, 4, 12, 4), (2, 12, 0), "robe"),
  ("leg_r", None, (-2, 0, -2, 4, 12, 4), (-2, 12, 0), "robe"),
  ("arm_l", None, (-1, -2, -2, 4, 12, 4), (5, 2, 0), "robe"),
  ("arm_r", None, (-3, -2, -2, 4, 12, 4), (-5, 2, 0), "robe"),
  ("wing_l", None, (0, -12, 0, 14, 18, 1), (3, 2, 2), "wing"),
  ("wing_l2", "wing_l", (0, -10, 0, 10, 14, 1), (14, 0, 0), "wing"),
  ("wing_r", None, (-14, -12, 0, 14, 18, 1), (-3, 2, 2), "wing"),
  ("wing_r2", "wing_r", (-10, -10, 0, 10, 14, 1), (-14, 0, 0), "wing")])
SPECS["celestial_griffin"] = dict(size=(128, 64), pal={
  "fur": ((205, 160, 90), "plain"), "head": ((245, 245, 250), "feather"), "beak": ((255, 200, 70), "plain"),
  "wing": ((235, 240, 255), "feather"), "tuft": ((120, 200, 230), "plain"), "claw": ((230, 190, 80), "plain")}, parts=[
  ("body", None, (-5, -5, -9, 10, 10, 18), (0, 14, 0), "fur"),
  ("head", None, (-3, -6, -6, 6, 6, 6), (0, 10, -9), "head"),
  ("beak", "head", (-1, -3, -9, 2, 3, 3), (0, 0, 0), "beak"),
  ("leg_0", None, (-1, 0, -1, 3, 5, 3), (-4, 19, -6), "claw"),
  ("leg_1", None, (-1, 0, -1, 3, 5, 3), (4, 19, -6), "claw"),
  ("leg_2", None, (-2, 0, -2, 4, 5, 4), (-4, 19, 7), "fur"),
  ("leg_3", None, (-2, 0, -2, 4, 5, 4), (4, 19, 7), "fur"),
  ("wing_l", None, (0, -1, -3, 14, 1, 9), (4, 9, -3), "wing"),
  ("wing_l2", "wing_l", (0, -1, -2, 10, 1, 7), (14, 0, 0), "wing"),
  ("wing_r", None, (-14, -1, -3, 14, 1, 9), (-4, 9, -3), "wing"),
  ("wing_r2", "wing_r", (-10, -1, -2, 10, 1, 7), (-14, 0, 0), "wing"),
  ("tail", None, (-1, -1, 0, 3, 3, 8), (0, 12, 9), "fur"),
  ("tail2", "tail", (-2, -2, 0, 4, 4, 3), (0, 0, 8), "tuft")])
SPECS["celestial_dragon"] = dict(size=(128, 128), pal={
  "scale": ((60, 105, 200), "scale"), "belly": ((238, 224, 160), "plain"), "wing": ((110, 170, 255), "feather"),
  "horn": ((255, 215, 90), "plain"), "eye": ((255, 235, 90), "plain"), "claw": ((235, 235, 245), "plain")}, parts=[
  ("body", None, (-6, -6, -12, 12, 12, 24), (0, 12, 0), "scale"),
  ("neck", None, (-3, -3, -8, 6, 6, 8), (0, 9, -12), "scale", (-0.5, 0, 0)),
  ("head", "neck", (-4, -3, -8, 8, 6, 8), (0, 0, -8), "scale"),
  ("jaw", "head", (-3, 0, -7, 6, 2, 7), (0, 3, 0), "belly"),
  ("horn_l", "head", (0, -6, -1, 2, 6, 2), (3, -3, -2), "horn"),
  ("horn_r", "head", (-2, -6, -1, 2, 6, 2), (-3, -3, -2), "horn"),
  ("leg_0", None, (-2, 0, -2, 4, 8, 4), (-5, 16, -8), "scale"),
  ("leg_1", None, (-2, 0, -2, 4, 8, 4), (5, 16, -8), "scale"),
  ("leg_2", None, (-2, 0, -2, 4, 8, 4), (-5, 16, 8), "scale"),
  ("leg_3", None, (-2, 0, -2, 4, 8, 4), (5, 16, 8), "scale"),
  ("wing_l", None, (0, -1, -3, 20, 1, 14), (6, 8, -6), "wing"),
  ("wing_l2", "wing_l", (0, -1, -2, 16, 1, 10), (20, 0, 0), "wing"),
  ("wing_r", None, (-20, -1, -3, 20, 1, 14), (-6, 8, -6), "wing"),
  ("wing_r2", "wing_r", (-16, -1, -2, 16, 1, 10), (-20, 0, 0), "wing"),
  ("tail", None, (-4, -3, 0, 8, 6, 10), (0, 12, 12), "scale"),
  ("tail2", "tail", (-3, -2, 0, 6, 4, 10), (0, 0, 10), "scale"),
  ("tail3", "tail2", (-2, -1, 0, 4, 3, 10), (0, 0, 10), "scale"),
  ("tail4", "tail3", (-1, -1, 0, 2, 2, 8), (0, 0, 10), "horn")])
SPECS["cloud_spirit"] = dict(size=(64, 64), pal={
  "cloud": ((240, 246, 255), "cloud"), "face": ((255, 255, 255), "plain"), "wing": ((200, 225, 255), "feather"),
  "eye": ((70, 140, 230), "plain")}, parts=[
  ("body", None, (-3, -3, -3, 6, 6, 6), (0, 17, 0), "cloud"),
  ("head", None, (-3, -6, -3, 6, 6, 6), (0, 14, 0), "face"),
  ("tail", None, (-2, 0, -2, 4, 4, 4), (0, 20, 0), "cloud"),
  ("tail2", "tail", (-1, 0, -1, 2, 3, 2), (0, 4, 0), "cloud"),
  ("arm_l", None, (0, -1, -1, 3, 2, 2), (3, 16, 0), "cloud"),
  ("arm_r", None, (-3, -1, -1, 3, 2, 2), (-3, 16, 0), "cloud"),
  ("wing_l", None, (0, -3, 0, 6, 6, 1), (2, 16, 3), "wing"),
  ("wing_r", None, (-6, -3, 0, 6, 6, 1), (-2, 16, 3), "wing")])
SPECS["crystal_golem"] = dict(size=(128, 64), pal={
  "stone": ((135, 148, 185), "plain"), "crystal": ((110, 225, 255), "crystal"), "eye": ((255, 240, 120), "plain"),
  "dark": ((90, 100, 140), "plain")}, parts=[
  ("body", None, (-8, -12, -5, 16, 24, 10), (0, 0, 0), "stone"),
  ("head", None, (-4, -8, -4, 8, 8, 8), (0, -12, 0), "stone"),
  ("leg_l", None, (-3, 0, -3, 6, 12, 6), (5, 12, 0), "dark"),
  ("leg_r", None, (-3, 0, -3, 6, 12, 6), (-5, 12, 0), "dark"),
  ("arm_l", None, (-3, -2, -3, 6, 22, 6), (11, -8, 0), "stone"),
  ("arm_r", None, (-3, -2, -3, 6, 22, 6), (-11, -8, 0), "stone"),
  ("crystal_1", "body", (-6, -12, 5, 4, 12, 4), (0, -8, 0), "crystal"),
  ("crystal_2", "body", (2, -16, 5, 4, 16, 4), (0, -8, 0), "crystal"),
  ("crystal_3", "head", (-1, -5, -1, 2, 5, 2), (0, -8, 0), "crystal")])
SPECS["celestial_harpy"] = dict(size=(128, 64), pal={
  "feather": ((150, 120, 190), "feather"), "skin": ((235, 205, 185), "plain"), "beak": ((255, 190, 60), "plain"),
  "wing": ((120, 90, 175), "feather"), "talon": ((240, 200, 90), "plain"), "eye": ((255, 80, 80), "plain")}, parts=[
  ("body", None, (-3, 0, -2, 6, 9, 4), (0, 8, 0), "feather"),
  ("head", None, (-3, -6, -3, 6, 6, 6), (0, 8, 0), "skin"),
  ("beak", "head", (-1, -3, -5, 2, 2, 2), (0, 0, 0), "beak"),
  ("crest", "head", (-1, -8, -2, 2, 2, 4), (0, 0, 0), "feather"),
  ("leg_l", None, (-1, 0, -1, 2, 7, 2), (2, 17, 0), "talon"),
  ("leg_r", None, (-1, 0, -1, 2, 7, 2), (-2, 17, 0), "talon"),
  ("wing_l", None, (0, 0, -2, 16, 1, 8), (3, 9, 2), "wing"),
  ("wing_l2", "wing_l", (0, 0, -2, 12, 1, 6), (16, 0, 0), "wing"),
  ("wing_r", None, (-16, 0, -2, 16, 1, 8), (-3, 9, 2), "wing"),
  ("wing_r2", "wing_r", (-12, 0, -2, 12, 1, 6), (-16, 0, 0), "wing"),
  ("tail", None, (-2, 0, 0, 4, 1, 8), (0, 16, 2), "wing")])
SPECS["luminous_deer"] = dict(size=(128, 64), pal={
  "fur": ((235, 225, 200), "spots"), "antler": ((130, 235, 235), "crystal"), "dark": ((170, 150, 130), "plain"),
  "eye": ((60, 90, 140), "plain")}, parts=[
  ("body", None, (-3, -4, -8, 6, 8, 16), (0, 12, 0), "fur"),
  ("neck", None, (-2, -10, -3, 4, 10, 4), (0, 10, -6), "fur"),
  ("head", "neck", (-2, -4, -4, 4, 4, 6), (0, -10, -1), "fur"),
  ("antler_l", "head", (0, -6, 0, 1, 6, 1), (1, -4, -1), "antler"),
  ("antler_l2", "antler_l", (0, -3, 0, 3, 1, 1), (0, -4, 0), "antler"),
  ("antler_r", "head", (-1, -6, 0, 1, 6, 1), (-1, -4, -1), "antler"),
  ("antler_r2", "antler_r", (-3, -3, 0, 3, 1, 1), (0, -4, 0), "antler"),
  ("leg_0", None, (-1, 0, -1, 2, 8, 2), (-2, 16, -6), "dark"),
  ("leg_1", None, (-1, 0, -1, 2, 8, 2), (2, 16, -6), "dark"),
  ("leg_2", None, (-1, 0, -1, 2, 8, 2), (-2, 16, 6), "dark"),
  ("leg_3", None, (-1, 0, -1, 2, 8, 2), (2, 16, 6), "dark"),
  ("tail", None, (-1, -1, 0, 2, 2, 3), (0, 9, 8), "fur")])
SPECS["sky_serpent"] = dict(size=(128, 64), pal={
  "scale": ((60, 190, 160), "scale"), "belly": ((230, 240, 170), "plain"), "wing": ((130, 90, 200), "feather"),
  "eye": ((255, 60, 60), "plain")}, parts=[
  ("head", None, (-3, -3, -8, 6, 6, 8), (0, 16, -14), "scale"),
  ("jaw", "head", (-2, 0, -7, 4, 1, 7), (0, 3, 0), "belly"),
  ("seg0", None, (-3, -3, 0, 6, 6, 8), (0, 16, -14), "scale"),
  ("seg1", "seg0", (-3, -3, 0, 6, 6, 8), (0, 0, 8), "scale"),
  ("seg2", "seg1", (-3, -3, 0, 6, 6, 8), (0, 0, 8), "scale"),
  ("seg3", "seg2", (-2, -2, 0, 4, 4, 8), (0, 0, 8), "scale"),
  ("seg4", "seg3", (-2, -2, 0, 4, 4, 8), (0, 0, 8), "scale"),
  ("seg5", "seg4", (-1, -1, 0, 2, 2, 8), (0, 0, 8), "belly"),
  ("wing_l", None, (0, -1, -2, 12, 1, 6), (3, 14, -10), "wing"),
  ("wing_r", None, (-12, -1, -2, 12, 1, 6), (-3, 14, -10), "wing")])

# ---------------- pintura de texturas ----------------
def paint(name, spec):
    W, H = spec["size"]
    px = [[(0, 0, 0, 0) for _ in range(W)] for _ in range(H)]
    rnd = random.Random(hash(name) & 0xffff)
    x = y = rowh = 0
    placed = []
    for p in spec["parts"]:
        bx, by, bz, w, h, d = p[2]
        fw, fh = 2 * d + 2 * w, d + h
        if x + fw > W: x, y, rowh = 0, y + rowh, 0
        if y + fh > H: raise SystemExit(f"{name}: textura demasiado pequena en {p[0]}")
        placed.append((p, x, y)); x += fw; rowh = max(rowh, fh)
    def fillreg(x0, y0, w, h, zone, shade, part):
        base, kind = spec["pal"][zone]
        for yy in range(h):
            for xx in range(w):
                n = rnd.randint(-10, 10)
                r, g, b = base
                if kind == "scale" and (xx + yy) % 4 == 0: n -= 28
                if kind == "scale" and (xx - yy) % 4 == 0: n -= 14
                if kind == "feather" and yy % 3 == 0: n += 24
                if kind == "feather" and xx % 5 == 0: n -= 14
                if kind == "crystal" and (xx + yy) % 5 in (0, 1): n += 55
                if kind == "crystal" and (xx + yy) % 5 == 3: n -= 30
                if kind == "cloud" and rnd.random() < 0.15: n += 15
                if kind == "spots" and rnd.random() < 0.06: r, g, b, n = 120, 255, 235, 0
                px[y0 + yy][x0 + xx] = (cl(r + n + shade), cl(g + n + shade), cl(b + n + shade), 255)
    for (p, ox, oy) in placed:
        name_, parent, (bx, by, bz, w, h, d), pose, zone = p[:5]
        regs = {"top": (ox + d, oy, w, d, 18), "bottom": (ox + d + w, oy, w, d, -34),
                "right": (ox, oy + d, d, h, -8), "front": (ox + d, oy + d, w, h, 0),
                "left": (ox + d + w, oy + d, d, h, -8), "back": (ox + 2 * d + w, oy + d, w, h, -14)}
        for k, (rx, ry, rw, rh, sh) in regs.items():
            if rw > 0 and rh > 0: fillreg(rx, ry, rw, rh, zone, sh, name_)
        if name_ == "head" and "eye" in spec["pal"]:
            fx, fy = ox + d, oy + d
            ey = fy + max(0, h // 3)
            for ex in (fx + max(0, w // 4 - 1), fx + w - max(1, w // 4)):
                if 0 <= ex < W and ey < H: px[ey][ex] = tuple(list(spec["pal"]["eye"][0]) + [255])
                if h >= 6 and w >= 6: px[ey][min(ex + 1, W - 1)] = tuple(list(spec["pal"]["eye"][0]) + [255])
    png(f"{AS}/textures/entity/{name}.png", W, H, px)
    return placed

# ---------------- generacion de CreatureModels.java ----------------
def f(v): return f"{float(v)}F"
java = ["package com.celestialdimension.client;", "",
 "import java.util.HashMap;", "import java.util.Map;",
 "import net.minecraft.client.model.geom.ModelPart;",
 "import net.minecraft.client.model.geom.PartPose;",
 "import net.minecraft.client.model.geom.builders.CubeListBuilder;",
 "import net.minecraft.client.model.geom.builders.LayerDefinition;",
 "import net.minecraft.client.model.geom.builders.MeshDefinition;",
 "import net.minecraft.client.model.geom.builders.PartDefinition;", "",
 "/** Generado por tools_stage5a.py: geometria de las criaturas (las texturas PNG se pintan con el mismo diseno). */",
 "public final class CreatureModels {"]
layers, partsfn = [], []
for name, spec in SPECS.items():
    placed = paint(name, spec)
    pathof = {}
    for p, ox, oy in placed:
        pathof[p[0]] = (pathof[p[1]] + [p[0]]) if p[1] else [p[0]]
    body = [f"    private static LayerDefinition layer_{name}() {{",
            "        MeshDefinition mesh = new MeshDefinition();",
            "        PartDefinition root = mesh.getRoot();"]
    for p, ox, oy in placed:
        n, parent, (x, y, z, w, h, d), (px_, py_, pz_), zone = p[:5]
        rot = p[5] if len(p) > 5 else (0, 0, 0)
        pose = (f"PartPose.offsetAndRotation({f(px_)}, {f(py_)}, {f(pz_)}, {f(rot[0])}, {f(rot[1])}, {f(rot[2])})"
                if any(rot) else f"PartPose.offset({f(px_)}, {f(py_)}, {f(pz_)})")
        par = f"p_{parent}" if parent else "root"
        body.append(f"        PartDefinition p_{n} = {par}.addOrReplaceChild(\"{n}\", CubeListBuilder.create().texOffs({ox}, {oy})"
                    f".addBox({f(x)}, {f(y)}, {f(z)}, {f(w)}, {f(h)}, {f(d)}), {pose});")
    body.append(f"        return LayerDefinition.create(mesh, {spec['size'][0]}, {spec['size'][1]});")
    body.append("    }"); body.append("")
    layers.append("\n".join(body))
    pf = [f"    private static Map<String, ModelPart> parts_{name}(ModelPart root) {{",
          "        Map<String, ModelPart> m = new HashMap<>();"]
    for p, ox, oy in placed:
        chain = "".join(f".getChild(\"{c}\")" for c in pathof[p[0]])
        pf.append(f"        m.put(\"{p[0]}\", root{chain});")
    pf += ["        return m;", "    }", ""]
    partsfn.append("\n".join(pf))
java += layers + partsfn
java += ["    public static LayerDefinition layer(String name) {", "        switch (name) {"]
java += [f"            case \"{n}\": return layer_{n}();" for n in SPECS]
java += ["            default: throw new IllegalArgumentException(\"Modelo desconocido: \" + name);", "        }", "    }", "",
         "    public static Map<String, ModelPart> parts(String name, ModelPart root) {", "        switch (name) {"]
java += [f"            case \"{n}\": return parts_{n}(root);" for n in SPECS]
java += ["            default: throw new IllegalArgumentException(\"Modelo desconocido: \" + name);", "        }", "    }", "",
         "    private CreatureModels() {", "    }", "}", ""]
os.makedirs(f"{JV}/client", exist_ok=True)
open(f"{JV}/client/CreatureModels.java", "w").write("\n".join(java))
print("creatures:", list(SPECS))
