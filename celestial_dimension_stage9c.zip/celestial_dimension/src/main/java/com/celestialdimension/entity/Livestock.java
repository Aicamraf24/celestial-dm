package com.celestialdimension.entity;

import com.celestialdimension.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.BreedGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowParentGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.TemptGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** Animales celestiales pacificos: versiones azuladas de los del Overworld y dos criaturas nuevas. */
public final class Livestock {

    public static class Pig extends CelestialAnimal {
        public Pig(EntityType<? extends Pig> type, Level level) {
            super(type, level);
        }

        public static AttributeSupplier.Builder attrs() {
            return CelestialAnimal.attrs(10.0, 0.25);
        }

        @Override
        protected boolean isFoodItem(ItemStack s) {
            return s.is(Items.CARROT) || s.is(Items.POTATO) || s.is(Items.BEETROOT);
        }

        @Override
        protected SoundEvent getAmbientSound() {
            return SoundEvents.PIG_AMBIENT;
        }

        @Override
        protected SoundEvent getHurtSound(DamageSource source) {
            return SoundEvents.PIG_HURT;
        }

        @Override
        protected SoundEvent getDeathSound() {
            return SoundEvents.PIG_DEATH;
        }
    }

    public static class Cow extends CelestialAnimal {
        public Cow(EntityType<? extends Cow> type, Level level) {
            super(type, level);
        }

        public static AttributeSupplier.Builder attrs() {
            return CelestialAnimal.attrs(12.0, 0.2);
        }

        @Override
        protected boolean isFoodItem(ItemStack s) {
            return s.is(Items.WHEAT);
        }

        @Override
        protected SoundEvent getAmbientSound() {
            return SoundEvents.COW_AMBIENT;
        }

        @Override
        protected SoundEvent getHurtSound(DamageSource source) {
            return SoundEvents.COW_HURT;
        }

        @Override
        protected SoundEvent getDeathSound() {
            return SoundEvents.COW_DEATH;
        }
    }

    public static class Sheep extends CelestialAnimal {
        public Sheep(EntityType<? extends Sheep> type, Level level) {
            super(type, level);
        }

        public static AttributeSupplier.Builder attrs() {
            return CelestialAnimal.attrs(8.0, 0.23);
        }

        @Override
        protected boolean isFoodItem(ItemStack s) {
            return s.is(Items.WHEAT);
        }

        @Override
        protected SoundEvent getAmbientSound() {
            return SoundEvents.SHEEP_AMBIENT;
        }

        @Override
        protected SoundEvent getHurtSound(DamageSource source) {
            return SoundEvents.SHEEP_HURT;
        }

        @Override
        protected SoundEvent getDeathSound() {
            return SoundEvents.SHEEP_DEATH;
        }
    }

    /** Gallina planeadora: cae despacio y no recibe danio por caida. */
    public static class Chicken extends CelestialAnimal {
        public Chicken(EntityType<? extends Chicken> type, Level level) {
            super(type, level);
        }

        public static AttributeSupplier.Builder attrs() {
            return CelestialAnimal.attrs(4.0, 0.25);
        }

        @Override
        protected boolean isFoodItem(ItemStack s) {
            return s.is(Items.WHEAT_SEEDS) || s.is(Items.BEETROOT_SEEDS) || s.is(Items.MELON_SEEDS)
                    || s.is(Items.PUMPKIN_SEEDS);
        }

        @Override
        public void aiStep() {
            super.aiStep();
            if (!onGround() && getDeltaMovement().y < 0.0) {
                setDeltaMovement(getDeltaMovement().multiply(1.0, 0.6, 1.0));
            }
        }

        @Override
        protected void checkFallDamage(double y, boolean onGround, BlockState state, BlockPos pos) {
        }

        @Override
        public boolean isFlyingNow() {
            return !onGround();
        }

        @Override
        protected SoundEvent getAmbientSound() {
            return SoundEvents.CHICKEN_AMBIENT;
        }

        @Override
        protected SoundEvent getHurtSound(DamageSource source) {
            return SoundEvents.CHICKEN_HURT;
        }

        @Override
        protected SoundEvent getDeathSound() {
            return SoundEvents.CHICKEN_DEATH;
        }
    }

    public static class Llama extends CelestialAnimal {
        public Llama(EntityType<? extends Llama> type, Level level) {
            super(type, level);
        }

        public static AttributeSupplier.Builder attrs() {
            return CelestialAnimal.attrs(20.0, 0.2);
        }

        @Override
        protected boolean isFoodItem(ItemStack s) {
            return s.is(Items.WHEAT) || s.is(Items.HAY_BLOCK);
        }

        @Override
        protected SoundEvent getAmbientSound() {
            return SoundEvents.LLAMA_AMBIENT;
        }

        @Override
        protected SoundEvent getHurtSound(DamageSource source) {
            return SoundEvents.LLAMA_HURT;
        }

        @Override
        protected SoundEvent getDeathSound() {
            return SoundEvents.LLAMA_DEATH;
        }
    }

    public static class Goat extends CelestialAnimal {
        public Goat(EntityType<? extends Goat> type, Level level) {
            super(type, level);
        }

        public static AttributeSupplier.Builder attrs() {
            return CelestialAnimal.attrs(10.0, 0.25);
        }

        @Override
        protected boolean isFoodItem(ItemStack s) {
            return s.is(Items.WHEAT);
        }

        @Override
        protected SoundEvent getAmbientSound() {
            return SoundEvents.GOAT_AMBIENT;
        }

        @Override
        protected SoundEvent getHurtSound(DamageSource source) {
            return SoundEvents.GOAT_HURT;
        }

        @Override
        protected SoundEvent getDeathSound() {
            return SoundEvents.GOAT_DEATH;
        }
    }

    /** Manta de nubes: criatura voladora pacifica; se cria con manzanas. */
    public static class CloudManta extends CelestialAnimal {
        public CloudManta(EntityType<? extends CloudManta> type, Level level) {
            super(type, level);
            this.moveControl = new FlyingMoveControl(this, 20, true);
        }

        public static AttributeSupplier.Builder attrs() {
            return CelestialAnimal.attrs(12.0, 0.2).add(Attributes.FLYING_SPEED, 0.3);
        }

        @Override
        protected boolean airborne() {
            return true;
        }

        @Override
        protected boolean isFoodItem(ItemStack s) {
            return s.is(Items.APPLE);
        }

        @Override
        protected PathNavigation createNavigation(Level level) {
            return Ai.flyingNav(this, level);
        }

        @Override
        protected void registerGoals() {
            this.goalSelector.addGoal(0, new FloatGoal(this));
            this.goalSelector.addGoal(1, new PanicGoal(this, 1.3));
            this.goalSelector.addGoal(2, new BreedGoal(this, 1.0));
            this.goalSelector.addGoal(3, new TemptGoal(this, 1.1, this::isFood, false));
            this.goalSelector.addGoal(4, new FollowParentGoal(this, 1.1));
            this.goalSelector.addGoal(5, new WaterAvoidingRandomFlyingGoal(this, 1.0));
            this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 6.0f));
            this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        }

        @Override
        protected void checkFallDamage(double y, boolean onGround, BlockState state, BlockPos pos) {
        }

        @Override
        public boolean isFlyingNow() {
            return true;
        }
    }

    /** Pegaso celeste: montura voladora. Clic derecho con la mano vacia para montarlo; se cria con zanahorias y manzanas. */
    public static class Pegasus extends CelestialAnimal {
        public Pegasus(EntityType<? extends Pegasus> type, Level level) {
            super(type, level);
        }

        public static AttributeSupplier.Builder attrs() {
            return CelestialAnimal.attrs(30.0, 0.25).add(Attributes.FLYING_SPEED, 0.6);
        }

        @Override
        protected boolean isFoodItem(ItemStack s) {
            return s.is(Items.CARROT) || s.is(Items.GOLDEN_CARROT) || s.is(Items.APPLE);
        }

        @Override
        public InteractionResult mobInteract(Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (!isFood(stack) && !isBaby() && !isVehicle() && stack.isEmpty()) {
                if (!level().isClientSide()) {
                    player.startRiding(this);
                }
                return InteractionResult.SUCCESS;
            }
            return super.mobInteract(player, hand);
        }

        @Override
        public LivingEntity getControllingPassenger() {
            return getFirstPassenger() instanceof LivingEntity le ? le : null;
        }

        @Override
        public void aiStep() {
            super.aiStep();
            setNoGravity(isVehicle());
        }

        @Override
        protected Vec3 getRiddenInput(Player player, Vec3 travelVector) {
            float forward = player.zza;
            double vertical = forward > 0.0f ? -Math.sin(player.getXRot() * Mth.DEG_TO_RAD) * forward * 0.9 : 0.0;
            return new Vec3(player.xxa * 0.5, vertical, forward > 0.0f ? forward : forward * 0.25f);
        }

        @Override
        protected float getRiddenSpeed(Player player) {
            return (float) getAttributeValue(Attributes.FLYING_SPEED) * 0.7f;
        }

        @Override
        protected void tickRidden(Player player, Vec3 riddenInput) {
            super.tickRidden(player, riddenInput);
            setRot(player.getYRot(), player.getXRot() * 0.5f);
            this.yRotO = getYRot();
            this.yBodyRot = getYRot();
            this.yHeadRot = getYRot();
        }

        @Override
        protected void checkFallDamage(double y, boolean onGround, BlockState state, BlockPos pos) {
        }

        @Override
        public boolean isFlyingNow() {
            return isVehicle() || !onGround();
        }
    }

    private Livestock() {
    }
}
