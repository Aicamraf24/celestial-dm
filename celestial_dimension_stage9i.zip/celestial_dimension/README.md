# Celestial Dimension (Etapa 1)

Mod Fabric para Minecraft Java 26.1.2 (Java 25, Loom 1.15.5, Fabric API 0.145.4+26.1.2).

Etapa 1: 22 bloques, 5 materiales, texturas PNG generadas por script, recetas, loot tables, idiomas es/en,
pestaña creativa y compilación con GitHub Actions.
Pendiente (etapas siguientes): dimensión y portal, biomas, estructuras, criaturas, jefe, equipamiento, sonidos.

Compilar: súbelo a GitHub -> pestaña Actions -> "Build Celestial Dimension" -> Artifacts -> celestial_dimension-jar.

## Etapa 2 (dimension y portal)
- Dimension `celestial_dimension:celestial`: islas flotantes por ruido, cuevas, cascadas (manantiales), lagos, arboles gigantes, menas.
- Portal: marco de 10 `portal_frame` (anillo 4x5 sin esquinas, interior 2x3) y clic derecho con un Fragmento Solar.
- Comando de prueba: `/execute in celestial_dimension:celestial run tp @s ~ 120 ~`

## Etapa 3 (seis biomas)
Fuente de biomas multi-ruido (temperatura x humedad): Montanas Sagradas, Islas Cristalinas, Praderas Celestiales,
Jardines Luminosos, Ruinas del Cielo, Bosque de las Nubes. Cada uno con superficie, vegetacion/estructuras naturales
(columnas de cristal, pilares, nubes), colores y menas propias. Criaturas: Etapa 5.

## Etapa 4 (estructuras)
9 estructuras jigsaw de una pieza, cada una con su propia isla: templo celestial, torre flotante, aldea suspendida,
santuario, ruinas antiguas, mina abandonada, camara secreta, mazmorra y Santuario del Dragon Celestial, con loot tables.
Localizar: /locate structure celestial_dimension:celestial_temple (etc.)

## Etapas 4 a 8
- Etapa 4: 9 estructuras (ver arriba) con loot tables. /locate structure celestial_dimension:<nombre>
- Etapa 5: 8 criaturas con modelo 3D propio, textura PNG pintada desde el mismo diseno, animaciones, IA, drops y aparicion por bioma.
  Invocar: /summon celestial_dimension:celestial_harpy (etc.)
- Etapa 6: Dragon Celestial (3 fases, vuelo/aterrizaje, rayos, lluvia de energia, onda de choque, invocacion de arpias, barra de jefe).
  Se invoca con un Fragmento Solar sobre el Altar del Dragon (centro del Santuario del Dragon Celestial).
- Etapa 7: armaduras de Cristal de Aurora y Divina (bono de set), Espada Celestial (rafaga), Daga de Eter (salto), Arco de Luz, 4 herramientas.
- Etapa 8: particulas (portal, cristales, altar, criaturas). Sonidos: vanilla (los propios quedan fuera por peticion).

## Vegetacion y animales celestiales
- Plantas: brote celestial (crece solo o con polvo de hueso), mata de hierba, helecho luminoso, flor azur, lirio solar, orquidea de eter,
  algodon de nube, brote de cristal, tulipan lunar. Arboles: normal, pequeno, pino, sombrilla y gigante (todos de tronco y hojas celestiales).
- Animales pacificos: cerdo, vaca, oveja, gallina, llama y cabra celestiales, Manta de Nubes (voladora) y Pegaso Celeste (montura voladora).
  Se crian con comida natural del Overworld (zanahoria/patata/remolacha, trigo, semillas, heno, manzana).
- Huevos de aparicion para las 16 criaturas.
