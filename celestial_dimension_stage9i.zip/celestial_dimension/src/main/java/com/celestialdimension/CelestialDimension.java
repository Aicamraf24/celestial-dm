package com.celestialdimension;

import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CelestialDimension implements ModInitializer {
    public static final String MOD_ID = "celestial_dimension";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModBlocks.init();
        ModItems.init();
        ModCreativeTab.init();
        ModPortal.init();
        ModEntities.init();
        ModEquipment.init();
        ModAbilities.init();
        ModBoss.init();
        ModNature.init();
        ModSpawnEggs.init();
        LOGGER.info("Celestial Dimension cargado: {} bloques registrados", ModBlocks.COUNT);
    }
}
