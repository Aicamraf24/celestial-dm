package com.celestialdimension;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

/** Brote del arbol celestial: crece con el tiempo o con polvo de hueso, usando tronco y hojas celestiales. */
public class CelestialSaplingBlock extends Block {
    public CelestialSaplingBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (level.getBlockState(pos.below()).isAir()) {
            level.destroyBlock(pos, true);
            return;
        }
        if (random.nextInt(7) == 0 && level.getMaxLocalRawBrightness(pos.above()) >= 9) {
            grow(level, pos, random);
        }
    }

    /** Coloca un arbol; si no hay espacio libre no hace nada. */
    public static boolean grow(ServerLevel level, BlockPos pos, RandomSource random) {
        int h = 5 + random.nextInt(3);
        for (int y = 1; y <= h + 1; y++) {
            BlockState s = level.getBlockState(pos.above(y));
            if (!s.isAir() && !s.is(ModBlocks.CELESTIAL_LEAVES)) {
                return false;
            }
        }
        BlockState log = ModBlocks.CELESTIAL_LOG.defaultBlockState();
        BlockState leaves = ModBlocks.CELESTIAL_LEAVES.defaultBlockState();
        for (int dy = h - 3; dy <= h + 1; dy++) {
            int r = dy >= h ? 1 : 2;
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (Math.abs(dx) == r && Math.abs(dz) == r && (dy >= h || random.nextInt(3) == 0)) {
                        continue;
                    }
                    BlockPos p = pos.offset(dx, dy, dz);
                    if (level.getBlockState(p).isAir()) {
                        level.setBlock(p, leaves, Block.UPDATE_ALL);
                    }
                }
            }
        }
        for (int y = 0; y < h; y++) {
            level.setBlock(pos.above(y), log, Block.UPDATE_ALL);
        }
        return true;
    }
}
