package com.celestialdimension;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

/** Habilidades de equipo: bonos de set (armadura), rafaga celestial (espada), salto etereo (daga), flechas de luz (arco). */
public final class ModAbilities {
    private static final Map<UUID, Long> BURST = new HashMap<>();
    private static final Map<UUID, Long> BLINK = new HashMap<>();

    private static boolean wearing(ServerPlayer p, EquipmentSlot slot, Item item) {
        return p.getItemBySlot(slot).is(item);
    }

    public static void init() {
        // Bonos de set cada 2 segundos
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTickCount() % 40 != 0) {
                return;
            }
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                boolean aurora = wearing(p, EquipmentSlot.HEAD, ModEquipment.AURORA_HELMET)
                        && wearing(p, EquipmentSlot.CHEST, ModEquipment.AURORA_CHESTPLATE)
                        && wearing(p, EquipmentSlot.LEGS, ModEquipment.AURORA_LEGGINGS)
                        && wearing(p, EquipmentSlot.FEET, ModEquipment.AURORA_BOOTS);
                boolean divine = wearing(p, EquipmentSlot.HEAD, ModEquipment.DIVINE_HELMET)
                        && wearing(p, EquipmentSlot.CHEST, ModEquipment.DIVINE_CHESTPLATE)
                        && wearing(p, EquipmentSlot.LEGS, ModEquipment.DIVINE_LEGGINGS)
                        && wearing(p, EquipmentSlot.FEET, ModEquipment.DIVINE_BOOTS);
                if (aurora) {
                    p.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 100, 0, true, false));
                    p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 260, 0, true, false));
                    p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 100, 0, true, false));
                }
                if (divine) {
                    p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0, true, false));
                    p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 100, 1, true, false));
                    p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 100, 0, true, false));
                    p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 100, 0, true, false));
                    p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 260, 0, true, false));
                }
            }
        });

        // Clic derecho: rafaga (espada) y salto etereo (daga)
        UseItemCallback.EVENT.register((player, level, hand) -> {
            if (!(level instanceof ServerLevel sl) || !(player instanceof ServerPlayer sp)) {
                return InteractionResult.PASS;
            }
            ItemStack stack = player.getItemInHand(hand);
            long now = sl.getGameTime();
            if (stack.is(ModEquipment.CELESTIAL_SWORD)) {
                Long last = BURST.get(sp.getUUID());
                if (last != null && now - last < 100) {
                    Msg.overlay(sp, "message.celestial_dimension.cooldown");
                    return InteractionResult.PASS;
                }
                BURST.put(sp.getUUID(), now);
                burst(sl, sp);
                return InteractionResult.SUCCESS;
            }
            if (stack.is(ModEquipment.ETHER_DAGGER)) {
                Long last = BLINK.get(sp.getUUID());
                if (last != null && now - last < 60) {
                    Msg.overlay(sp, "message.celestial_dimension.cooldown");
                    return InteractionResult.PASS;
                }
                if (blink(sl, sp)) {
                    BLINK.put(sp.getUUID(), now);
                    return InteractionResult.SUCCESS;
                }
            }
            return InteractionResult.PASS;
        });

        // Arco de Luz: flechas criticas, mas danio y brillantes
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof AbstractArrow arrow && arrow.getOwner() instanceof LivingEntity owner
                    && owner.getMainHandItem().is(ModEquipment.LIGHT_BOW)) {
                arrow.setBaseDamage(4.0);
                arrow.setCritArrow(true);
                arrow.setGlowingTag(true);
            }
        });
    }

    private static void burst(ServerLevel sl, ServerPlayer p) {
        sl.sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 1.0, p.getZ(), 60, 2.5, 0.6, 2.5, 0.1);
        List<LivingEntity> list = sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(5.0),
                e -> e != p && e.isAlive());
        for (LivingEntity e : list) {
            e.hurtServer(sl, sl.damageSources().playerAttack(p), 9.0f);
            Vec3 away = e.position().subtract(p.position()).multiply(1, 0, 1).normalize();
            e.push(away.x * 0.9, 0.4, away.z * 0.9);
        }
    }

    private static boolean blink(ServerLevel sl, ServerPlayer p) {
        Vec3 look = p.getLookAngle();
        Vec3 eye = p.getEyePosition();
        Vec3 best = null;
        for (int i = 1; i <= 8; i++) {
            Vec3 pos = eye.add(look.scale(i));
            BlockPos feet = BlockPos.containing(pos.x, pos.y - 1.0, pos.z);
            if (sl.getBlockState(feet).isAir() && sl.getBlockState(feet.above()).isAir()) {
                best = new Vec3(pos.x, pos.y - 1.0, pos.z);
            } else {
                break;
            }
        }
        if (best == null) {
            return false;
        }
        sl.sendParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1.0, p.getZ(), 30, 0.3, 0.6, 0.3, 0.5);
        p.teleportTo(best.x, best.y, best.z);
        sl.sendParticles(ParticleTypes.PORTAL, best.x, best.y + 1.0, best.z, 30, 0.3, 0.6, 0.3, 0.5);
        return true;
    }

    private ModAbilities() {
    }
}
