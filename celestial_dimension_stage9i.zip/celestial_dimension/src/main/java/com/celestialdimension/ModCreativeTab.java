package com.celestialdimension;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;

public final class ModCreativeTab {
    public static void init() {
        ResourceKey<CreativeModeTab> key = ResourceKey.create(Registries.CREATIVE_MODE_TAB, CelestialDimension.id("main"));
        CreativeModeTab tab = CreativeModeTab.builder(CreativeModeTab.Row.TOP, 0)
                .title(Component.translatable("itemGroup." + CelestialDimension.MOD_ID + ".main"))
                .icon(() -> new ItemStack(ModItems.AURORA_CRYSTAL))
                .displayItems((params, output) -> {
                    output.accept(ModBlocks.CELESTIAL_GRASS);
                    output.accept(ModBlocks.CELESTIAL_DIRT);
                    output.accept(ModBlocks.CELESTIAL_STONE);
                    output.accept(ModBlocks.ANCIENT_STONE);
                    output.accept(ModBlocks.CELESTIAL_MARBLE);
                    output.accept(ModBlocks.CELESTIAL_BRICKS);
                    output.accept(ModBlocks.AZURE_CRYSTAL_GLASS);
                    output.accept(ModBlocks.LUMINOUS_CRYSTAL);
                    output.accept(ModBlocks.SACRED_CRYSTAL);
                    output.accept(ModBlocks.SOLID_CLOUD);
                    output.accept(ModBlocks.CELESTIAL_PLANKS);
                    output.accept(ModBlocks.CELESTIAL_LOG);
                    output.accept(ModBlocks.CELESTIAL_LEAVES);
                    output.accept(ModBlocks.LUMINOUS_FLOWER_BLOCK);
                    output.accept(ModBlocks.CELESTIAL_SAND);
                    output.accept(ModBlocks.TEMPLE_TILES);
                    output.accept(ModBlocks.RUIN_BRICKS);
                    output.accept(ModBlocks.ESSENCE_ORE);
                    output.accept(ModBlocks.ESSENCE_BLOCK);
                    output.accept(ModBlocks.ETHER_ORE);
                    output.accept(ModBlocks.AURORA_CRYSTAL_BLOCK);
                    output.accept(ModBlocks.PORTAL_FRAME);
                    output.accept(ModItems.CELESTIAL_ESSENCE);
                    output.accept(ModItems.AURORA_CRYSTAL);
                    output.accept(ModItems.ETHER_SHARD);
                    output.accept(ModItems.DIVINE_INGOT);
                    output.accept(ModItems.SOLAR_FRAGMENT);
                    output.accept(ModItems.DRAGON_SCALE);
                    output.accept(ModItems.DRAGON_HEART);
                    output.accept(ModBlocks.DRAGON_ALTAR);
                    output.accept(ModBlocks.CELESTIAL_SAPLING);
                    output.accept(ModBlocks.GRASS_TUFT);
                    output.accept(ModBlocks.GLOW_FERN);
                    output.accept(ModBlocks.AZURE_BLOOM);
                    output.accept(ModBlocks.SUN_LILY);
                    output.accept(ModBlocks.AETHER_ORCHID);
                    output.accept(ModBlocks.CLOUD_COTTON);
                    output.accept(ModBlocks.CRYSTAL_SPROUT);
                    output.accept(ModBlocks.MOON_TULIP);
                    output.accept(ModEquipment.CELESTIAL_SWORD);
                    output.accept(ModEquipment.ETHER_DAGGER);
                    output.accept(ModEquipment.LIGHT_BOW);
                    output.accept(ModEquipment.CELESTIAL_PICKAXE);
                    output.accept(ModEquipment.CELESTIAL_AXE);
                    output.accept(ModEquipment.CELESTIAL_SHOVEL);
                    output.accept(ModEquipment.CELESTIAL_HOE);
                    output.accept(ModEquipment.AURORA_HELMET);
                    output.accept(ModEquipment.AURORA_CHESTPLATE);
                    output.accept(ModEquipment.AURORA_LEGGINGS);
                    output.accept(ModEquipment.AURORA_BOOTS);
                    output.accept(ModEquipment.DIVINE_HELMET);
                    output.accept(ModEquipment.DIVINE_CHESTPLATE);
                    output.accept(ModEquipment.DIVINE_LEGGINGS);
                    output.accept(ModEquipment.DIVINE_BOOTS);
                    ModSpawnEggs.EGGS.values().forEach(output::accept);
                })
                .build();
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, key, tab);
    }

    private ModCreativeTab() {
    }
}
