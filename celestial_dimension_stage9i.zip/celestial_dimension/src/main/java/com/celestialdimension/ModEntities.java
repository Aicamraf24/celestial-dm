package com.celestialdimension;

import com.celestialdimension.entity.CelestialDragon;
import com.celestialdimension.entity.CelestialGriffin;
import com.celestialdimension.entity.CelestialHarpy;
import com.celestialdimension.entity.CloudSpirit;
import com.celestialdimension.entity.CrystalGolem;
import com.celestialdimension.entity.GuardianAngel;
import com.celestialdimension.entity.Livestock;
import com.celestialdimension.entity.LuminousDeer;
import com.celestialdimension.entity.SkySerpent;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;

public final class ModEntities {
    public static final EntityType<GuardianAngel> GUARDIAN_ANGEL = reg("guardian_angel",
            EntityType.Builder.<GuardianAngel>of(GuardianAngel::new, MobCategory.CREATURE).sized(0.8f, 2.1f),
            GuardianAngel.attrs());
    public static final EntityType<CelestialGriffin> CELESTIAL_GRIFFIN = reg("celestial_griffin",
            EntityType.Builder.<CelestialGriffin>of(CelestialGriffin::new, MobCategory.CREATURE).sized(1.4f, 1.4f),
            CelestialGriffin.attrs());
    public static final EntityType<CelestialDragon> CELESTIAL_DRAGON = reg("celestial_dragon",
            EntityType.Builder.<CelestialDragon>of(CelestialDragon::new, MobCategory.MONSTER).sized(3.0f, 3.0f).fireImmune(),
            CelestialDragon.attrs());
    public static final EntityType<CloudSpirit> CLOUD_SPIRIT = reg("cloud_spirit",
            EntityType.Builder.<CloudSpirit>of(CloudSpirit::new, MobCategory.CREATURE).sized(0.6f, 1.0f),
            CloudSpirit.attrs());
    public static final EntityType<CrystalGolem> CRYSTAL_GOLEM = reg("crystal_golem",
            EntityType.Builder.<CrystalGolem>of(CrystalGolem::new, MobCategory.MONSTER).sized(1.4f, 2.8f),
            CrystalGolem.attrs());
    public static final EntityType<CelestialHarpy> CELESTIAL_HARPY = reg("celestial_harpy",
            EntityType.Builder.<CelestialHarpy>of(CelestialHarpy::new, MobCategory.MONSTER).sized(0.7f, 1.4f),
            CelestialHarpy.attrs());
    public static final EntityType<LuminousDeer> LUMINOUS_DEER = reg("luminous_deer",
            EntityType.Builder.<LuminousDeer>of(LuminousDeer::new, MobCategory.CREATURE).sized(0.9f, 1.9f),
            LuminousDeer.attrs());
    public static final EntityType<SkySerpent> SKY_SERPENT = reg("sky_serpent",
            EntityType.Builder.<SkySerpent>of(SkySerpent::new, MobCategory.MONSTER).sized(0.8f, 0.8f),
            SkySerpent.attrs());

    public static final EntityType<Livestock.Pig> CELESTIAL_PIG = reg("celestial_pig",
            EntityType.Builder.<Livestock.Pig>of(Livestock.Pig::new, MobCategory.CREATURE).sized(0.9f, 0.9f), Livestock.Pig.attrs());
    public static final EntityType<Livestock.Cow> CELESTIAL_COW = reg("celestial_cow",
            EntityType.Builder.<Livestock.Cow>of(Livestock.Cow::new, MobCategory.CREATURE).sized(0.9f, 1.4f), Livestock.Cow.attrs());
    public static final EntityType<Livestock.Sheep> CELESTIAL_SHEEP = reg("celestial_sheep",
            EntityType.Builder.<Livestock.Sheep>of(Livestock.Sheep::new, MobCategory.CREATURE).sized(0.9f, 1.3f), Livestock.Sheep.attrs());
    public static final EntityType<Livestock.Chicken> CELESTIAL_CHICKEN = reg("celestial_chicken",
            EntityType.Builder.<Livestock.Chicken>of(Livestock.Chicken::new, MobCategory.CREATURE).sized(0.4f, 0.7f), Livestock.Chicken.attrs());
    public static final EntityType<Livestock.Llama> CELESTIAL_LLAMA = reg("celestial_llama",
            EntityType.Builder.<Livestock.Llama>of(Livestock.Llama::new, MobCategory.CREATURE).sized(0.9f, 1.87f), Livestock.Llama.attrs());
    public static final EntityType<Livestock.Goat> CELESTIAL_GOAT = reg("celestial_goat",
            EntityType.Builder.<Livestock.Goat>of(Livestock.Goat::new, MobCategory.CREATURE).sized(0.9f, 1.3f), Livestock.Goat.attrs());
    public static final EntityType<Livestock.CloudManta> CLOUD_MANTA = reg("cloud_manta",
            EntityType.Builder.<Livestock.CloudManta>of(Livestock.CloudManta::new, MobCategory.CREATURE).sized(1.4f, 0.7f), Livestock.CloudManta.attrs());
    public static final EntityType<Livestock.Pegasus> CELESTIAL_PEGASUS = reg("celestial_pegasus",
            EntityType.Builder.<Livestock.Pegasus>of(Livestock.Pegasus::new, MobCategory.CREATURE).sized(1.4f, 1.9f)
                    .passengerAttachments(1.2f), Livestock.Pegasus.attrs());

    private static <T extends LivingEntity> EntityType<T> reg(String name, EntityType.Builder<T> builder,
                                                              AttributeSupplier.Builder attrs) {
        ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, CelestialDimension.id(name));
        EntityType<T> type = Registry.register(BuiltInRegistries.ENTITY_TYPE, key, builder.build(key));
        FabricDefaultAttributeRegistry.register(type, attrs);
        return type;
    }

    public static void init() {
    }

    private ModEntities() {
    }
}
