package com.celestialdimension;

import java.util.Map;
import java.util.function.Function;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;
import net.minecraft.world.level.block.Block;

/** Armaduras, armas y herramientas. Las habilidades estan en {@link ModAbilities}. */
public final class ModEquipment {
    public static final TagKey<Block> INCORRECT_FOR_CELESTIAL =
            TagKey.create(Registries.BLOCK, CelestialDimension.id("incorrect_for_celestial_tool"));
    public static final TagKey<Item> REPAIRS_CELESTIAL_TOOLS =
            TagKey.create(Registries.ITEM, CelestialDimension.id("repairs_celestial_tools"));
    public static final TagKey<Item> REPAIRS_AURORA_ARMOR =
            TagKey.create(Registries.ITEM, CelestialDimension.id("repairs_aurora_armor"));
    public static final TagKey<Item> REPAIRS_DIVINE_ARMOR =
            TagKey.create(Registries.ITEM, CelestialDimension.id("repairs_divine_armor"));

    public static final ToolMaterial CELESTIAL = new ToolMaterial(INCORRECT_FOR_CELESTIAL, 2000, 9.5f, 3.5f, 18,
            REPAIRS_CELESTIAL_TOOLS);

    public static final int AURORA_DURABILITY = 38;
    public static final int DIVINE_DURABILITY = 55;
    public static final ResourceKey<EquipmentAsset> AURORA_ASSET =
            ResourceKey.create(EquipmentAssets.ROOT_ID, CelestialDimension.id("aurora"));
    public static final ResourceKey<EquipmentAsset> DIVINE_ASSET =
            ResourceKey.create(EquipmentAssets.ROOT_ID, CelestialDimension.id("divine"));

    public static final ArmorMaterial AURORA_MATERIAL = new ArmorMaterial(AURORA_DURABILITY,
            Map.of(ArmorType.HELMET, 3, ArmorType.CHESTPLATE, 8, ArmorType.LEGGINGS, 6, ArmorType.BOOTS, 3),
            14, SoundEvents.ARMOR_EQUIP_DIAMOND, 2.0f, 0.0f, REPAIRS_AURORA_ARMOR, AURORA_ASSET);
    public static final ArmorMaterial DIVINE_MATERIAL = new ArmorMaterial(DIVINE_DURABILITY,
            Map.of(ArmorType.HELMET, 4, ArmorType.CHESTPLATE, 9, ArmorType.LEGGINGS, 7, ArmorType.BOOTS, 4),
            18, SoundEvents.ARMOR_EQUIP_NETHERITE, 4.0f, 0.1f, REPAIRS_DIVINE_ARMOR, DIVINE_ASSET);

    public static final Item CELESTIAL_SWORD = reg("celestial_sword", Item::new,
            new Item.Properties().sword(CELESTIAL, 3.0f, -2.4f));
    public static final Item ETHER_DAGGER = reg("ether_dagger", Item::new,
            new Item.Properties().sword(CELESTIAL, 1.0f, -1.6f));
    public static final Item CELESTIAL_PICKAXE = reg("celestial_pickaxe", Item::new,
            new Item.Properties().pickaxe(CELESTIAL, 1.0f, -2.8f));
    public static final Item CELESTIAL_AXE = reg("celestial_axe",
            p -> new AxeItem(CELESTIAL, 5.0f, -3.0f, p), new Item.Properties());
    public static final Item CELESTIAL_SHOVEL = reg("celestial_shovel",
            p -> new ShovelItem(CELESTIAL, 1.5f, -3.0f, p), new Item.Properties());
    public static final Item CELESTIAL_HOE = reg("celestial_hoe",
            p -> new HoeItem(CELESTIAL, -3.0f, 0.0f, p), new Item.Properties());
    public static final Item LIGHT_BOW = reg("light_bow", BowItem::new, new Item.Properties().durability(800));

    public static final Item AURORA_HELMET = reg("aurora_helmet", Item::new, new Item.Properties()
            .humanoidArmor(AURORA_MATERIAL, ArmorType.HELMET).durability(ArmorType.HELMET.getDurability(AURORA_DURABILITY)));
    public static final Item AURORA_CHESTPLATE = reg("aurora_chestplate", Item::new, new Item.Properties()
            .humanoidArmor(AURORA_MATERIAL, ArmorType.CHESTPLATE).durability(ArmorType.CHESTPLATE.getDurability(AURORA_DURABILITY)));
    public static final Item AURORA_LEGGINGS = reg("aurora_leggings", Item::new, new Item.Properties()
            .humanoidArmor(AURORA_MATERIAL, ArmorType.LEGGINGS).durability(ArmorType.LEGGINGS.getDurability(AURORA_DURABILITY)));
    public static final Item AURORA_BOOTS = reg("aurora_boots", Item::new, new Item.Properties()
            .humanoidArmor(AURORA_MATERIAL, ArmorType.BOOTS).durability(ArmorType.BOOTS.getDurability(AURORA_DURABILITY)));
    public static final Item DIVINE_HELMET = reg("divine_helmet", Item::new, new Item.Properties()
            .humanoidArmor(DIVINE_MATERIAL, ArmorType.HELMET).durability(ArmorType.HELMET.getDurability(DIVINE_DURABILITY)));
    public static final Item DIVINE_CHESTPLATE = reg("divine_chestplate", Item::new, new Item.Properties()
            .humanoidArmor(DIVINE_MATERIAL, ArmorType.CHESTPLATE).durability(ArmorType.CHESTPLATE.getDurability(DIVINE_DURABILITY)));
    public static final Item DIVINE_LEGGINGS = reg("divine_leggings", Item::new, new Item.Properties()
            .humanoidArmor(DIVINE_MATERIAL, ArmorType.LEGGINGS).durability(ArmorType.LEGGINGS.getDurability(DIVINE_DURABILITY)));
    public static final Item DIVINE_BOOTS = reg("divine_boots", Item::new, new Item.Properties()
            .humanoidArmor(DIVINE_MATERIAL, ArmorType.BOOTS).durability(ArmorType.BOOTS.getDurability(DIVINE_DURABILITY)));

    private static Item reg(String name, Function<Item.Properties, Item> factory, Item.Properties props) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, CelestialDimension.id(name));
        return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(props.setId(key)));
    }

    public static void init() {
    }

    private ModEquipment() {
    }
}
