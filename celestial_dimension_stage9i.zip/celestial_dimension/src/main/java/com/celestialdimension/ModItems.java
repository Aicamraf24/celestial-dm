package com.celestialdimension;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;

public final class ModItems {
    public static final Item CELESTIAL_ESSENCE = reg("celestial_essence");
    public static final Item AURORA_CRYSTAL = reg("aurora_crystal");
    public static final Item ETHER_SHARD = reg("ether_shard");
    public static final Item DIVINE_INGOT = reg("divine_ingot");
    public static final Item SOLAR_FRAGMENT = reg("solar_fragment");
    public static final Item DRAGON_SCALE = reg("dragon_scale");
    public static final Item DRAGON_HEART = reg("dragon_heart");

    private static Item reg(String name) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, CelestialDimension.id(name));
        return Registry.register(BuiltInRegistries.ITEM, key, new Item(new Item.Properties().setId(key)));
    }

    public static void init() {
    }

    private ModItems() {
    }
}
