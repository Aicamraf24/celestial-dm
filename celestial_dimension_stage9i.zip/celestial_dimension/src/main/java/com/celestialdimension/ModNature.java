package com.celestialdimension;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Polvo de hueso sobre el brote celestial. */
public final class ModNature {
    public static void init() {
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (!(level instanceof ServerLevel sl)) {
                return InteractionResult.PASS;
            }
            ItemStack stack = player.getItemInHand(hand);
            BlockPos pos = hit.getBlockPos();
            if (!stack.is(Items.BONE_MEAL) || !sl.getBlockState(pos).is(ModBlocks.CELESTIAL_SAPLING)) {
                return InteractionResult.PASS;
            }
            if (!player.isCreative()) {
                stack.shrink(1);
            }
            sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 8, 0.3, 0.3, 0.3, 0.0);
            if (sl.getRandom().nextFloat() < 0.45f) {
                CelestialSaplingBlock.grow(sl, pos, sl.getRandom());
            }
            return InteractionResult.SUCCESS;
        });
    }

    private ModNature() {
    }
}
