package com.celestialdimension;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Portal del Reino Celestial.
 * Marco: anillo de bloques portal_frame con interior libre de 2 de ancho x 3 de alto (sin esquinas).
 * Activacion: clic derecho sobre el marco con un Fragmento Solar.
 */
public final class ModPortal {
    public static final ResourceKey<Level> CELESTIAL =
            ResourceKey.create(Registries.DIMENSION, CelestialDimension.id("celestial"));

    private static final int ARRIVAL_Y = 110;
    private static final Map<UUID, BlockPos> ORIGIN = new HashMap<>();
    private static final Map<UUID, Integer> COOLDOWN = new HashMap<>();

    public static void init() {
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (!(level instanceof ServerLevel serverLevel)) {
                return InteractionResult.PASS;
            }
            ItemStack stack = player.getItemInHand(hand);
            if (!stack.is(ModItems.SOLAR_FRAGMENT)) {
                return InteractionResult.PASS;
            }
            BlockPos clicked = hit.getBlockPos();
            if (!serverLevel.getBlockState(clicked).is(ModBlocks.PORTAL_FRAME)) {
                return InteractionResult.PASS;
            }
            if (tryActivate(serverLevel, clicked)) {
                if (!player.isCreative()) {
                    stack.shrink(1);
                }
                return InteractionResult.SUCCESS;
            }
            return InteractionResult.PASS;
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                UUID id = player.getUUID();
                Integer cd = COOLDOWN.get(id);
                if (cd != null) {
                    if (cd <= 1) {
                        COOLDOWN.remove(id);
                    } else {
                        COOLDOWN.put(id, cd - 1);
                    }
                    continue;
                }
                ServerLevel level = (ServerLevel) player.level();
                BlockPos feet = player.blockPosition();
                if (level.getBlockState(feet).is(ModBlocks.CELESTIAL_PORTAL)
                        || level.getBlockState(feet.above()).is(ModBlocks.CELESTIAL_PORTAL)) {
                    travel(server.getLevel(CELESTIAL), level, player);
                }
            }
        });
    }

    // ---------- activacion ----------
    private static boolean tryActivate(ServerLevel level, BlockPos clicked) {
        for (Direction.Axis axis : new Direction.Axis[] {Direction.Axis.X, Direction.Axis.Z}) {
            Direction d = axis == Direction.Axis.X ? Direction.EAST : Direction.SOUTH;
            for (int a = -3; a <= 3; a++) {
                for (int b = -4; b <= 3; b++) {
                    BlockPos origin = clicked.relative(d, a).above(b);
                    if (validFrame(level, origin, d)) {
                        fillPortal(level, origin, d, axis);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /** origin = bloque interior inferior-izquierdo (menor coordenada en la direccion d). */
    private static boolean validFrame(ServerLevel level, BlockPos origin, Direction d) {
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 3; j++) {
                if (!level.getBlockState(origin.relative(d, i).above(j)).isAir()) {
                    return false;
                }
            }
            if (!isFrame(level, origin.relative(d, i).below())) return false;
            if (!isFrame(level, origin.relative(d, i).above(3))) return false;
        }
        for (int j = 0; j < 3; j++) {
            if (!isFrame(level, origin.relative(d, -1).above(j))) return false;
            if (!isFrame(level, origin.relative(d, 2).above(j))) return false;
        }
        return true;
    }

    private static boolean isFrame(ServerLevel level, BlockPos pos) {
        return level.getBlockState(pos).is(ModBlocks.PORTAL_FRAME);
    }

    private static void fillPortal(ServerLevel level, BlockPos origin, Direction d, Direction.Axis axis) {
        BlockState portal = ModBlocks.CELESTIAL_PORTAL.defaultBlockState().setValue(CelestialPortalBlock.AXIS, axis);
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 3; j++) {
                level.setBlock(origin.relative(d, i).above(j), portal, Block.UPDATE_ALL);
            }
        }
    }

    // ---------- viaje ----------
    private static void travel(ServerLevel celestial, ServerLevel current, ServerPlayer player) {
        if (celestial == null) {
            CelestialDimension.LOGGER.error("La dimension celestial_dimension:celestial no esta cargada");
            return;
        }
        UUID id = player.getUUID();
        COOLDOWN.put(id, 100);
        if (current.dimension().equals(CELESTIAL)) {
            ServerLevel overworld = celestial.getServer().getLevel(Level.OVERWORLD);
            BlockPos back = ORIGIN.get(id);
            if (back == null) {
                int y = overworld.getHeight(Heightmap.Types.MOTION_BLOCKING, 0, 0);
                back = new BlockPos(0, y, 0);
            }
            player.teleportTo(overworld, back.getX() + 0.5, back.getY(), back.getZ() + 0.5,
                    Set.of(), player.getYRot(), player.getXRot(), true);
        } else {
            ORIGIN.put(id, player.blockPosition());
            BlockPos base = new BlockPos(player.blockPosition().getX(), ARRIVAL_Y, player.blockPosition().getZ());
            buildArrival(celestial, base);
            player.teleportTo(celestial, base.getX() + 0.5, base.getY() + 1, base.getZ() + 3.5,
                    Set.of(), 180.0f, 0.0f, true);
        }
    }

    /** Plataforma de marmol 9x9 con un portal de regreso ya encendido. */
    private static void buildArrival(ServerLevel level, BlockPos base) {
        BlockState marble = ModBlocks.CELESTIAL_MARBLE.defaultBlockState();
        BlockState air = net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();
        for (int x = -4; x <= 4; x++) {
            for (int z = -4; z <= 4; z++) {
                level.setBlock(base.offset(x, 0, z), marble, Block.UPDATE_ALL);
                for (int y = 1; y <= 6; y++) {
                    level.setBlock(base.offset(x, y, z), air, Block.UPDATE_ALL);
                }
            }
        }
        BlockState frame = ModBlocks.PORTAL_FRAME.defaultBlockState();
        BlockPos origin = base.offset(0, 1, 0);
        Direction d = Direction.EAST;
        for (int i = 0; i < 2; i++) {
            level.setBlock(origin.relative(d, i).below(), frame, Block.UPDATE_ALL);
            level.setBlock(origin.relative(d, i).above(3), frame, Block.UPDATE_ALL);
        }
        for (int j = 0; j < 3; j++) {
            level.setBlock(origin.relative(d, -1).above(j), frame, Block.UPDATE_ALL);
            level.setBlock(origin.relative(d, 2).above(j), frame, Block.UPDATE_ALL);
        }
        fillPortal(level, origin, d, Direction.Axis.X);
    }

    private ModPortal() {
    }
}
