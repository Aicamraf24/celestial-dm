package com.celestialdimension;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;

/** Un huevo de aparicion por cada criatura del mod. */
public final class ModSpawnEggs {
    public static final Map<String, Item> EGGS = new LinkedHashMap<>();

    private static void egg(String name, EntityType<?> type) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, CelestialDimension.id(name + "_spawn_egg"));
        Item item = Registry.register(BuiltInRegistries.ITEM, key, new SpawnEggItem(new Item.Properties().setId(key).spawnEgg(type)));
        EGGS.put(name, item);
    }

    public static void init() {
        egg("guardian_angel", ModEntities.GUARDIAN_ANGEL);
        egg("celestial_griffin", ModEntities.CELESTIAL_GRIFFIN);
        egg("celestial_dragon", ModEntities.CELESTIAL_DRAGON);
        egg("cloud_spirit", ModEntities.CLOUD_SPIRIT);
        egg("crystal_golem", ModEntities.CRYSTAL_GOLEM);
        egg("celestial_harpy", ModEntities.CELESTIAL_HARPY);
        egg("luminous_deer", ModEntities.LUMINOUS_DEER);
        egg("sky_serpent", ModEntities.SKY_SERPENT);
        egg("celestial_pig", ModEntities.CELESTIAL_PIG);
        egg("celestial_cow", ModEntities.CELESTIAL_COW);
        egg("celestial_sheep", ModEntities.CELESTIAL_SHEEP);
        egg("celestial_chicken", ModEntities.CELESTIAL_CHICKEN);
        egg("celestial_llama", ModEntities.CELESTIAL_LLAMA);
        egg("celestial_goat", ModEntities.CELESTIAL_GOAT);
        egg("cloud_manta", ModEntities.CLOUD_MANTA);
        egg("celestial_pegasus", ModEntities.CELESTIAL_PEGASUS);
    }

    private ModSpawnEggs() {
    }
}
