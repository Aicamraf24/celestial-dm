package com.celestialdimension;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/** Mensajes sobre la barra de acciones (en 26.1 displayClientMessage se dividio en sendOverlayMessage). */
public final class Msg {
    public static void overlay(Player player, String translationKey) {
        if (player instanceof ServerPlayer sp) {
            sp.sendOverlayMessage(Component.translatable(translationKey));
        }
    }

    private Msg() {
    }
}
