package com.celestialdimension;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

/** Planta decorativa: se rompe sola si pierde el suelo y puede emitir particulas de luz. */
public class PlantBlock extends Block {
    private final ParticleOptions particle;

    public PlantBlock(BlockBehaviour.Properties properties, ParticleOptions particle) {
        super(properties);
        this.particle = particle;
    }

    @Override
    protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (level.getBlockState(pos.below()).isAir()) {
            level.destroyBlock(pos, true);
        }
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (particle != null && random.nextInt(8) == 0) {
            level.addParticle(particle, pos.getX() + 0.2 + random.nextDouble() * 0.6, pos.getY() + 0.3 + random.nextDouble() * 0.5,
                    pos.getZ() + 0.2 + random.nextDouble() * 0.6, 0.0, 0.015, 0.0);
        }
    }
}
