package com.celestialdimension.client;

import com.celestialdimension.CelestialDimension;
import com.celestialdimension.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;

public class CelestialDimensionClient implements ClientModInitializer {
    public static ModelLayerLocation layer(String name) {
        return new ModelLayerLocation(CelestialDimension.id(name), "main");
    }

    private static <T extends Mob> void reg(EntityType<T> type, String name, float shadow, float scale) {
        ModelLayerRegistry.registerModelLayer(layer(name), () -> CreatureModels.layer(name));
        EntityRenderers.register(type, ctx -> new CelestialRenderer<T>(ctx, name, shadow, scale));
    }

    @Override
    public void onInitializeClient() {
        reg(ModEntities.GUARDIAN_ANGEL, "guardian_angel", 0.5f, 1.0f);
        reg(ModEntities.CELESTIAL_GRIFFIN, "celestial_griffin", 0.8f, 1.0f);
        reg(ModEntities.CELESTIAL_DRAGON, "celestial_dragon", 2.5f, 2.2f);
        reg(ModEntities.CLOUD_SPIRIT, "cloud_spirit", 0.3f, 1.0f);
        reg(ModEntities.CRYSTAL_GOLEM, "crystal_golem", 0.9f, 1.0f);
        reg(ModEntities.CELESTIAL_HARPY, "celestial_harpy", 0.4f, 1.0f);
        reg(ModEntities.LUMINOUS_DEER, "luminous_deer", 0.6f, 1.0f);
        reg(ModEntities.SKY_SERPENT, "sky_serpent", 0.4f, 1.2f);
        reg(ModEntities.CELESTIAL_PIG, "celestial_pig", 0.5f, 1.0f);
        reg(ModEntities.CELESTIAL_COW, "celestial_cow", 0.7f, 1.0f);
        reg(ModEntities.CELESTIAL_SHEEP, "celestial_sheep", 0.6f, 1.0f);
        reg(ModEntities.CELESTIAL_CHICKEN, "celestial_chicken", 0.3f, 1.0f);
        reg(ModEntities.CELESTIAL_LLAMA, "celestial_llama", 0.7f, 1.0f);
        reg(ModEntities.CELESTIAL_GOAT, "celestial_goat", 0.5f, 1.0f);
        reg(ModEntities.CLOUD_MANTA, "cloud_manta", 0.5f, 1.0f);
        reg(ModEntities.CELESTIAL_PEGASUS, "celestial_pegasus", 0.8f, 1.1f);

        // TODO: registrar las capas de render CUTOUT (hojas y plantas) cuando se confirme el nombre de la API en Fabric API 26.1.2.
    }
}
