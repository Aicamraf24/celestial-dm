package com.celestialdimension.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class CelestialRenderState extends LivingEntityRenderState {
    public boolean flying;
    public float attack;
}
