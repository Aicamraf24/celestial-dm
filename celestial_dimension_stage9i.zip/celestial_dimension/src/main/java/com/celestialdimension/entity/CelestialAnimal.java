package com.celestialdimension.entity;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.BreedGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowParentGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.TemptGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;

/** Base de los animales celestiales: cria, tentacion con comida natural y aparicion sobre suelo firme. */
public abstract class CelestialAnimal extends Animal implements CelestialCreature {
    protected CelestialAnimal(EntityType<? extends CelestialAnimal> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder attrs(double health, double speed) {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, health)
                .add(Attributes.MOVEMENT_SPEED, speed)
                .add(Attributes.FLYING_SPEED, speed * 1.4)
                .add(Attributes.TEMPT_RANGE, 10.0);
    }

    /** Comida con la que se cria y que los atrae. */
    protected abstract boolean isFoodItem(ItemStack stack);

    @Override
    public boolean isFood(ItemStack stack) {
        return isFoodItem(stack);
    }

    protected boolean airborne() {
        return false;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.4));
        this.goalSelector.addGoal(2, new BreedGoal(this, 1.0));
        this.goalSelector.addGoal(3, new TemptGoal(this, 1.1, this::isFood, false));
        this.goalSelector.addGoal(4, new FollowParentGoal(this, 1.1));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 6.0f));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    @Override
    @SuppressWarnings("unchecked")
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob partner) {
        EntityType<? extends AgeableMob> type = (EntityType<? extends AgeableMob>) this.getType();
        return type.create(level, EntitySpawnReason.BREEDING);
    }

    /** Los animales terrestres solo aparecen sobre un bloque solido (no en el aire). */
    @Override
    public boolean checkSpawnRules(LevelAccessor level, EntitySpawnReason spawnReason) {
        if (airborne() || spawnReason != EntitySpawnReason.NATURAL) {
            return true;
        }
        BlockState below = level.getBlockState(this.blockPosition().below());
        return !below.isAir() && below.getFluidState().isEmpty();
    }

    @Override
    public boolean isFlyingNow() {
        return airborne() && !onGround();
    }
}
