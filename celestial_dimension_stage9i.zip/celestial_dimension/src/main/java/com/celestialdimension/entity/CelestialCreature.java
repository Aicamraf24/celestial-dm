package com.celestialdimension.entity;

/** Marca comun para el renderizador generico. */
public interface CelestialCreature {
    default boolean isFlyingNow() {
        return false;
    }
}
