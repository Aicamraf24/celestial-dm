package com.celestialdimension.entity;

import com.celestialdimension.ModEntities;
import com.celestialdimension.Msg;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Jefe final. Fase 1 (&gt;66% vida): suelo, rayos de energia y mordiscos.
 * Fase 2 (33-66%): alterna vuelo con picados y lluvia de energia con aterrizajes con onda de choque; invoca arpias.
 * Fase 3 (&lt;33%): furia: ataques mas rapidos, mas invocaciones.
 */
public class CelestialDragon extends Monster implements CelestialCreature {
    private final ServerBossEvent bossEvent = new ServerBossEvent(UUID.randomUUID(),
            Component.translatable("entity.celestial_dimension.celestial_dragon"),
            BossEvent.BossBarColor.BLUE, BossEvent.BossBarOverlay.PROGRESS);

    private int phase = 1;
    private boolean airborne = false;
    private boolean wasAirborne = false;
    private int modeTimer = 200;
    private int beamCooldown = 80;
    private int beamCharge = 0;
    private int biteCooldown = 0;
    private int summonCooldown = 200;
    private int slamCooldown = 60;
    private int rainCooldown = 70;

    public CelestialDragon(EntityType<? extends CelestialDragon> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder attrs() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 400.0)
                .add(Attributes.ATTACK_DAMAGE, 14.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.FLYING_SPEED, 0.6)
                .add(Attributes.ARMOR, 8.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.FOLLOW_RANGE, 64.0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2, true));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 32.0f));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public boolean isFlyingNow() {
        return airborne || !onGround();
    }

    @Override
    public boolean removeWhenFarAway(double distanceSq) {
        return false;
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        super.remove(reason);
        bossEvent.removeAllPlayers();
    }

    @Override
    protected void checkFallDamage(double y, boolean onGround, BlockState state, BlockPos pos) {
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!(level() instanceof ServerLevel sl)) {
            return;
        }
        if (tickCount % 5 == 0) {
            bossEvent.setProgress(Mth.clamp(getHealth() / getMaxHealth(), 0.0f, 1.0f));
        }
        updatePhase(sl);
        if (biteCooldown > 0) biteCooldown--;
        if (beamCooldown > 0) beamCooldown--;
        if (summonCooldown > 0) summonCooldown--;
        if (slamCooldown > 0) slamCooldown--;
        if (rainCooldown > 0) rainCooldown--;

        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) {
            airborne = false;
            setNoGravity(false);
            return;
        }

        if (phase >= 2) {
            if (--modeTimer <= 0) {
                airborne = !airborne;
                modeTimer = airborne ? (phase == 2 ? 240 : 180) : (phase == 2 ? 140 : 100);
            }
        } else {
            airborne = false;
        }

        if (airborne) {
            flyTick(sl, target);
        } else {
            setNoGravity(false);
            if (wasAirborne && onGround()) {
                slam(sl, 9.0, 10.0f);
            }
            if (phase >= 2 && slamCooldown <= 0 && onGround()) {
                slam(sl, 8.0, 8.0f);
                slamCooldown = phase == 3 ? 80 : 130;
            }
        }
        wasAirborne = airborne;

        beamTick(sl, target);

        if (phase >= 2 && summonCooldown <= 0) {
            summonHelpers(sl, phase == 3 ? 3 : 2);
            summonCooldown = phase == 3 ? 300 : 420;
        }
    }

    private void updatePhase(ServerLevel sl) {
        float r = getHealth() / getMaxHealth();
        int p = r > 0.66f ? 1 : (r > 0.33f ? 2 : 3);
        if (p != phase) {
            phase = p;
            modeTimer = 20;
            for (Player pl : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(64.0))) {
                Msg.overlay(pl, "message.celestial_dimension.dragon_phase_" + p);
            }
            sl.sendParticles(ParticleTypes.FIREWORK, getX(), getY() + 3.0, getZ(), 60, 3.0, 2.0, 3.0, 0.2);
            summonHelpers(sl, 2);
        }
    }

    private void flyTick(ServerLevel sl, LivingEntity target) {
        setNoGravity(true);
        getNavigation().stop();
        boolean dive = (tickCount % 140) > 100;
        double ang = tickCount * 0.035;
        Vec3 dest = dive
                ? target.position().add(0, 1.0, 0)
                : target.position().add(Math.cos(ang) * 14.0, 9.0, Math.sin(ang) * 14.0);
        double speed = dive ? 1.0 : 0.5;
        Vec3 d = dest.subtract(position());
        double len = d.length();
        if (len > 0.8) {
            Vec3 v = d.scale(speed / len);
            setDeltaMovement(getDeltaMovement().scale(0.85).add(v.scale(0.15)));
        }
        float yaw = (float) (Mth.atan2(target.getZ() - getZ(), target.getX() - getX()) * Mth.RAD_TO_DEG) - 90.0f;
        setYRot(yaw);
        setYBodyRot(yaw);
        setYHeadRot(yaw);
        if (biteCooldown <= 0 && distanceToSqr(target) < 20.0) {
            target.hurtServer(sl, sl.damageSources().mobAttack(this), (float) getAttributeValue(Attributes.ATTACK_DAMAGE));
            biteCooldown = 20;
        }
        if (rainCooldown <= 0 && !dive) {
            energyRain(sl, target);
            rainCooldown = phase == 3 ? 45 : 70;
        }
    }

    private void beamTick(ServerLevel sl, LivingEntity target) {
        if (beamCharge > 0) {
            beamCharge--;
            Vec3 head = headPos();
            sl.sendParticles(ParticleTypes.END_ROD, head.x, head.y, head.z, 4, 0.4, 0.4, 0.4, 0.02);
            if (beamCharge == 0 && target.isAlive()) {
                fireBeam(sl, target);
            }
            return;
        }
        if (beamCooldown <= 0 && distanceToSqr(target) < 40.0 * 40.0 && hasLineOfSight(target)) {
            beamCharge = 30;
            beamCooldown = phase == 1 ? 130 : (phase == 2 ? 100 : 70);
        }
    }

    private Vec3 headPos() {
        Vec3 look = getLookAngle();
        return position().add(0, 2.6, 0).add(look.scale(3.0));
    }

    private void fireBeam(ServerLevel sl, LivingEntity target) {
        Vec3 from = headPos();
        Vec3 to = target.position().add(0, target.getBbHeight() * 0.6, 0);
        Vec3 dir = to.subtract(from);
        int steps = Math.max(1, (int) dir.length());
        Vec3 step = dir.scale(1.0 / steps);
        for (int i = 0; i < steps; i++) {
            Vec3 p = from.add(step.scale(i));
            sl.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 0.05, 0.05, 0.05, 0.0);
        }
        float dmg = phase == 1 ? 8.0f : (phase == 2 ? 10.0f : 12.0f);
        target.hurtServer(sl, sl.damageSources().mobAttack(this), dmg);
    }

    private void energyRain(ServerLevel sl, LivingEntity target) {
        for (int i = 0; i < 3; i++) {
            double cx = target.getX() + (random.nextDouble() - 0.5) * 8.0;
            double cz = target.getZ() + (random.nextDouble() - 0.5) * 8.0;
            for (int y = 0; y < 10; y++) {
                sl.sendParticles(ParticleTypes.END_ROD, cx, target.getY() + y, cz, 1, 0.1, 0.0, 0.1, 0.0);
            }
            sl.sendParticles(ParticleTypes.FIREWORK, cx, target.getY() + 0.2, cz, 8, 0.6, 0.1, 0.6, 0.05);
            AABBHelper.damageAround(sl, this, cx, target.getY(), cz, 2.0, 7.0f);
        }
    }

    private void slam(ServerLevel sl, double radius, float dmg) {
        sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.3, getZ(), 6, radius * 0.4, 0.2, radius * 0.4, 0.0);
        sl.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 0.3, getZ(), 40, radius * 0.5, 0.2, radius * 0.5, 0.15);
        List<LivingEntity> list = sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(radius, 3.0, radius),
                e -> e != this && !(e instanceof CelestialCreature));
        for (LivingEntity e : list) {
            e.hurtServer(sl, sl.damageSources().mobAttack(this), dmg);
            Vec3 away = e.position().subtract(position()).multiply(1, 0, 1).normalize();
            e.push(away.x * 1.2, 0.6, away.z * 1.2);
        }
    }

    private void summonHelpers(ServerLevel sl, int count) {
        int near = sl.getEntitiesOfClass(CelestialHarpy.class, getBoundingBox().inflate(40.0)).size();
        for (int i = 0; i < count && near < 5; i++, near++) {
            CelestialHarpy h = ModEntities.CELESTIAL_HARPY.create(sl, EntitySpawnReason.MOB_SUMMONED);
            if (h != null) {
                h.setPos(getX() + (random.nextDouble() - 0.5) * 8.0, getY() + 4.0, getZ() + (random.nextDouble() - 0.5) * 8.0);
                h.setTarget(getTarget());
                sl.addFreshEntity(h);
                sl.sendParticles(ParticleTypes.POOF, h.getX(), h.getY(), h.getZ(), 10, 0.3, 0.3, 0.3, 0.02);
            }
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENDER_DRAGON_GROWL;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENDER_DRAGON_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENDER_DRAGON_DEATH;
    }

    /** Dano en area simple sin depender de clases de proyectiles. */
    private static final class AABBHelper {
        static void damageAround(ServerLevel sl, LivingEntity src, double x, double y, double z, double r, float dmg) {
            List<Player> list = sl.getEntitiesOfClass(Player.class,
                    new net.minecraft.world.phys.AABB(x - r, y - 1, z - r, x + r, y + 3, z + r));
            for (Player p : list) {
                p.hurtServer(sl, sl.damageSources().mobAttack(src), dmg);
            }
        }
    }
}
