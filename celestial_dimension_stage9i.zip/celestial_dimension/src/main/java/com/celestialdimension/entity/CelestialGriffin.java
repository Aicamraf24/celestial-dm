package com.celestialdimension.entity;

import com.celestialdimension.ModItems;
import java.util.EnumSet;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

/** Grifo voladora. Se domestica con Esencia Celestial; domesticado sigue y defiende a su dueno. */
public class CelestialGriffin extends PathfinderMob implements CelestialCreature {
    private String ownerId = "";

    public CelestialGriffin(EntityType<? extends CelestialGriffin> type, Level level) {
        super(type, level);
        this.moveControl = new FlyingMoveControl(this, 20, true);
    }

    public static AttributeSupplier.Builder attrs() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0)
                .add(Attributes.ATTACK_DAMAGE, 6.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.FLYING_SPEED, 0.5)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    public boolean isTamed() {
        return !ownerId.isEmpty();
    }

    private Player owner() {
        if (ownerId.isEmpty()) {
            return null;
        }
        try {
            return level().getPlayerByUUID(UUID.fromString(ownerId));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        return Ai.flyingNav(this, level);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2, true));
        this.goalSelector.addGoal(2, new FollowOwnerGoal(this));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomFlyingGoal(this, 1.0));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 8.0f));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!level().isClientSide() && isTamed() && getTarget() == null && tickCount % 10 == 0) {
            Player o = owner();
            if (o != null) {
                LivingEntity t = o.getLastHurtByMob();
                if (t == null) {
                    t = o.getLastHurtMob();
                }
                if (t != null && t != this && t.isAlive()) {
                    setTarget(t);
                }
            }
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!isTamed() && stack.is(ModItems.CELESTIAL_ESSENCE)) {
            if (level() instanceof ServerLevel sl) {
                if (!player.isCreative()) {
                    stack.shrink(1);
                }
                if (this.random.nextInt(3) == 0) {
                    ownerId = player.getUUID().toString();
                    setTarget(null);
                    sl.sendParticles(ParticleTypes.HEART, getX(), getY() + 1.2, getZ(), 7, 0.4, 0.4, 0.4, 0.02);
                } else {
                    sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 1.2, getZ(), 7, 0.4, 0.4, 0.4, 0.02);
                }
            }
            return InteractionResult.SUCCESS;
        }
        return super.mobInteract(player, hand);
    }

    @Override
    protected void addAdditionalSaveData(ValueOutput out) {
        super.addAdditionalSaveData(out);
        out.putString("Owner", ownerId);
    }

    @Override
    protected void readAdditionalSaveData(ValueInput in) {
        super.readAdditionalSaveData(in);
        ownerId = in.getString("Owner").orElse("");
    }

    @Override
    protected void checkFallDamage(double y, boolean onGround, BlockState state, BlockPos pos) {
    }

    @Override
    public boolean isFlyingNow() {
        return !onGround();
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.PARROT_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PARROT_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.PARROT_DEATH;
    }

    private static class FollowOwnerGoal extends Goal {
        private final CelestialGriffin griffin;

        FollowOwnerGoal(CelestialGriffin griffin) {
            this.griffin = griffin;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            Player o = griffin.owner();
            return o != null && griffin.getTarget() == null && griffin.distanceToSqr(o) > 64.0;
        }

        @Override
        public boolean canContinueToUse() {
            Player o = griffin.owner();
            return o != null && griffin.getTarget() == null && griffin.distanceToSqr(o) > 16.0;
        }

        @Override
        public void tick() {
            Player o = griffin.owner();
            if (o != null) {
                griffin.getNavigation().moveTo(o, 1.3);
            }
        }
    }
}
