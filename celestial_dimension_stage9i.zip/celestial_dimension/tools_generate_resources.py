import os, json, random, zlib, struct

ROOT = "/home/claude/cd/celestial_dimension"
NS = "celestial_dimension"
RES = f"{ROOT}/src/main/resources"
AS = f"{RES}/assets/{NS}"
DT = f"{RES}/data/{NS}"

def w(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)

def wj(path, obj):
    w(path, json.dumps(obj, indent=2, ensure_ascii=False) + "\n")

def png(path, size, px):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    w_, h_ = size
    raw = b""
    for y in range(h_):
        raw += b"\x00" + b"".join(bytes(px[y][x]) for x in range(w_))
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    data = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w_, h_, 8, 6, 0, 0, 0))
    data += chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")
    with open(path, "wb") as f:
        f.write(data)

def clamp(v): return max(0, min(255, int(v)))
def shade(c, d): return (clamp(c[0]+d), clamp(c[1]+d), clamp(c[2]+d), 255)

def base(color, seed, var=14, n=16):
    r = random.Random(seed)
    return [[shade(color, r.randint(-var, var)) for _ in range(n)] for _ in range(n)]

def bricks(color, mortar, seed):
    px = base(color, seed, 10)
    for y in range(16):
        for x in range(16):
            row = y // 4
            if y % 4 == 3: px[y][x] = shade(mortar, 0)
            elif (x + (4 if row % 2 else 0)) % 8 == 7: px[y][x] = shade(mortar, 0)
    return px

def tiles(color, trim, seed):
    px = base(color, seed, 8)
    for i in range(16):
        for k in (0, 15, 7, 8):
            px[k][i] = shade(trim, 0); px[i][k] = shade(trim, 0)
    return px

def planks(color, seed):
    px = base(color, seed, 8)
    for y in range(16):
        for x in range(16):
            if y % 4 == 3: px[y][x] = shade(color, -35)
    return px

def log_side(color, seed):
    r = random.Random(seed)
    px = base(color, seed, 6)
    for x in range(16):
        d = r.randint(-25, 10) if x % 3 == 0 else 0
        for y in range(16): px[y][x] = shade(px[y][x][:3], d)
    return px

def log_top(color, ring, seed):
    px = base(color, seed, 6)
    for y in range(16):
        for x in range(16):
            d = max(abs(x-7.5), abs(y-7.5))
            if int(d) % 3 == 2: px[y][x] = shade(ring, 0)
            if d > 6.5: px[y][x] = shade(ring, -20)
    return px

def leaves(color, seed):
    r = random.Random(seed)
    px = base(color, seed, 20)
    for _ in range(30):
        px[r.randint(0,15)][r.randint(0,15)] = shade(color, 45)
    return px

def crystal(color, seed, glow=0):
    px = base(color, seed, 10)
    for y in range(16):
        for x in range(16):
            s = (x + y) % 8
            if s in (0, 1): px[y][x] = shade(color, 55 + glow)
            elif s == 4: px[y][x] = shade(color, -30)
            if x in (0, 15) or y in (0, 15): px[y][x] = shade(color, -45)
    return px

def cloud(seed):
    r = random.Random(seed)
    px = base((245, 248, 255), seed, 6)
    for _ in range(12):
        cx, cy = r.randint(0,15), r.randint(0,15)
        for dy in range(-2, 3):
            for dx in range(-2, 3):
                if dx*dx+dy*dy <= 4:
                    px[(cy+dy)%16][(cx+dx)%16] = shade((255, 255, 255), -r.randint(0, 8))
    return px

def ore(stone, spot, seed):
    r = random.Random(seed)
    px = base(stone, seed, 12)
    for _ in range(5):
        cx, cy = r.randint(2,13), r.randint(2,13)
        for dx, dy in ((0,0),(1,0),(0,1),(1,1)):
            px[cy+dy][cx+dx] = shade(spot, r.randint(-10, 25))
    return px

def grass_top(seed):
    r = random.Random(seed)
    px = base((96, 170, 200), seed, 14)
    for _ in range(18): px[r.randint(0,15)][r.randint(0,15)] = shade((150, 225, 245), 0)
    return px

def grass_side(seed):
    px = base((126, 98, 82), seed, 12)
    r = random.Random(seed+1)
    for x in range(16):
        h = 3 + r.randint(0, 2)
        for y in range(h): px[y][x] = shade((96, 170, 200), r.randint(-14, 14))
    return px

def item_icon(kind, color, seed):
    px = [[(0,0,0,0) for _ in range(16)] for _ in range(16)]
    r = random.Random(seed)
    if kind == "gem":
        pts = [(8,2),(6,4),(10,4),(5,6),(11,6),(4,8),(12,8),(5,10),(11,10),(6,12),(10,12),(7,14),(9,14),(8,13)]
        for y in range(2, 15):
            half = min(y-1, 14-y, 5)
            for x in range(8-half, 8+half):
                px[y][x] = shade(color, 30 - (x-8+half)*6 + r.randint(-6, 6))
        px[5][6] = shade(color, 90); px[6][7] = shade(color, 80)
    elif kind == "ingot":
        for y in range(5, 12):
            for x in range(2, 14):
                d = 35 if y == 5 else (-35 if y == 11 else r.randint(-8, 8))
                px[y][x] = shade(color, d)
        for x in range(4, 8): px[7][x] = shade(color, 70)
    elif kind == "orb":
        for y in range(16):
            for x in range(16):
                d = ((x-7.5)**2 + (y-7.5)**2) ** 0.5
                if d < 5.5: px[y][x] = shade(color, int(60 - d*14) + r.randint(-5,5))
        px[5][5] = shade(color, 110)
    elif kind == "shard":
        for i in range(12):
            for t in range(3):
                x, y = 3+i, 13-i
                if 0 <= x+t < 16: px[y][x+t] = shade(color, 40 - t*30 + r.randint(-5, 5))
    return px

def icon_mod():
    n = 128
    px = [[(0,0,0,255) for _ in range(n)] for _ in range(n)]
    for y in range(n):
        for x in range(n):
            t = y / n
            px[y][x] = (clamp(110+90*t), clamp(180+60*t), 255, 255)
    r = random.Random(7)
    for _ in range(14):
        cx, cy, rad = r.randint(10,118), r.randint(90,120), r.randint(6,14)
        for y in range(n):
            for x in range(n):
                if (x-cx)**2 + ((y-cy)*1.6)**2 < rad*rad: px[y][x] = (255,255,255,255)
    # floating island
    for y in range(40, 84):
        half = int(34 * (1 - abs(y-52)/40)) if y > 52 else 34
        if y > 52: half = int(34 * (1 - (y-52)/34))
        for x in range(64-half, 64+half):
            if 0 <= x < n:
                px[y][x] = (96,170,200,255) if y < 48 else (126,98,82,255)
    # crystal
    for y in range(14, 46):
        half = (46 - y) // 4 + (1 if y > 20 else 0)
        if y < 20: half = (y-14)//2
        for x in range(64-half, 64+half+1):
            px[y][x] = (190, 120, 255, 255) if x >= 64 else (150, 90, 235, 255)
    return px

# ---------------- texturas ----------------
BLOCK_TEX = {
 "celestial_dirt": base((126, 98, 82), 1),
 "celestial_stone": base((150, 160, 180), 2),
 "ancient_stone": base((110, 112, 130), 3, 18),
 "celestial_marble": base((238, 240, 248), 4, 7),
 "celestial_bricks": bricks((222, 226, 240), (150, 160, 190), 5),
 "azure_crystal_glass": crystal((110, 190, 255), 6),
 "luminous_crystal": crystal((120, 255, 235), 7, 30),
 "sacred_crystal": crystal((255, 235, 140), 8, 30),
 "solid_cloud": cloud(9),
 "celestial_planks": planks((205, 175, 120), 10),
 "celestial_log": log_side((150, 120, 90), 11),
 "celestial_log_top": log_top((205, 175, 120), (150, 120, 90), 12),
 "celestial_leaves": leaves((90, 190, 170), 13),
 "luminous_flower_block": crystal((255, 140, 230), 14, 20),
 "celestial_sand": base((240, 228, 190), 15, 10),
 "temple_tiles": tiles((215, 205, 160), (190, 150, 60), 16),
 "ruin_bricks": bricks((120, 125, 140), (70, 75, 90), 17),
 "essence_ore": ore((150, 160, 180), (255, 245, 170), 18),
 "essence_block": crystal((255, 245, 170), 19, 25),
 "ether_ore": ore((150, 160, 180), (180, 110, 255), 20),
 "aurora_crystal_block": crystal((90, 235, 255), 21, 20),
 "portal_frame": tiles((90, 110, 190), (255, 225, 120), 22),
 "celestial_grass_top": grass_top(23),
 "celestial_grass_side": grass_side(24),
}
for n, px in BLOCK_TEX.items():
    png(f"{AS}/textures/block/{n}.png", (16, 16), px)

ITEM_TEX = {
 "celestial_essence": ("orb", (255, 240, 150)),
 "aurora_crystal": ("gem", (90, 235, 255)),
 "ether_shard": ("shard", (180, 110, 255)),
 "divine_ingot": ("ingot", (255, 215, 90)),
 "solar_fragment": ("shard", (255, 150, 60)),
}
for i, (n, (k, c)) in enumerate(ITEM_TEX.items()):
    png(f"{AS}/textures/item/{n}.png", (16, 16), item_icon(k, c, 100+i))

png(f"{RES}/assets/{NS}/icon.png", (128, 128), icon_mod())

# ---------------- bloques: modelos / estados / items ----------------
CUBE_ALL = ["celestial_dirt","celestial_stone","ancient_stone","celestial_marble","celestial_bricks",
 "azure_crystal_glass","luminous_crystal","sacred_crystal","solid_cloud","celestial_planks",
 "celestial_leaves","luminous_flower_block","celestial_sand","temple_tiles","ruin_bricks",
 "essence_ore","essence_block","ether_ore","aurora_crystal_block","portal_frame"]
ALL_BLOCKS = CUBE_ALL + ["celestial_log", "celestial_grass"]

for b in CUBE_ALL:
    wj(f"{AS}/blockstates/{b}.json", {"variants": {"": {"model": f"{NS}:block/{b}"}}})
    wj(f"{AS}/models/block/{b}.json", {"parent": "minecraft:block/cube_all", "textures": {"all": f"{NS}:block/{b}"}})
# tronco
wj(f"{AS}/blockstates/celestial_log.json", {"variants": {
  "axis=y": {"model": f"{NS}:block/celestial_log"},
  "axis=z": {"model": f"{NS}:block/celestial_log", "x": 90},
  "axis=x": {"model": f"{NS}:block/celestial_log", "x": 90, "y": 90}}})
wj(f"{AS}/models/block/celestial_log.json", {"parent": "minecraft:block/cube_column",
  "textures": {"end": f"{NS}:block/celestial_log_top", "side": f"{NS}:block/celestial_log"}})
# césped
wj(f"{AS}/blockstates/celestial_grass.json", {"variants": {"": {"model": f"{NS}:block/celestial_grass"}}})
wj(f"{AS}/models/block/celestial_grass.json", {"parent": "minecraft:block/cube_bottom_top",
  "textures": {"top": f"{NS}:block/celestial_grass_top", "side": f"{NS}:block/celestial_grass_side",
               "bottom": f"{NS}:block/celestial_dirt"}})
for b in ALL_BLOCKS:
    wj(f"{AS}/items/{b}.json", {"model": {"type": "minecraft:model", "model": f"{NS}:block/{b}"}})
    wj(f"{DT}/loot_table/blocks/{b}.json", {"type": "minecraft:block", "pools": [{"rolls": 1,
      "conditions": [{"condition": "minecraft:survives_explosion"}],
      "entries": [{"type": "minecraft:item", "name": f"{NS}:{b}"}]}]})
# menas sueltan items
def drop(b, item, lo, hi):
    wj(f"{DT}/loot_table/blocks/{b}.json", {"type": "minecraft:block", "pools": [{"rolls": 1,
      "conditions": [{"condition": "minecraft:survives_explosion"}],
      "entries": [{"type": "minecraft:item", "name": f"{NS}:{item}",
        "functions": [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": lo, "max": hi}},
                      {"function": "minecraft:apply_bonus", "enchantment": "minecraft:fortune", "formula": "minecraft:ore_drops"}]}]}]})
drop("essence_ore", "celestial_essence", 1, 3)
drop("ether_ore", "ether_shard", 1, 2)
# césped suelta tierra
wj(f"{DT}/loot_table/blocks/celestial_grass.json", {"type": "minecraft:block", "pools": [{"rolls": 1,
  "conditions": [{"condition": "minecraft:survives_explosion"}],
  "entries": [{"type": "minecraft:item", "name": f"{NS}:celestial_dirt"}]}]})

# items
for it in ITEM_TEX:
    wj(f"{AS}/items/{it}.json", {"model": {"type": "minecraft:model", "model": f"{NS}:item/{it}"}})
    wj(f"{AS}/models/item/{it}.json", {"parent": "minecraft:item/generated", "textures": {"layer0": f"{NS}:item/{it}"}})

# tags de minado
pick = [b for b in ALL_BLOCKS if b not in ("celestial_dirt","celestial_sand","celestial_grass","celestial_planks","celestial_log","celestial_leaves","solid_cloud")]
wj(f"{RES}/data/minecraft/tags/block/mineable/pickaxe.json", {"replace": False, "values": [f"{NS}:{b}" for b in pick]})
wj(f"{RES}/data/minecraft/tags/block/mineable/shovel.json", {"replace": False, "values": [f"{NS}:{b}" for b in ("celestial_dirt","celestial_sand","celestial_grass","solid_cloud")]})
wj(f"{RES}/data/minecraft/tags/block/mineable/axe.json", {"replace": False, "values": [f"{NS}:{b}" for b in ("celestial_planks","celestial_log")]})
wj(f"{RES}/data/minecraft/tags/block/mineable/hoe.json", {"replace": False, "values": [f"{NS}:celestial_leaves"]})

# recetas
def shaped(name, pattern, key, result, count=1):
    wj(f"{DT}/recipe/{name}.json", {"type": "minecraft:crafting_shaped", "category": "building",
       "pattern": pattern, "key": key, "result": {"id": f"{NS}:{result}", "count": count}})
def shapeless(name, ings, result, count=1):
    wj(f"{DT}/recipe/{name}.json", {"type": "minecraft:crafting_shapeless", "category": "misc",
       "ingredients": ings, "result": {"id": f"{NS}:{result}", "count": count}})
shapeless("celestial_planks_from_log", [f"{NS}:celestial_log"], "celestial_planks", 4)
shaped("celestial_bricks", ["##","##"], {"#": f"{NS}:celestial_stone"}, "celestial_bricks", 4)
shaped("celestial_marble", ["#S","S#"], {"#": f"{NS}:celestial_stone", "S": f"{NS}:celestial_sand"}, "celestial_marble", 2)
shaped("ruin_bricks", ["##","##"], {"#": f"{NS}:ancient_stone"}, "ruin_bricks", 4)
shaped("temple_tiles", ["#M","M#"], {"#": f"{NS}:celestial_bricks", "M": f"{NS}:celestial_marble"}, "temple_tiles", 4)
shaped("essence_block", ["###","###","###"], {"#": f"{NS}:celestial_essence"}, "essence_block")
shapeless("essence_from_block", [f"{NS}:essence_block"], "celestial_essence", 9)
shaped("aurora_crystal_block", ["###","###","###"], {"#": f"{NS}:aurora_crystal"}, "aurora_crystal_block")
shapeless("aurora_from_block", [f"{NS}:aurora_crystal_block"], "aurora_crystal", 9)
shaped("azure_crystal_glass", ["#G","G#"], {"#": f"{NS}:aurora_crystal", "G": "minecraft:glass"}, "azure_crystal_glass", 4)
shaped("luminous_crystal", [" E ","EAE"," E "], {"E": f"{NS}:celestial_essence", "A": f"{NS}:aurora_crystal"}, "luminous_crystal", 2)
shaped("sacred_crystal", ["LLL","LSL","LLL"], {"L": f"{NS}:luminous_crystal", "S": f"{NS}:solar_fragment"}, "sacred_crystal")
shaped("solid_cloud", ["##","##"], {"#": "minecraft:snowball"}, "solid_cloud", 2)
shaped("portal_frame", ["MAM","ESE","MAM"], {"M": f"{NS}:celestial_marble", "A": f"{NS}:aurora_crystal", "E": f"{NS}:celestial_essence", "S": f"{NS}:solar_fragment"}, "portal_frame", 4)
shaped("divine_ingot", ["EEE","ESE","EEE"], {"E": f"{NS}:ether_shard", "S": f"{NS}:solar_fragment"}, "divine_ingot")
shaped("solar_fragment", [" G ","GEG"," G "], {"G": "minecraft:gold_nugget", "E": f"{NS}:celestial_essence"}, "solar_fragment")
shaped("aurora_crystal", ["EE","EE"], {"E": f"{NS}:ether_shard"}, "aurora_crystal")
for src, res, xp in (("essence_ore","celestial_essence",0.7), ("ether_ore","ether_shard",1.0)):
    wj(f"{DT}/recipe/smelt_{src}.json", {"type": "minecraft:smelting", "category": "misc",
       "ingredient": f"{NS}:{src}", "result": {"id": f"{NS}:{res}"}, "experience": xp, "cookingtime": 200})

# idiomas
NAMES = {
 "celestial_grass": ("Césped celestial", "Celestial Grass"),
 "celestial_dirt": ("Tierra celestial", "Celestial Dirt"),
 "celestial_stone": ("Piedra celestial", "Celestial Stone"),
 "ancient_stone": ("Piedra antigua", "Ancient Stone"),
 "celestial_marble": ("Mármol celestial", "Celestial Marble"),
 "celestial_bricks": ("Ladrillos celestiales", "Celestial Bricks"),
 "azure_crystal_glass": ("Cristal azul", "Azure Crystal Glass"),
 "luminous_crystal": ("Cristal luminoso", "Luminous Crystal"),
 "sacred_crystal": ("Cristal sagrado", "Sacred Crystal"),
 "solid_cloud": ("Nube sólida", "Solid Cloud"),
 "celestial_planks": ("Madera celestial", "Celestial Planks"),
 "celestial_log": ("Tronco celestial", "Celestial Log"),
 "celestial_leaves": ("Hojas celestiales", "Celestial Leaves"),
 "luminous_flower_block": ("Bloque de flor luminosa", "Luminous Flower Block"),
 "celestial_sand": ("Arena celestial", "Celestial Sand"),
 "temple_tiles": ("Baldosas de templo", "Temple Tiles"),
 "ruin_bricks": ("Ladrillos de ruinas", "Ruin Bricks"),
 "essence_ore": ("Mineral de esencia", "Essence Ore"),
 "essence_block": ("Bloque de esencia concentrada", "Concentrated Essence Block"),
 "ether_ore": ("Mineral de Éter", "Ether Ore"),
 "aurora_crystal_block": ("Bloque de Cristal de Aurora", "Aurora Crystal Block"),
 "portal_frame": ("Marco del portal celestial", "Celestial Portal Frame"),
 "celestial_essence": ("Esencia Celestial", "Celestial Essence"),
 "aurora_crystal": ("Cristal de Aurora", "Aurora Crystal"),
 "ether_shard": ("Fragmento de Éter", "Ether Shard"),
 "divine_ingot": ("Lingote Divino", "Divine Ingot"),
 "solar_fragment": ("Fragmento Solar", "Solar Fragment"),
}
es, en = {}, {}
for k, (a, b) in NAMES.items():
    kind = "block" if k in ALL_BLOCKS else "item"
    es[f"{kind}.{NS}.{k}"] = a; en[f"{kind}.{NS}.{k}"] = b
es[f"itemGroup.{NS}.main"] = "Celestial Dimension"; en[f"itemGroup.{NS}.main"] = "Celestial Dimension"
wj(f"{AS}/lang/es_es.json", es); wj(f"{AS}/lang/en_us.json", en)

# fabric.mod.json
wj(f"{RES}/fabric.mod.json", {
 "schemaVersion": 1, "id": NS, "version": "${version}", "name": "Celestial Dimension",
 "description": "Mod de aventura: el Reino Celestial. Etapa 1: bloques, materiales y base del proyecto.",
 "authors": ["Celestial Dimension Team"], "license": "MIT",
 "icon": f"assets/{NS}/icon.png", "environment": "*",
 "entrypoints": {"main": ["com.celestialdimension.CelestialDimension"]},
 "depends": {"fabricloader": ">=0.19.1", "minecraft": "26.1.2", "java": ">=25", "fabric-api": "*"}})

# ---------------- Gradle ----------------
w(f"{ROOT}/settings.gradle", """pluginManagement {
    repositories {
        maven { name = 'Fabric'; url = 'https://maven.fabricmc.net/' }
        mavenCentral()
        gradlePluginPortal()
    }
}
rootProject.name = 'celestial_dimension'
""")
w(f"{ROOT}/gradle.properties", """org.gradle.jvmargs=-Xmx2G
org.gradle.parallel=true

minecraft_version=26.1.2
loader_version=0.19.1
loom_version=1.15.5
fabric_api_version=0.145.4+26.1.2

mod_version=0.1.0
maven_group=com.celestialdimension
archives_base_name=celestial_dimension
""")
w(f"{ROOT}/build.gradle", """plugins {
    id 'net.fabricmc.fabric-loom' version "${loom_version}"
    id 'maven-publish'
}

version = "${project.mod_version}+mc${project.minecraft_version}"
group = project.maven_group

base {
    archivesName = project.archives_base_name
}

repositories {
}

dependencies {
    minecraft "com.mojang:minecraft:${project.minecraft_version}"
    implementation "net.fabricmc:fabric-loader:${project.loader_version}"
    implementation "net.fabricmc.fabric-api:fabric-api:${project.fabric_api_version}"
}

processResources {
    inputs.property "version", project.version
    filesMatching("fabric.mod.json") {
        expand "version": project.version
    }
}

tasks.withType(JavaCompile).configureEach {
    it.options.release = 25
    it.options.encoding = 'UTF-8'
}

java {
    withSourcesJar()
    sourceCompatibility = JavaVersion.VERSION_25
    targetCompatibility = JavaVersion.VERSION_25
}

jar {
    inputs.property "archivesName", project.base.archivesName
    from("LICENSE") {
        rename { "${it}_${inputs.properties.archivesName}" }
    }
}
""")
w(f"{ROOT}/gradle/wrapper/gradle-wrapper.properties", """distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-9.4.1-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
""")
w(f"{ROOT}/LICENSE", "MIT License\n\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software to use, copy, modify, merge, publish and distribute it, subject to inclusion of this notice.\n")
w(f"{ROOT}/.gitignore", ".gradle/\nbuild/\n.idea/\nrun/\n*.iml\n")

# ---------------- workflow ----------------
w(f"{ROOT}/.github/workflows/build.yml", """name: Build Celestial Dimension

on:
  push:
  pull_request:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Set up JDK 25
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 25

      - name: Set up Gradle
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: 9.4.1

      - name: Generate Gradle Wrapper if missing
        run: |
          if [ ! -f gradle/wrapper/gradle-wrapper.jar ]; then
            gradle wrapper --gradle-version 9.4.1
          fi
          chmod +x gradlew

      - name: Build
        run: ./gradlew build --stacktrace

      - name: Verify jar
        run: |
          ls -la build/libs/
          JAR=$(ls build/libs/*.jar | grep -v -- '-sources' | head -n 1)
          test -s "$JAR"
          unzip -p "$JAR" fabric.mod.json | head -n 20
          unzip -l "$JAR" | grep -c 'assets/celestial_dimension/textures'

      - name: Upload mod jar
        uses: actions/upload-artifact@v4
        with:
          name: celestial_dimension-jar
          path: |
            build/libs/*.jar
            !build/libs/*-sources.jar
          if-no-files-found: error
""")
print("ok")
