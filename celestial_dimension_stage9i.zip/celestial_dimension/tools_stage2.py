import os, json, zlib, struct, random, math
ROOT = "/home/claude/cd/celestial_dimension"
NS = "celestial_dimension"
RES = f"{ROOT}/src/main/resources"
AS = f"{RES}/assets/{NS}"
DT = f"{RES}/data/{NS}"
JV = f"{ROOT}/src/main/java/com/celestialdimension"

def w(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "w", encoding="utf-8").write(text)
def wj(path, obj): w(path, json.dumps(obj, indent=2, ensure_ascii=False) + "\n")
def id_(n): return f"{NS}:{n}"
def st(name, props=None):
    d = {"Name": name}
    if props: d["Properties"] = props
    return d
def prov(name): return {"type": "minecraft:simple_state_provider", "state": st(name)}

# ---------- textura del portal ----------
def png(path, size, px):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    W, H = size
    raw = b"".join(b"\x00" + b"".join(bytes(px[y][x]) for x in range(W)) for y in range(H))
    def ch(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    open(path, "wb").write(b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", W, H, 8, 6, 0, 0, 0))
                           + ch(b"IDAT", zlib.compress(raw, 9)) + ch(b"IEND", b""))
rnd = random.Random(77)
px = []
for y in range(16):
    row = []
    for x in range(16):
        v = math.sin((x + y) * 0.7) * 0.5 + math.sin((x - y) * 0.9) * 0.5
        r = int(150 + 70 * v + rnd.randint(-10, 10)); g = int(120 + 60 * v + rnd.randint(-10, 10)); b = 255
        row.append((max(0, min(255, r)), max(0, min(255, g)), b, 255))
    px.append(row)
png(f"{AS}/textures/block/celestial_portal.png", (16, 16), px)

# modelo + estado del bloque portal (lámina fina, eje X o Z)
wj(f"{AS}/models/block/celestial_portal_ns.json", {
  "textures": {"portal": f"{NS}:block/celestial_portal", "particle": f"{NS}:block/celestial_portal"},
  "elements": [{"from": [0, 0, 7], "to": [16, 16, 9], "faces": {
      "north": {"uv": [0, 0, 16, 16], "texture": "#portal"},
      "south": {"uv": [0, 0, 16, 16], "texture": "#portal"}}}]})
wj(f"{AS}/blockstates/celestial_portal.json", {"variants": {
  "axis=z": {"model": f"{NS}:block/celestial_portal_ns"},
  "axis=x": {"model": f"{NS}:block/celestial_portal_ns", "y": 90}}})

# receta del marco con materiales del Overworld (evita dependencia circular)
wj(f"{DT}/recipe/portal_frame.json", {"type": "minecraft:crafting_shaped", "category": "building",
  "pattern": ["QAQ", "AEA", "QAQ"],
  "key": {"Q": "minecraft:quartz_block", "A": "minecraft:amethyst_shard", "E": id_("celestial_essence")},
  "result": {"id": id_("portal_frame"), "count": 4}})
wj(f"{DT}/recipe/celestial_essence_from_overworld.json", {"type": "minecraft:crafting_shapeless", "category": "misc",
  "ingredients": ["minecraft:amethyst_shard", "minecraft:glowstone_dust", "minecraft:lapis_lazuli"],
  "result": {"id": id_("celestial_essence"), "count": 2}})

# ---------- datos de mundo ----------
wj(f"{DT}/dimension_type/celestial.json", {
  "has_skylight": True, "has_ceiling": False, "coordinate_scale": 1.0,
  "ambient_light": 0.1, "min_y": 0, "height": 256, "logical_height": 256,
  "infiniburn": "#minecraft:infiniburn_overworld",
  "monster_spawn_light_level": 0, "monster_spawn_block_light_limit": 0,
  "skybox": "overworld", "cardinal_light": "default"})

wj(f"{DT}/dimension/celestial.json", {
  "type": id_("celestial"),
  "generator": {"type": "minecraft:noise", "settings": id_("celestial"),
    "biome_source": {"type": "minecraft:fixed", "biome": id_("celestial_meadows")}}})

wj(f"{DT}/worldgen/noise/islands.json", {"firstOctave": -6, "amplitudes": [1.0, 0.6, 0.35]})

noise = {"type": "minecraft:noise", "noise": id_("islands"), "xz_scale": 1.0, "y_scale": 1.0}
up = {"type": "minecraft:y_clamped_gradient", "from_y": 40, "to_y": 120, "from_value": -1.3, "to_value": 0.0}
down = {"type": "minecraft:y_clamped_gradient", "from_y": 120, "to_y": 150, "from_value": 0.0, "to_value": -2.0}
profile = {"type": "minecraft:min", "argument1": up, "argument2": down}
density = {"type": "minecraft:add",
  "argument1": {"type": "minecraft:add",
     "argument1": {"type": "minecraft:mul", "argument1": 1.4, "argument2": noise},
     "argument2": profile},
  "argument2": -0.3}
wj(f"{DT}/worldgen/density_function/island_density.json", {"type": "minecraft:interpolated", "argument": density})

zero = 0.0
wj(f"{DT}/worldgen/noise_settings/celestial.json", {
  "sea_level": -64, "disable_mob_generation": False, "aquifers_enabled": False,
  "ore_veins_enabled": False, "legacy_random_source": False,
  "default_block": st(id_("celestial_stone")),
  "default_fluid": st("minecraft:water", {"level": "0"}),
  "spawn_target": [],
  "noise": {"min_y": 0, "height": 256, "size_horizontal": 2, "size_vertical": 1},
  "noise_router": {
    "barrier": zero, "fluid_level_floodedness": zero, "fluid_level_spread": zero, "lava": zero,
    "temperature": zero, "vegetation": zero, "continents": zero, "erosion": zero, "depth": zero, "ridges": zero,
    "preliminary_surface_level": zero, "final_density": id_("island_density"),
    "vein_toggle": zero, "vein_ridged": zero, "vein_gap": zero,
    "initial_density_without_jaggedness": zero},
  "surface_rule": {"type": "minecraft:sequence", "sequence": [
    {"type": "minecraft:condition",
     "if_true": {"type": "minecraft:stone_depth", "offset": 0, "surface_type": "floor", "add_surface_depth": False, "secondary_depth_range": 0},
     "then_run": {"type": "minecraft:block", "result_state": st(id_("celestial_grass"))}},
    {"type": "minecraft:condition",
     "if_true": {"type": "minecraft:stone_depth", "offset": 0, "surface_type": "floor", "add_surface_depth": True, "secondary_depth_range": 0},
     "then_run": {"type": "minecraft:block", "result_state": st(id_("celestial_dirt"))}}]}})

# ---------- features ----------
wj(f"{DT}/tags/block/carver_replaceables.json", {"replace": False, "values": [id_("celestial_stone"), id_("celestial_dirt"), id_("celestial_grass")]})
wj(f"{DT}/worldgen/configured_carver/celestial_caves.json", {"type": "minecraft:cave", "config": {
  "probability": 0.15,
  "y": {"type": "minecraft:uniform", "min_inclusive": {"absolute": 45}, "max_inclusive": {"absolute": 140}},
  "yScale": {"type": "minecraft:uniform", "min_inclusive": 0.5, "max_exclusive": 1.0},
  "lava_level": {"above_bottom": 0},
  "replaceable": "#" + id_("carver_replaceables"),
  "horizontal_radius_multiplier": {"type": "minecraft:uniform", "min_inclusive": 0.7, "max_exclusive": 1.4},
  "vertical_radius_multiplier": {"type": "minecraft:uniform", "min_inclusive": 0.8, "max_exclusive": 1.3},
  "floor_level": {"type": "minecraft:uniform", "min_inclusive": -1.0, "max_exclusive": -0.4}}})

def hr(lo, hi): return {"type": "minecraft:height_range", "height": {"type": "minecraft:uniform",
    "min_inclusive": {"absolute": lo}, "max_inclusive": {"absolute": hi}}}
scan = {"type": "minecraft:environment_scan", "direction_of_search": "down",
        "target_condition": {"type": "minecraft:solid"},
        "allowed_search_condition": {"type": "minecraft:matching_blocks", "blocks": "minecraft:air"}, "max_steps": 24}
on_grass = {"type": "minecraft:block_predicate_filter",
            "predicate": {"type": "minecraft:matching_blocks", "blocks": id_("celestial_grass"), "offset": [0, -1, 0]}}
BIOME = {"type": "minecraft:biome"}
SQ = {"type": "minecraft:in_square"}

def cfg(name, obj): wj(f"{DT}/worldgen/configured_feature/{name}.json", obj)
def plc(name, feat, mods): wj(f"{DT}/worldgen/placed_feature/{name}.json", {"feature": id_(feat), "placement": mods})

cfg("celestial_tree", {"type": "minecraft:tree", "config": {
  "trunk_provider": prov(id_("celestial_log")), "foliage_provider": prov(id_("celestial_leaves")),
  "dirt_provider": prov(id_("celestial_dirt")),
  "trunk_placer": {"type": "minecraft:fancy_trunk_placer", "base_height": 12, "height_rand_a": 4, "height_rand_b": 6},
  "foliage_placer": {"type": "minecraft:fancy_foliage_placer", "radius": 3, "offset": 4, "height": 4},
  "minimum_size": {"type": "minecraft:two_layers_feature_size", "limit": 0, "lower_size": 0, "upper_size": 0},
  "ignore_vines": True, "decorators": []}})
plc("celestial_tree", "celestial_tree", [{"type": "minecraft:count", "count": 6}, SQ, hr(60, 170), scan, on_grass, BIOME])

cfg("luminous_flower", {"type": "minecraft:simple_block", "config": {"to_place": prov(id_("luminous_flower_block"))}})
plc("luminous_flower", "luminous_flower", [{"type": "minecraft:count", "count": 10}, SQ, hr(60, 170), scan, on_grass, BIOME])

def ore_cfg(name, block, size):
    cfg(name, {"type": "minecraft:ore", "config": {"size": size, "discard_chance_on_air_exposure": 0.0,
      "targets": [{"target": {"predicate_type": "minecraft:block_match", "block": id_("celestial_stone")}, "state": st(id_(block))}]}})
ore_cfg("essence_ore", "essence_ore", 8)
ore_cfg("ether_ore", "ether_ore", 5)
plc("essence_ore", "essence_ore", [{"type": "minecraft:count", "count": 14}, SQ, hr(30, 170), BIOME])
plc("ether_ore", "ether_ore", [{"type": "minecraft:count", "count": 5}, SQ, hr(30, 100), BIOME])

cfg("celestial_spring", {"type": "minecraft:spring_feature", "config": {
  "state": st("minecraft:water", {"falling": "true"}), "requires_block_below": True,
  "rock_count": 4, "hole_count": 1, "valid_blocks": [id_("celestial_stone"), id_("celestial_dirt")]}})
plc("celestial_spring", "celestial_spring", [{"type": "minecraft:count", "count": 30}, SQ, hr(40, 170), BIOME])

cfg("celestial_lake", {"type": "minecraft:lake", "config": {
  "fluid": {"type": "minecraft:simple_state_provider", "state": st("minecraft:water", {"level": "0"})},
  "barrier": prov(id_("celestial_sand"))}})
plc("celestial_lake", "celestial_lake", [{"type": "minecraft:rarity_filter", "chance": 5}, SQ, hr(70, 150), scan, BIOME])

feats = [[] for _ in range(11)]
feats[1] = [id_("celestial_lake")]
feats[6] = [id_("essence_ore"), id_("ether_ore")]
feats[8] = [id_("celestial_spring")]
feats[9] = [id_("celestial_tree"), id_("luminous_flower")]
wj(f"{DT}/worldgen/biome/celestial_meadows.json", {
  "has_precipitation": False, "temperature": 0.5, "downfall": 0.4,
  "effects": {"sky_color": 0x8FD0FF, "fog_color": 0xDCEBFF, "water_color": 0x4FC3F7, "water_fog_color": 0x2A7FBF,
              "grass_color": 0x62C9E8, "foliage_color": 0x5FD6C0},
  "spawners": {"monster": [], "creature": [], "ambient": [], "water_creature": [], "underground_water_creature": [],
               "water_ambient": [], "misc": []},
  "spawn_costs": {}, "carvers": {"air": [id_("celestial_caves")]}, "features": feats})

# ---------- lang ----------
for lang, txt in (("es_es", "Portal celestial"), ("en_us", "Celestial Portal")):
    p = f"{AS}/lang/{lang}.json"; d = json.load(open(p, encoding="utf-8"))
    d[f"block.{NS}.celestial_portal"] = txt
    wj(p, d)

# ---------- Java ----------
w(f"{JV}/CelestialPortalBlock.java", """package com.celestialdimension;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.EnumProperty;

/** Bloque interior del portal. La lógica de teletransporte vive en {@link ModPortal}. */
public class CelestialPortalBlock extends Block {
    public static final EnumProperty<Direction.Axis> AXIS = BlockStateProperties.HORIZONTAL_AXIS;

    public CelestialPortalBlock(BlockBehaviour.Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(AXIS, Direction.Axis.X));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(AXIS);
    }
}
""")

w(f"{JV}/ModPortal.java", """package com.celestialdimension;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Portal del Reino Celestial.
 * Marco: anillo de bloques portal_frame con interior libre de 2 de ancho x 3 de alto (sin esquinas).
 * Activacion: clic derecho sobre el marco con un Fragmento Solar.
 */
public final class ModPortal {
    public static final ResourceKey<Level> CELESTIAL =
            ResourceKey.create(Registries.DIMENSION, CelestialDimension.id("celestial"));

    private static final int ARRIVAL_Y = 110;
    private static final Map<UUID, BlockPos> ORIGIN = new HashMap<>();
    private static final Map<UUID, Integer> COOLDOWN = new HashMap<>();

    public static void init() {
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (!(level instanceof ServerLevel serverLevel)) {
                return InteractionResult.PASS;
            }
            ItemStack stack = player.getItemInHand(hand);
            if (!stack.is(ModItems.SOLAR_FRAGMENT)) {
                return InteractionResult.PASS;
            }
            BlockPos clicked = hit.getBlockPos();
            if (!serverLevel.getBlockState(clicked).is(ModBlocks.PORTAL_FRAME)) {
                return InteractionResult.PASS;
            }
            if (tryActivate(serverLevel, clicked)) {
                if (!player.isCreative()) {
                    stack.shrink(1);
                }
                return InteractionResult.SUCCESS;
            }
            return InteractionResult.PASS;
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                UUID id = player.getUUID();
                Integer cd = COOLDOWN.get(id);
                if (cd != null) {
                    if (cd <= 1) {
                        COOLDOWN.remove(id);
                    } else {
                        COOLDOWN.put(id, cd - 1);
                    }
                    continue;
                }
                ServerLevel level = (ServerLevel) player.level();
                BlockPos feet = player.blockPosition();
                if (level.getBlockState(feet).is(ModBlocks.CELESTIAL_PORTAL)
                        || level.getBlockState(feet.above()).is(ModBlocks.CELESTIAL_PORTAL)) {
                    travel(server.getLevel(CELESTIAL), level, player);
                }
            }
        });
    }

    // ---------- activacion ----------
    private static boolean tryActivate(ServerLevel level, BlockPos clicked) {
        for (Direction.Axis axis : new Direction.Axis[] {Direction.Axis.X, Direction.Axis.Z}) {
            Direction d = axis == Direction.Axis.X ? Direction.EAST : Direction.SOUTH;
            for (int a = -3; a <= 3; a++) {
                for (int b = -4; b <= 3; b++) {
                    BlockPos origin = clicked.relative(d, a).above(b);
                    if (validFrame(level, origin, d)) {
                        fillPortal(level, origin, d, axis);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /** origin = bloque interior inferior-izquierdo (menor coordenada en la direccion d). */
    private static boolean validFrame(ServerLevel level, BlockPos origin, Direction d) {
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 3; j++) {
                if (!level.getBlockState(origin.relative(d, i).above(j)).isAir()) {
                    return false;
                }
            }
            if (!isFrame(level, origin.relative(d, i).below())) return false;
            if (!isFrame(level, origin.relative(d, i).above(3))) return false;
        }
        for (int j = 0; j < 3; j++) {
            if (!isFrame(level, origin.relative(d, -1).above(j))) return false;
            if (!isFrame(level, origin.relative(d, 2).above(j))) return false;
        }
        return true;
    }

    private static boolean isFrame(ServerLevel level, BlockPos pos) {
        return level.getBlockState(pos).is(ModBlocks.PORTAL_FRAME);
    }

    private static void fillPortal(ServerLevel level, BlockPos origin, Direction d, Direction.Axis axis) {
        BlockState portal = ModBlocks.CELESTIAL_PORTAL.defaultBlockState().setValue(CelestialPortalBlock.AXIS, axis);
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 3; j++) {
                level.setBlock(origin.relative(d, i).above(j), portal, Block.UPDATE_ALL);
            }
        }
    }

    // ---------- viaje ----------
    private static void travel(ServerLevel celestial, ServerLevel current, ServerPlayer player) {
        if (celestial == null) {
            CelestialDimension.LOGGER.error("La dimension celestial_dimension:celestial no esta cargada");
            return;
        }
        UUID id = player.getUUID();
        COOLDOWN.put(id, 100);
        if (current.dimension().equals(CELESTIAL)) {
            ServerLevel overworld = celestial.getServer().getLevel(Level.OVERWORLD);
            BlockPos back = ORIGIN.get(id);
            if (back == null) {
                int y = overworld.getHeight(Heightmap.Types.MOTION_BLOCKING, 0, 0);
                back = new BlockPos(0, y, 0);
            }
            player.teleportTo(overworld, back.getX() + 0.5, back.getY(), back.getZ() + 0.5,
                    Set.of(), player.getYRot(), player.getXRot(), true);
        } else {
            ORIGIN.put(id, player.blockPosition());
            BlockPos base = new BlockPos(player.blockPosition().getX(), ARRIVAL_Y, player.blockPosition().getZ());
            buildArrival(celestial, base);
            player.teleportTo(celestial, base.getX() + 0.5, base.getY() + 1, base.getZ() + 3.5,
                    Set.of(), 180.0f, 0.0f, true);
        }
    }

    /** Plataforma de marmol 9x9 con un portal de regreso ya encendido. */
    private static void buildArrival(ServerLevel level, BlockPos base) {
        BlockState marble = ModBlocks.CELESTIAL_MARBLE.defaultBlockState();
        BlockState air = net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();
        for (int x = -4; x <= 4; x++) {
            for (int z = -4; z <= 4; z++) {
                level.setBlock(base.offset(x, 0, z), marble, Block.UPDATE_ALL);
                for (int y = 1; y <= 6; y++) {
                    level.setBlock(base.offset(x, y, z), air, Block.UPDATE_ALL);
                }
            }
        }
        BlockState frame = ModBlocks.PORTAL_FRAME.defaultBlockState();
        BlockPos origin = base.offset(0, 1, 0);
        Direction d = Direction.EAST;
        for (int i = 0; i < 2; i++) {
            level.setBlock(origin.relative(d, i).below(), frame, Block.UPDATE_ALL);
            level.setBlock(origin.relative(d, i).above(3), frame, Block.UPDATE_ALL);
        }
        for (int j = 0; j < 3; j++) {
            level.setBlock(origin.relative(d, -1).above(j), frame, Block.UPDATE_ALL);
            level.setBlock(origin.relative(d, 2).above(j), frame, Block.UPDATE_ALL);
        }
        fillPortal(level, origin, d, Direction.Axis.X);
    }

    private ModPortal() {
    }
}
""")

# bloque portal en ModBlocks + init
p = f"{JV}/ModBlocks.java"; s = open(p).read()
s = s.replace("""    private static Block reg(""", """    public static final Block CELESTIAL_PORTAL = regNoItem("celestial_portal", CelestialPortalBlock::new,
            BlockBehaviour.Properties.of().strength(-1.0f, 3600000.0f).noCollision().noOcclusion()
                    .lightLevel(s -> 11).sound(SoundType.GLASS));

    private static Block regNoItem(String name, Function<BlockBehaviour.Properties, Block> factory, BlockBehaviour.Properties props) {
        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, CelestialDimension.id(name));
        Block block = factory.apply(props.setId(blockKey));
        Registry.register(BuiltInRegistries.BLOCK, blockKey, block);
        COUNT++;
        return block;
    }

    private static Block reg(""", 1)
open(p, "w").write(s)
p = f"{JV}/CelestialDimension.java"; s = open(p).read()
s = s.replace("        ModCreativeTab.init();\n", "        ModCreativeTab.init();\n        ModPortal.init();\n")
open(p, "w").write(s)
w(f"{ROOT}/README.md", open(f"{ROOT}/README.md").read() + """
## Etapa 2 (dimension y portal)
- Dimension `celestial_dimension:celestial`: islas flotantes por ruido, cuevas, cascadas (manantiales), lagos, arboles gigantes, menas.
- Portal: marco de 10 `portal_frame` (anillo 4x5 sin esquinas, interior 2x3) y clic derecho con un Fragmento Solar.
- Comando de prueba: `/execute in celestial_dimension:celestial run tp @s ~ 120 ~`
""")
print("stage2 ok")
