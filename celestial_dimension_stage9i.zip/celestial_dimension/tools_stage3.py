import os, json
ROOT = "/home/claude/cd/celestial_dimension"
NS = "celestial_dimension"
RES = f"{ROOT}/src/main/resources"
AS = f"{RES}/assets/{NS}"
DT = f"{RES}/data/{NS}"
def wj(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "w", encoding="utf-8").write(json.dumps(obj, indent=2, ensure_ascii=False) + "\n")
def rj(path): return json.load(open(path, encoding="utf-8"))
def i(n): return f"{NS}:{n}"
def st(n, p=None):
    d = {"Name": n}
    if p: d["Properties"] = p
    return d
def prov(n): return {"type": "minecraft:simple_state_provider", "state": st(n)}
def hr(lo, hi): return {"type": "minecraft:height_range", "height": {"type": "minecraft:uniform",
    "min_inclusive": {"absolute": lo}, "max_inclusive": {"absolute": hi}}}
scan = {"type": "minecraft:environment_scan", "direction_of_search": "down",
        "target_condition": {"type": "minecraft:solid"},
        "allowed_search_condition": {"type": "minecraft:matching_blocks", "blocks": "minecraft:air"}, "max_steps": 24}
def on(block): return {"type": "minecraft:block_predicate_filter",
    "predicate": {"type": "minecraft:matching_blocks", "blocks": i(block), "offset": [0, -1, 0]}}
BIOME = {"type": "minecraft:biome"}; SQ = {"type": "minecraft:in_square"}
def cnt(n): return {"type": "minecraft:count", "count": n}
def cfg(n, o): wj(f"{DT}/worldgen/configured_feature/{n}.json", o)
def plc(n, feat, mods): wj(f"{DT}/worldgen/placed_feature/{n}.json", {"feature": i(feat), "placement": mods})

# ---------- features nuevas ----------
cfg("small_celestial_tree", {"type": "minecraft:tree", "config": {
  "trunk_provider": prov(i("celestial_log")), "foliage_provider": prov(i("celestial_leaves")),
  "dirt_provider": prov(i("celestial_dirt")),
  "trunk_placer": {"type": "minecraft:straight_trunk_placer", "base_height": 5, "height_rand_a": 2, "height_rand_b": 0},
  "foliage_placer": {"type": "minecraft:blob_foliage_placer", "radius": 2, "offset": 0, "height": 3},
  "minimum_size": {"type": "minecraft:two_layers_feature_size", "limit": 1, "lower_size": 0, "upper_size": 1},
  "ignore_vines": True, "decorators": []}})
cfg("cloud_mass", {"type": "minecraft:ore", "config": {"size": 28, "discard_chance_on_air_exposure": 0.0,
  "targets": [{"target": {"predicate_type": "minecraft:block_match", "block": "minecraft:air"}, "state": st(i("solid_cloud"))}]}})
def column(n, block, lo, hi):
    cfg(n, {"type": "minecraft:block_column", "config": {"direction": "up",
      "allowed_placement": {"type": "minecraft:matching_blocks", "blocks": "minecraft:air"}, "prioritize_tip": False,
      "layers": [{"height": {"type": "minecraft:uniform", "min_inclusive": lo, "max_inclusive": hi}, "provider": prov(block)}]}})
column("aurora_spire", i("aurora_crystal_block"), 3, 9)
column("luminous_spire", i("luminous_crystal"), 2, 6)
column("sacred_spire", i("sacred_crystal"), 2, 4)
column("ruin_pillar", i("ruin_bricks"), 3, 7)
column("marble_pillar", i("celestial_marble"), 2, 5)
cfg("flower_patch", {"type": "minecraft:simple_block", "config": {"to_place": prov(i("luminous_flower_block"))}})
cfg("cloud_puff", {"type": "minecraft:simple_block", "config": {"to_place": prov(i("solid_cloud"))}})

# ---------- helpers de colocacion ----------
def tree_big(n, c, base): plc(n, "celestial_tree", [cnt(c), SQ, hr(60, 170), scan, on(base), BIOME])
def tree_small(n, c, base): plc(n, "small_celestial_tree", [cnt(c), SQ, hr(60, 170), scan, on(base), BIOME])
def flowers(n, c, base): plc(n, "flower_patch", [cnt(c), SQ, hr(60, 170), scan, on(base), BIOME])
def col(n, feat, c, base): plc(n, feat, [cnt(c), SQ, hr(50, 175), scan, on(base), BIOME])
def ore(n, feat, c, lo, hi): plc(n, feat, [cnt(c), SQ, hr(lo, hi), BIOME])
def lake(n, rarity): plc(n, "celestial_lake", [{"type": "minecraft:rarity_filter", "chance": rarity}, SQ, hr(70, 150), scan, BIOME])
def spring(n, c): plc(n, "celestial_spring", [cnt(c), SQ, hr(40, 170), BIOME])
def clouds(n, c): plc(n, "cloud_mass", [cnt(c), SQ, hr(90, 175), BIOME])

tree_small("meadows_trees", 3, "celestial_grass"); flowers("meadows_flowers", 12, "celestial_grass")
tree_big("forest_giant_trees", 14, "celestial_grass"); clouds("forest_clouds", 8); flowers("forest_flowers", 4, "celestial_grass")
col("mountain_marble_pillars", "marble_pillar", 4, "celestial_marble"); col("mountain_luminous", "luminous_spire", 6, "celestial_marble")
col("mountain_sacred", "sacred_spire", 1, "celestial_marble")
tree_small("garden_trees", 5, "celestial_grass"); flowers("garden_flowers", 40, "celestial_grass")
col("garden_luminous", "luminous_spire", 2, "celestial_grass"); lake("garden_lakes", 2)
col("crystal_aurora", "aurora_spire", 12, "celestial_sand"); col("crystal_luminous", "luminous_spire", 8, "celestial_sand")
col("crystal_sacred", "sacred_spire", 2, "celestial_sand")
col("ruins_pillars", "ruin_pillar", 8, "ancient_stone"); col("ruins_marble", "marble_pillar", 3, "ancient_stone")
ore("rich_essence", "essence_ore", 24, 30, 170); ore("rich_ether", "ether_ore", 10, 30, 110)
spring("many_springs", 40)

# ---------- biomas ----------
def hexc(h): return int(h, 16)
BIOMES = {
 "celestial_meadows": dict(es="Praderas Celestiales", en="Celestial Meadows",
    fx=dict(sky_color=hexc("8FD0FF"), fog_color=hexc("DCEBFF"), water_color=hexc("4FC3F7"), water_fog_color=hexc("2A7FBF"),
            grass_color=hexc("62C9E8"), foliage_color=hexc("5FD6C0")),
    f1=["celestial_lake"], f6=["essence_ore", "ether_ore"], f8=["celestial_spring"], f9=["meadows_trees", "meadows_flowers"]),
 "cloud_forest": dict(es="Bosque de las Nubes", en="Cloud Forest",
    fx=dict(sky_color=hexc("B5E0FF"), fog_color=hexc("F2F7FF"), water_color=hexc("7FD4E8"), water_fog_color=hexc("5AA9C4"),
            grass_color=hexc("7FDDB5"), foliage_color=hexc("4FC9A0")),
    f1=[], f6=["essence_ore", "ether_ore"], f8=["celestial_spring"], f9=["forest_giant_trees", "forest_clouds", "forest_flowers"]),
 "sacred_mountains": dict(es="Montañas Sagradas", en="Sacred Mountains",
    fx=dict(sky_color=hexc("A8C4FF"), fog_color=hexc("E8E4FF"), water_color=hexc("6FA8F0"), water_fog_color=hexc("3F6FC0"),
            grass_color=hexc("B0C8F0"), foliage_color=hexc("A0B8E8")),
    f1=[], f6=["rich_essence", "rich_ether"], f8=["many_springs"], f9=["mountain_marble_pillars", "mountain_luminous", "mountain_sacred"]),
 "luminous_gardens": dict(es="Jardines Luminosos", en="Luminous Gardens",
    fx=dict(sky_color=hexc("9FDCFF"), fog_color=hexc("E6FFF8"), water_color=hexc("40E0D0"), water_fog_color=hexc("1FA89A"),
            grass_color=hexc("5FE8C8"), foliage_color=hexc("C58BFF")),
    f1=["garden_lakes"], f6=["essence_ore", "ether_ore"], f8=["celestial_spring"], f9=["garden_trees", "garden_flowers", "garden_luminous"]),
 "crystal_isles": dict(es="Islas Cristalinas", en="Crystal Isles",
    fx=dict(sky_color=hexc("A0B8FF"), fog_color=hexc("EAD8FF"), water_color=hexc("7FB0FF"), water_fog_color=hexc("5A7FE0"),
            grass_color=hexc("A0D8F0"), foliage_color=hexc("B090F0")),
    f1=[], f6=["rich_essence", "rich_ether"], f8=["celestial_spring"], f9=["crystal_aurora", "crystal_luminous", "crystal_sacred"]),
 "sky_ruins": dict(es="Ruinas del Cielo", en="Sky Ruins",
    fx=dict(sky_color=hexc("9CB0D8"), fog_color=hexc("D0D4E4"), water_color=hexc("5F8FC0"), water_fog_color=hexc("3F5F90"),
            grass_color=hexc("8FB0C0"), foliage_color=hexc("7FA0B0")),
    f1=[], f6=["essence_ore", "ether_ore"], f8=["celestial_spring"], f9=["ruins_pillars", "ruins_marble"]),
}
for name, b in BIOMES.items():
    feats = [[] for _ in range(11)]
    feats[1] = [i(x) if ":" not in x else x for x in b["f1"]]
    feats[6] = [i(x) for x in b["f6"]]
    feats[8] = [i(x) for x in b["f8"]]
    feats[9] = [i(x) for x in b["f9"]]
    feats[1] = [i(x) for x in b["f1"]]
    wj(f"{DT}/worldgen/biome/{name}.json", {
      "has_precipitation": False, "temperature": 0.5, "downfall": 0.4, "effects": b["fx"],
      "spawners": {k: [] for k in ("monster", "creature", "ambient", "water_creature",
                                   "underground_water_creature", "water_ambient", "misc")},
      "spawn_costs": {}, "carvers": {"air": [i("celestial_caves")]}, "features": feats})

# ---------- fuente de biomas multi-ruido ----------
def band(lo, hi): return [lo, hi]
def entry(biome, t, h):
    return {"biome": i(biome), "parameters": {"temperature": t, "humidity": h, "continentalness": [-2.0, 2.0],
            "erosion": [-2.0, 2.0], "depth": [-2.0, 2.0], "weirdness": [-2.0, 2.0], "offset": 0.0}}
COLD, MID, WARM = [-2.0, -0.25], [-0.25, 0.25], [0.25, 2.0]
DRY, WET = [-2.0, 0.0], [0.0, 2.0]
dim = rj(f"{DT}/dimension/celestial.json")
dim["generator"]["biome_source"] = {"type": "minecraft:multi_noise", "biomes": [
  entry("sacred_mountains", COLD, DRY), entry("crystal_isles", COLD, WET),
  entry("celestial_meadows", MID, DRY), entry("luminous_gardens", MID, WET),
  entry("sky_ruins", WARM, DRY), entry("cloud_forest", WARM, WET)]}
wj(f"{DT}/dimension/celestial.json", dim)

# ---------- ruido: clima real + terreno variable por region ----------
def cn(noise): return {"type": "minecraft:noise", "noise": noise, "xz_scale": 0.25, "y_scale": 0.0}
ns = rj(f"{DT}/worldgen/noise_settings/celestial.json")
r = ns["noise_router"]
r["temperature"] = cn("minecraft:temperature"); r["vegetation"] = cn("minecraft:vegetation")
r["continents"] = cn("minecraft:continentalness"); r["erosion"] = cn("minecraft:erosion"); r["ridges"] = cn("minecraft:ridge")
def top(block): return {"type": "minecraft:condition",
    "if_true": {"type": "minecraft:stone_depth", "offset": 0, "surface_type": "floor", "add_surface_depth": False, "secondary_depth_range": 0},
    "then_run": {"type": "minecraft:block", "result_state": st(i(block))}}
def sub(block): return {"type": "minecraft:condition",
    "if_true": {"type": "minecraft:stone_depth", "offset": 0, "surface_type": "floor", "add_surface_depth": True, "secondary_depth_range": 0},
    "then_run": {"type": "minecraft:block", "result_state": st(i(block))}}
def biome_rule(biome, t, s):
    return {"type": "minecraft:condition", "if_true": {"type": "minecraft:biome", "biome_is": [i(biome)]},
            "then_run": {"type": "minecraft:sequence", "sequence": [top(t), sub(s)]}}
ns["surface_rule"] = {"type": "minecraft:sequence", "sequence": [
  biome_rule("sacred_mountains", "celestial_marble", "celestial_stone"),
  biome_rule("crystal_isles", "celestial_sand", "celestial_sand"),
  biome_rule("sky_ruins", "ancient_stone", "ancient_stone"),
  biome_rule("cloud_forest", "celestial_grass", "celestial_dirt"),
  biome_rule("luminous_gardens", "celestial_grass", "celestial_dirt"),
  biome_rule("celestial_meadows", "celestial_grass", "celestial_dirt"),
  top("celestial_grass"), sub("celestial_dirt")]}
wj(f"{DT}/worldgen/noise_settings/celestial.json", ns)

dens = rj(f"{DT}/worldgen/density_function/island_density.json")
base = dens["argument"]
dens["argument"] = {"type": "minecraft:add",
  "argument1": base,
  "argument2": {"type": "minecraft:add",
     "argument1": {"type": "minecraft:mul", "argument1": -0.35, "argument2": cn("minecraft:temperature")},
     "argument2": {"type": "minecraft:mul", "argument1": 0.2, "argument2": cn("minecraft:continentalness")}}}
wj(f"{DT}/worldgen/density_function/island_density.json", dens)

# ---------- idiomas ----------
for lang in ("es", "en"):
    p = f"{AS}/lang/{lang}_{'es' if lang=='es' else 'us'}.json"; d = rj(p)
    for k, b in BIOMES.items(): d[f"biome.{NS}.{k}"] = b[lang]
    wj(p, d)

rd = open(f"{ROOT}/README.md").read()
open(f"{ROOT}/README.md", "w").write(rd + """
## Etapa 3 (seis biomas)
Fuente de biomas multi-ruido (temperatura x humedad): Montanas Sagradas, Islas Cristalinas, Praderas Celestiales,
Jardines Luminosos, Ruinas del Cielo, Bosque de las Nubes. Cada uno con superficie, vegetacion/estructuras naturales
(columnas de cristal, pilares, nubes), colores y menas propias. Criaturas: Etapa 5.
""")
print("stage3 ok")
