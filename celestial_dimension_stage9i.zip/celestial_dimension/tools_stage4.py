import os, json, gzip, struct, random, math
ROOT = "/home/claude/cd/celestial_dimension"
NS = "celestial_dimension"
RES = f"{ROOT}/src/main/resources"
AS = f"{RES}/assets/{NS}"
DT = f"{RES}/data/{NS}"
def wj(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "w", encoding="utf-8").write(json.dumps(obj, indent=2, ensure_ascii=False) + "\n")
def i(n): return f"{NS}:{n}"

# ---------------- escritor NBT minimo ----------------
class S:  # short
    def __init__(s, v): s.v = v
class B:  # byte
    def __init__(s, v): s.v = v
def tid(v):
    if isinstance(v, B): return 1
    if isinstance(v, S): return 2
    if isinstance(v, bool): return 1
    if isinstance(v, int): return 3
    if isinstance(v, str): return 8
    if isinstance(v, list): return 9
    if isinstance(v, dict): return 10
    raise TypeError(type(v))
def wstr(o, s):
    b = s.encode("utf-8"); o.write(struct.pack(">H", len(b))); o.write(b)
def wpay(o, v):
    t = tid(v)
    if t == 1: o.write(struct.pack(">b", int(v.v if isinstance(v, B) else v)))
    elif t == 2: o.write(struct.pack(">h", v.v))
    elif t == 3: o.write(struct.pack(">i", v))
    elif t == 8: wstr(o, v)
    elif t == 9:
        et = tid(v[0]) if v else 0
        o.write(struct.pack(">b", et)); o.write(struct.pack(">i", len(v)))
        for e in v: wpay(o, e)
    elif t == 10:
        for k, x in v.items():
            o.write(struct.pack(">b", tid(x))); wstr(o, k); wpay(o, x)
        o.write(b"\x00")
import io
def write_nbt(path, root):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    o = io.BytesIO(); o.write(b"\x0a"); wstr(o, ""); wpay(o, root)
    with gzip.open(path, "wb") as f: f.write(o.getvalue())

# ---------------- constructor de plantillas ----------------
class T:
    def __init__(s): s.b = {}
    def set(s, x, y, z, name, props=None, nbt=None): s.b[(x, y, z)] = (name, props or {}, nbt)
    def box(s, x1, y1, z1, x2, y2, z2, name, props=None):
        for x in range(min(x1, x2), max(x1, x2) + 1):
            for y in range(min(y1, y2), max(y1, y2) + 1):
                for z in range(min(z1, z2), max(z1, z2) + 1): s.set(x, y, z, name, props)
    def air(s, x1, y1, z1, x2, y2, z2): s.box(x1, y1, z1, x2, y2, z2, "minecraft:air")
    def hollow(s, x1, y1, z1, x2, y2, z2, name):
        for x in range(x1, x2 + 1):
            for y in range(y1, y2 + 1):
                for z in range(z1, z2 + 1):
                    edge = x in (x1, x2) or z in (z1, z2) or y in (y1, y2)
                    s.set(x, y, z, name if edge else "minecraft:air")
    def chest(s, x, y, z, facing, loot):
        s.set(x, y, z, "minecraft:chest", {"facing": facing, "type": "single", "waterlogged": "false"},
              {"id": "minecraft:chest", "LootTable": i("chests/" + loot)})
    def island(s, cx, cz, r, depth, ytop, top="celestial_grass", mid="celestial_dirt", core="celestial_stone"):
        for k in range(depth + 1):
            rad = r * (1 - k / (depth + 1))
            y = ytop - k
            R = int(math.ceil(rad))
            for x in range(cx - R, cx + R + 1):
                for z in range(cz - R, cz + R + 1):
                    if (x - cx) ** 2 + (z - cz) ** 2 <= rad * rad + 0.5:
                        s.set(x, y, z, i(top if k == 0 else mid if k < 3 else core))
    def disc(s, cx, cz, y, r, name):
        for x in range(cx - r, cx + r + 1):
            for z in range(cz - r, cz + r + 1):
                if (x - cx) ** 2 + (z - cz) ** 2 <= r * r: s.set(x, y, z, name)
    def save(s, name):
        mx = min(k[0] for k in s.b); my = min(k[1] for k in s.b); mz = min(k[2] for k in s.b)
        sx = max(k[0] for k in s.b) - mx + 1; sy = max(k[1] for k in s.b) - my + 1; sz = max(k[2] for k in s.b) - mz + 1
        palette, index, blocks = [], {}, []
        for (x, y, z), (n, p, nbt) in sorted(s.b.items()):
            key = (n, tuple(sorted(p.items())))
            if key not in index:
                index[key] = len(palette)
                e = {"Name": n}
                if p: e["Properties"] = {a: str(b) for a, b in p.items()}
                palette.append(e)
            blk = {"pos": [x - mx, y - my, z - mz], "state": index[key]}
            if nbt: blk["nbt"] = nbt
            blocks.append(blk)
        write_nbt(f"{DT}/structure/{name}.nbt", {"DataVersion": 4671, "size": [sx, sy, sz],
                  "palette": palette, "blocks": blocks, "entities": []})
        return (sx, sy, sz)

M = i("celestial_marble"); TT = i("temple_tiles"); RB = i("ruin_bricks"); AN = i("ancient_stone")
CB = i("celestial_bricks"); PL = i("celestial_planks"); LG = i("celestial_log"); LC = i("luminous_crystal")
SC = i("sacred_crystal"); AC = i("aurora_crystal_block")
sizes = {}

# 1) Templo celestial
t = T(); t.island(10, 10, 10, 7, 7)
t.box(3, 8, 3, 17, 8, 17, M); t.box(5, 8, 5, 15, 8, 15, TT)
for (x, z) in [(3, 3), (3, 17), (17, 3), (17, 17), (3, 10), (17, 10), (10, 3), (10, 17)]:
    t.box(x, 9, z, x, 14, z, M); t.set(x, 15, z, LC)
t.box(3, 15, 3, 17, 15, 17, TT)
t.air(4, 15, 4, 16, 15, 16); t.box(4, 15, 4, 16, 15, 4, TT); t.box(4, 15, 16, 16, 15, 16, TT)
t.box(4, 15, 4, 4, 15, 16, TT); t.box(16, 15, 4, 16, 15, 16, TT)
t.box(8, 9, 8, 12, 9, 12, AN); t.set(10, 10, 10, SC); t.box(9, 15, 9, 11, 15, 11, TT)
t.chest(10, 9, 14, "north", "celestial_temple"); t.chest(6, 9, 6, "south", "celestial_temple")
sizes["celestial_temple"] = t.save("celestial_temple")

# 2) Torre flotante
t = T(); t.island(6, 6, 6, 5, 5)
t.hollow(2, 6, 2, 10, 30, 10, CB)
for y in (12, 18, 24):
    t.box(3, y, 3, 9, y, 9, PL); t.air(3, y, 8, 3, y, 8)
for y in range(6, 30): t.set(3, y, 8, "minecraft:ladder", {"facing": "east", "waterlogged": "false"}) if y != 6 else None
t.air(6, 7, 2, 6, 8, 2)
for (x, z) in [(2, 2), (2, 10), (10, 2), (10, 10)]: t.box(x, 31, z, x, 32, z, M); t.set(x, 33, z, LC)
for y in (10, 16, 22, 28): t.air(6, y, 2, 6, y + 1, 2); t.air(6, y, 10, 6, y + 1, 10)
t.chest(8, 25, 4, "west", "floating_tower"); t.chest(8, 19, 4, "west", "floating_tower")
sizes["floating_tower"] = t.save("floating_tower")

# 3) Aldea suspendida
t = T(); t.island(14, 14, 14, 8, 8)
def hut(t, x0, z0, loot=None):
    t.hollow(x0, 9, z0, x0 + 4, 12, z0 + 4, PL)
    for (x, z) in [(x0, z0), (x0 + 4, z0), (x0, z0 + 4), (x0 + 4, z0 + 4)]: t.box(x, 9, z, x, 12, z, LG)
    t.box(x0 - 1, 13, z0 - 1, x0 + 5, 13, z0 + 5, TT)
    t.air(x0 + 2, 9, z0, x0 + 2, 10, z0); t.air(x0 + 4, 11, z0 + 2, x0 + 4, 11, z0 + 2)
    t.set(x0 + 2, 12, z0 + 2, LC)
    if loot: t.chest(x0 + 1, 9, z0 + 3, "north", loot)
hut(t, 5, 8, "village_house"); hut(t, 17, 8, None); hut(t, 11, 18, "village_house")
t.box(13, 9, 13, 15, 9, 15, M); t.set(14, 10, 14, AC)
for (x, z) in [(10, 14), (18, 14), (14, 5), (14, 22)]: t.box(x, 9, z, x, 10, z, LG); t.set(x, 11, z, LC)
sizes["suspended_village"] = t.save("suspended_village")

# 4) Santuario
t = T(); t.island(7, 7, 7, 4, 4)
t.box(3, 5, 3, 11, 5, 11, M); t.box(5, 5, 5, 9, 5, 9, TT)
for (x, z) in [(3, 3), (3, 11), (11, 3), (11, 11)]:
    t.box(x, 6, z, x, 9, z, M); t.set(x, 10, z, LC)
t.set(7, 6, 7, SC); t.set(7, 7, 7, SC); t.chest(7, 6, 9, "north", "sanctuary")
sizes["sanctuary"] = t.save("sanctuary")

# 5) Ruinas antiguas
rng = random.Random(404)
t = T(); t.island(9, 9, 8, 5, 5, top="celestial_grass")
t.disc(9, 9, 6, 6, AN)
for _ in range(22):
    x, z = rng.randint(2, 16), rng.randint(2, 16)
    if (x - 9) ** 2 + (z - 9) ** 2 <= 49:
        t.box(x, 7, z, x, 7 + rng.randint(0, 4), z, rng.choice([RB, RB, AN, M]))
for k in range(5, 14): t.set(k, 7, 4, RB); t.set(k, 7, 14, RB) if k % 2 else None
t.chest(9, 7, 9, "south", "ancient_ruins"); t.set(9, 8, 8, LC)
sizes["ancient_ruins"] = t.save("ancient_ruins")

# 6) Mina abandonada
t = T(); t.island(10, 10, 10, 9, 9)
t.air(9, 4, 0, 11, 6, 10)
for z in range(1, 11, 3):
    t.box(9, 4, z, 9, 6, z, LG); t.box(11, 4, z, 11, 6, z, LG); t.box(9, 7, z, 11, 7, z, PL) if False else None
    t.box(9, 6, z, 11, 6, z, PL)
t.set(8, 5, 6, i("essence_ore")); t.set(12, 4, 7, i("ether_ore")); t.set(8, 4, 9, i("essence_ore")); t.set(12, 5, 4, i("essence_ore"))
t.chest(10, 4, 10, "north", "abandoned_mine"); t.set(10, 4, 8, "minecraft:rail", {"shape": "north_south", "waterlogged": "false"})
t.set(10, 4, 5, "minecraft:rail", {"shape": "north_south", "waterlogged": "false"})
sizes["abandoned_mine"] = t.save("abandoned_mine")

# 7) Camara secreta
t = T(); t.island(8, 8, 7, 6, 6)
t.box(5, 1, 5, 11, 5, 11, AN); t.air(6, 2, 6, 10, 4, 10)
t.set(8, 2, 8, SC); t.set(6, 3, 6, LC); t.set(10, 3, 10, LC)
t.chest(8, 2, 10, "north", "secret_chamber"); t.chest(8, 2, 6, "south", "secret_chamber")
t.box(8, 8, 8, 8, 12, 8, LC)
sizes["secret_chamber"] = t.save("secret_chamber")

# 8) Mazmorra
t = T(); t.island(9, 9, 8, 7, 7)
t.box(5, 1, 5, 13, 6, 13, AN); t.air(6, 2, 6, 12, 5, 12); t.box(6, 1, 6, 12, 1, 12, RB)
t.set(9, 2, 9, "minecraft:spawner", None, {"id": "minecraft:mob_spawner", "SpawnCount": S(4), "SpawnRange": S(4),
    "RequiredPlayerRange": S(16), "Delay": S(20), "MinSpawnDelay": S(200), "MaxSpawnDelay": S(600), "MaxNearbyEntities": S(6),
    "SpawnData": {"entity": {"id": "celestial_dimension:celestial_harpy"}}})
t.air(12, 6, 9, 12, 8, 9)
t.chest(6, 2, 6, "east", "dungeon"); t.chest(12, 2, 12, "west", "dungeon")
sizes["dungeon"] = t.save("dungeon")

# 9) Santuario del Dragon Celestial
t = T(); t.island(20, 20, 20, 12, 12)
t.disc(20, 20, 13, 17, M); t.disc(20, 20, 13, 11, TT); t.disc(20, 20, 13, 4, AN)
t.box(18, 14, 18, 22, 14, 22, AN); t.box(19, 15, 19, 21, 15, 21, AN); t.set(20, 16, 20, i("dragon_altar"))
for n in range(8):
    a = n * math.pi / 4; x = 20 + round(14 * math.cos(a)); z = 20 + round(14 * math.sin(a))
    t.box(x, 14, z, x, 22, z, M); t.set(x, 23, z, LC)
for n in range(32):
    a = n * math.pi / 16; x = 20 + round(17 * math.cos(a)); z = 20 + round(17 * math.sin(a))
    t.set(x, 14, z, RB)
t.chest(20, 14, 12, "south", "dragon_sanctuary"); t.chest(20, 14, 28, "north", "dragon_sanctuary")
t.chest(12, 14, 20, "east", "dragon_sanctuary"); t.chest(28, 14, 20, "west", "dragon_sanctuary")
sizes["dragon_sanctuary"] = t.save("dragon_sanctuary")

# ---------------- pools, estructuras, sets, tags ----------------
ALL = ["celestial_meadows", "cloud_forest", "sacred_mountains", "luminous_gardens", "crystal_isles", "sky_ruins"]
STRUCTS = {  # nombre: (biomas, y_min, y_max, spacing, separation, salt, step)
 "celestial_temple":   (["celestial_meadows", "luminous_gardens", "sacred_mountains"], 80, 130, 20, 8, 1100101),
 "floating_tower":     (["cloud_forest", "celestial_meadows", "crystal_isles"], 60, 110, 18, 7, 1100102),
 "suspended_village":  (["celestial_meadows", "luminous_gardens", "cloud_forest"], 80, 125, 32, 12, 1100103),
 "sanctuary":          (ALL, 80, 135, 16, 6, 1100104),
 "ancient_ruins":      (["sky_ruins", "celestial_meadows", "sacred_mountains"], 80, 135, 14, 5, 1100105),
 "abandoned_mine":     (["sacred_mountains", "crystal_isles", "sky_ruins"], 80, 130, 24, 9, 1100106),
 "secret_chamber":     (ALL, 75, 130, 28, 10, 1100107),
 "dungeon":            (["sky_ruins", "sacred_mountains", "cloud_forest"], 80, 130, 20, 8, 1100108),
 "dragon_sanctuary":   (ALL, 85, 115, 40, 16, 1100109),
}
for name, (biomes, y0, y1, sp, sep, salt) in STRUCTS.items():
    wj(f"{DT}/worldgen/template_pool/{name}/start.json", {"name": i(f"{name}/start"), "fallback": "minecraft:empty",
       "elements": [{"weight": 1, "element": {"element_type": "minecraft:single_pool_element",
                     "location": i(name), "processors": "minecraft:empty", "projection": "rigid"}}]})
    wj(f"{DT}/tags/worldgen/biome/has_{name}.json", {"replace": False, "values": [i(b) for b in biomes]})
    wj(f"{DT}/worldgen/structure/{name}.json", {
      "type": "minecraft:jigsaw", "biomes": "#" + i(f"has_{name}"), "step": "surface_structures",
      "spawn_overrides": {}, "terrain_adaptation": "none", "start_pool": i(f"{name}/start"), "size": 1,
      "start_height": {"type": "minecraft:uniform", "min_inclusive": {"absolute": y0}, "max_inclusive": {"absolute": y1}},
      "max_distance_from_center": 80, "use_expansion_hack": False})
    wj(f"{DT}/worldgen/structure_set/{name}.json", {"structures": [{"structure": i(name), "weight": 1}],
      "placement": {"type": "minecraft:random_spread", "spacing": sp, "separation": sep, "salt": salt}})

# ---------------- loot tables ----------------
def item(n, w, lo=1, hi=1):
    e = {"type": "minecraft:item", "name": n, "weight": w}
    if hi > 1 or lo > 1:
        e["functions"] = [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": lo, "max": hi}}]
    return e
def loot(name, rolls, entries, bonus=None):
    pools = [{"rolls": {"type": "minecraft:uniform", "min": rolls[0], "max": rolls[1]}, "entries": entries}]
    if bonus: pools.append({"rolls": 1, "entries": bonus})
    wj(f"{DT}/loot_table/chests/{name}.json", {"type": "minecraft:chest", "pools": pools})
ES, AUR, ETH, SOL, DIV = i("celestial_essence"), i("aurora_crystal"), i("ether_shard"), i("solar_fragment"), i("divine_ingot")
loot("celestial_temple", (3, 6), [item(ES, 30, 2, 5), item(AUR, 12, 1, 3), item(ETH, 10, 1, 2), item("minecraft:golden_apple", 4),
     item("minecraft:iron_ingot", 15, 2, 5), item(i("celestial_marble"), 20, 4, 12), item("minecraft:amethyst_shard", 15, 2, 6)],
     [item(SOL, 1)])
loot("floating_tower", (3, 5), [item(ES, 25, 2, 4), item(ETH, 12, 1, 3), item("minecraft:arrow", 20, 6, 16),
     item("minecraft:ender_pearl", 5), item(i("solid_cloud"), 15, 4, 10), item("minecraft:gold_ingot", 12, 2, 5)])
loot("village_house", (2, 4), [item("minecraft:bread", 25, 2, 6), item("minecraft:apple", 20, 2, 5), item(ES, 15, 1, 3),
     item(i("celestial_planks"), 20, 4, 12), item("minecraft:amethyst_shard", 10, 1, 4), item("minecraft:iron_nugget", 15, 3, 9)])
loot("sanctuary", (2, 4), [item(ES, 25, 3, 6), item(AUR, 20, 2, 4), item(i("luminous_crystal"), 15, 2, 5),
     item("minecraft:experience_bottle", 10, 2, 5), item(ETH, 10, 1, 2)], [item(SOL, 1, 1, 2)])
loot("ancient_ruins", (2, 5), [item(ES, 20, 1, 4), item(i("ancient_stone"), 20, 4, 10), item("minecraft:bone", 15, 2, 6),
     item("minecraft:diamond", 3), item(ETH, 8, 1, 2), item("minecraft:gold_ingot", 10, 1, 4)])
loot("abandoned_mine", (2, 4), [item(i("essence_ore"), 25, 2, 6), item(i("ether_ore"), 10, 1, 3), item("minecraft:iron_ingot", 20, 2, 6),
     item("minecraft:torch", 20, 4, 12), item("minecraft:rail", 15, 6, 16), item("minecraft:iron_pickaxe", 4)])
loot("secret_chamber", (4, 7), [item(AUR, 25, 2, 5), item(ETH, 22, 2, 5), item(ES, 25, 4, 8), item(SOL, 8, 1, 2),
     item("minecraft:diamond", 8, 1, 3), item("minecraft:enchanted_golden_apple", 2)], [item(DIV, 1)])
loot("dungeon", (3, 5), [item(ES, 25, 2, 5), item(ETH, 15, 1, 3), item("minecraft:bone", 20, 3, 8), item("minecraft:arrow", 20, 8, 20),
     item("minecraft:iron_sword", 5), item("minecraft:golden_apple", 5), item(AUR, 10, 1, 3)], [item(SOL, 2)])
loot("dragon_sanctuary", (5, 8), [item(AUR, 25, 3, 6), item(ETH, 25, 3, 7), item(ES, 25, 6, 12), item(SOL, 12, 1, 3),
     item("minecraft:diamond", 10, 2, 5), item("minecraft:golden_apple", 8, 1, 3), item("minecraft:enchanted_golden_apple", 3)])

print(sizes)
