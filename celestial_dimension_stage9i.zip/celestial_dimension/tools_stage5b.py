import os, json, zlib, struct, random, math
ROOT = "/home/claude/cd/celestial_dimension"
NS = "celestial_dimension"
RES = f"{ROOT}/src/main/resources"
AS = f"{RES}/assets/{NS}"
DT = f"{RES}/data/{NS}"
def wj(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "w", encoding="utf-8").write(json.dumps(obj, indent=2, ensure_ascii=False) + "\n")
def rj(p): return json.load(open(p, encoding="utf-8"))
def i(n): return f"{NS}:{n}"
def png(path, W, H, px):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    raw = b"".join(b"\x00" + b"".join(bytes(px[y][x]) for x in range(W)) for y in range(H))
    def ch(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    open(path, "wb").write(b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", W, H, 8, 6, 0, 0, 0))
                           + ch(b"IDAT", zlib.compress(raw, 9)) + ch(b"IEND", b""))
def cl(v): return max(0, min(255, int(v)))
def sh(c, d): return (cl(c[0] + d), cl(c[1] + d), cl(c[2] + d), 255)

# ---------- iconos 16x16 ----------
def canvas(): return [[(0, 0, 0, 0) for _ in range(16)] for _ in range(16)]
def line(px, x0, y0, x1, y1, c, thick=1):
    n = max(abs(x1 - x0), abs(y1 - y0), 1)
    for k in range(n + 1):
        x = round(x0 + (x1 - x0) * k / n); y = round(y0 + (y1 - y0) * k / n)
        for dx in range(thick):
            for dy in range(thick):
                if 0 <= x + dx < 16 and 0 <= y + dy < 16: px[y + dy][x + dx] = c
def dots(px, pts, c):
    for (x, y) in pts:
        if 0 <= x < 16 and 0 <= y < 16: px[y][x] = c
def rows(px, spec, c, rnd):
    for y, spans in spec.items():
        for (a, b) in spans:
            for x in range(a, b + 1): px[y][x] = sh(c, rnd.randint(-10, 10) + (12 if y % 3 == 0 else 0))
BROWN = (120, 80, 40, 255); GOLD = (255, 215, 90, 255)
def icon_sword(c, hl, short=False):
    px = canvas()
    if short:
        line(px, 7, 9, 12, 4, sh(c, 0), 2); line(px, 7, 8, 12, 3, sh(hl, 0)); line(px, 5, 8, 8, 11, GOLD); line(px, 3, 12, 6, 9, BROWN); dots(px, [(2, 13)], GOLD)
    else:
        line(px, 6, 10, 13, 3, sh(c, 0), 2); line(px, 6, 9, 13, 2, sh(hl, 0)); line(px, 4, 8, 8, 12, GOLD); line(px, 2, 13, 6, 9, BROWN); dots(px, [(1, 14), (2, 14)], GOLD)
    return px
def icon_pick(c, hl):
    px = canvas(); line(px, 3, 13, 11, 5, BROWN, 1)
    dots(px, [(4, 5), (5, 4), (6, 3), (7, 3), (8, 3), (9, 3), (10, 4), (11, 5), (12, 6), (13, 7), (3, 6), (2, 7)], sh(c, 0))
    dots(px, [(6, 4), (7, 4), (8, 4), (9, 4)], sh(hl, 0)); return px
def icon_axe(c, hl):
    px = canvas(); line(px, 3, 13, 10, 6, BROWN, 1)
    dots(px, [(9, 3), (10, 2), (11, 2), (12, 3), (12, 4), (11, 5), (10, 6), (9, 5), (10, 4), (11, 4), (10, 3), (11, 3), (8, 4)], sh(c, 0))
    dots(px, [(10, 3), (11, 3)], sh(hl, 0)); return px
def icon_shovel(c, hl):
    px = canvas(); line(px, 3, 13, 10, 6, BROWN, 1)
    dots(px, [(10, 4), (11, 3), (12, 3), (13, 4), (13, 5), (12, 6), (11, 6), (10, 5), (11, 4), (12, 4), (12, 5), (11, 5)], sh(c, 0))
    dots(px, [(11, 4), (12, 4)], sh(hl, 0)); return px
def icon_hoe(c, hl):
    px = canvas(); line(px, 3, 13, 11, 5, BROWN, 1)
    dots(px, [(8, 3), (9, 3), (10, 3), (11, 3), (12, 4), (12, 5), (8, 4)], sh(c, 0)); dots(px, [(9, 3), (10, 3)], sh(hl, 0)); return px
def icon_bow(c, hl):
    px = canvas()
    dots(px, [(6, 1), (5, 2), (4, 3), (4, 4), (3, 5), (3, 6), (3, 7), (3, 8), (4, 9), (4, 10), (5, 11), (6, 12)], sh(c, 0))
    dots(px, [(5, 3), (4, 5), (4, 8), (5, 10)], sh(hl, 0)); line(px, 7, 1, 7, 12, (240, 240, 255, 255))
    line(px, 7, 6, 13, 6, (200, 200, 220, 255)); dots(px, [(13, 5), (13, 7), (14, 6)], GOLD); return px
def icon_armor(kind, c, hl, rnd):
    px = canvas()
    spec = {"helmet": {4: [(5, 10)], 5: [(4, 11)], 6: [(4, 11)], 7: [(4, 11)], 8: [(4, 5), (10, 11)], 9: [(4, 5), (10, 11)]},
            "chest": {3: [(3, 5), (10, 12)], 4: [(3, 12)], 5: [(2, 13)], 6: [(2, 13)], 7: [(3, 12)], 8: [(4, 11)], 9: [(4, 11)], 10: [(4, 11)], 11: [(4, 11)], 12: [(4, 11)]},
            "legs": {3: [(4, 11)], 4: [(4, 11)], 5: [(4, 11)], 6: [(4, 11)], 7: [(4, 7), (8, 11)], 8: [(4, 7), (8, 11)], 9: [(4, 6), (9, 11)], 10: [(4, 6), (9, 11)], 11: [(4, 6), (9, 11)], 12: [(4, 6), (9, 11)]},
            "boots": {7: [(3, 6), (9, 12)], 8: [(3, 6), (9, 12)], 9: [(3, 6), (9, 12)], 10: [(3, 6), (9, 12)], 11: [(2, 6), (9, 13)], 12: [(2, 6), (9, 13)]}}[kind]
    rows(px, spec, c, rnd)
    ys = sorted(spec); top = ys[0]
    for (a, b) in spec[top]:
        for x in range(a, b + 1): px[top][x] = sh(hl, 0)
    gem = {"helmet": (7, 6), "chest": (7, 6), "legs": (7, 5), "boots": (4, 10)}[kind]
    px[gem[1]][gem[0]] = GOLD; px[gem[1]][gem[0] + 1 if gem[0] + 1 < 16 else gem[0]] = sh(hl, 40)
    return px
def icon_scale(c):
    px = canvas(); rnd = random.Random(5)
    for (cx, cy) in ((8, 8), (5, 6), (11, 6), (5, 10), (11, 10), (8, 4), (8, 12)):
        for dx, dy in ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)):
            x, y = cx + dx, cy + dy
            if 0 <= x < 16 and 0 <= y < 16: px[y][x] = sh(c, rnd.randint(-12, 12) + (20 if dy < 0 else 0))
    return px
def icon_heart():
    px = canvas(); rnd = random.Random(9)
    for y, spans in {3: [(3, 6), (9, 12)], 4: [(2, 7), (8, 13)], 5: [(2, 13)], 6: [(2, 13)], 7: [(3, 12)], 8: [(4, 11)], 9: [(5, 10)], 10: [(6, 9)], 11: [(7, 8)]}.items():
        for (a, b) in spans:
            for x in range(a, b + 1): px[y][x] = sh((200, 40, 90), rnd.randint(-12, 12) - (y - 3) * 4)
    dots(px, [(4, 4), (5, 4), (4, 5)], (255, 200, 220, 255)); dots(px, [(7, 7), (8, 7), (7, 8)], GOLD); return px

AUR = ((90, 225, 245), (200, 255, 255)); DIV = ((255, 205, 80), (255, 245, 190))
ICONS = {
 "celestial_sword": icon_sword(*AUR), "ether_dagger": icon_sword((180, 120, 255), (235, 210, 255), True),
 "celestial_pickaxe": icon_pick(*AUR), "celestial_axe": icon_axe(*AUR), "celestial_shovel": icon_shovel(*AUR),
 "celestial_hoe": icon_hoe(*AUR), "light_bow": icon_bow((255, 235, 140), (255, 255, 220)),
 "dragon_scale": icon_scale((70, 120, 215)), "dragon_heart": icon_heart()}
rr = random.Random(33)
for k, nm in (("helmet", "helmet"), ("chest", "chestplate"), ("legs", "leggings"), ("boots", "boots")):
    ICONS[f"aurora_{nm}"] = icon_armor(k, AUR[0], AUR[1], rr)
    ICONS[f"divine_{nm}"] = icon_armor(k, DIV[0], DIV[1], rr)
for n, px in ICONS.items(): png(f"{AS}/textures/item/{n}.png", 16, 16, px)

# ---------- capas de armadura 64x32 ----------
def layer_tex(base, trim, seed, gem):
    r = random.Random(seed); px = [[(0, 0, 0, 0) for _ in range(64)] for _ in range(32)]
    for y in range(32):
        for x in range(64):
            n = r.randint(-9, 9)
            if (x + y) % 6 in (0, 1): n += 28
            if (x - y) % 8 == 0: n -= 22
            if y % 8 in (0, 7): px[y][x] = sh(trim, r.randint(-8, 8))
            else: px[y][x] = sh(base, n)
    for (gx, gy) in gem: px[gy][gx] = (255, 255, 255, 255)
    return px
for nm, base, trim, seed in (("aurora", (60, 205, 225), (235, 250, 255), 11), ("divine", (240, 190, 70), (255, 255, 235), 12)):
    gems = [(4, 5), (20, 18), (28, 18), (44, 5)]
    png(f"{AS}/textures/entity/equipment/humanoid/{nm}.png", 64, 32, layer_tex(base, trim, seed, gems))
    png(f"{AS}/textures/entity/equipment/humanoid_leggings/{nm}.png", 64, 32, layer_tex(base, trim, seed + 5, gems))
    wj(f"{AS}/equipment/{nm}.json", {"layers": {"humanoid": [{"texture": i(nm)}], "humanoid_leggings": [{"texture": i(nm)}]}})

# ---------- modelos / definiciones de items ----------
HANDHELD = ["celestial_sword", "ether_dagger", "celestial_pickaxe", "celestial_axe", "celestial_shovel", "celestial_hoe"]
FLAT = ["dragon_scale", "dragon_heart"] + [f"{s}_{p}" for s in ("aurora", "divine") for p in ("helmet", "chestplate", "leggings", "boots")]
for n in HANDHELD:
    wj(f"{AS}/models/item/{n}.json", {"parent": "minecraft:item/handheld", "textures": {"layer0": i(f"item/{n}")}})
    wj(f"{AS}/items/{n}.json", {"model": {"type": "minecraft:model", "model": i(f"item/{n}")}})
for n in FLAT:
    wj(f"{AS}/models/item/{n}.json", {"parent": "minecraft:item/generated", "textures": {"layer0": i(f"item/{n}")}})
    wj(f"{AS}/items/{n}.json", {"model": {"type": "minecraft:model", "model": i(f"item/{n}")}})
# arco con animacion de tension
for k in range(3):
    wj(f"{AS}/models/item/light_bow_pulling_{k}.json", {"parent": f"minecraft:item/bow_pulling_{k}", "textures": {"layer0": i("item/light_bow")}})
wj(f"{AS}/models/item/light_bow.json", {"parent": "minecraft:item/bow", "textures": {"layer0": i("item/light_bow")}})
wj(f"{AS}/items/light_bow.json", {"model": {"type": "minecraft:condition", "property": "minecraft:using_item",
  "on_false": {"type": "minecraft:model", "model": i("item/light_bow")},
  "on_true": {"type": "minecraft:range_dispatch", "property": "minecraft:use_duration", "scale": 0.05,
    "entries": [{"threshold": 0.65, "model": {"type": "minecraft:model", "model": i("item/light_bow_pulling_1")}},
                {"threshold": 0.9, "model": {"type": "minecraft:model", "model": i("item/light_bow_pulling_2")}}],
    "fallback": {"type": "minecraft:model", "model": i("item/light_bow_pulling_0")}}}})

# ---------- altar del dragon ----------
rr = random.Random(77); top = [[None] * 16 for _ in range(16)]
alt = [[(0, 0, 0, 255)] * 16 for _ in range(16)]
for y in range(16):
    for x in range(16):
        d = max(abs(x - 7.5), abs(y - 7.5)); n = rr.randint(-8, 8)
        c = (95, 100, 130)
        if d < 3: c = (255, 225, 110)
        elif int(d) % 3 == 0: c = (130, 90, 220)
        if (x + y) % 7 == 0: n += 18
        alt[y][x] = sh(c, n)
png(f"{AS}/textures/block/dragon_altar.png", 16, 16, alt)
wj(f"{AS}/blockstates/dragon_altar.json", {"variants": {"": {"model": i("block/dragon_altar")}}})
wj(f"{AS}/models/block/dragon_altar.json", {"parent": "minecraft:block/cube_all", "textures": {"all": i("block/dragon_altar")}})
wj(f"{AS}/items/dragon_altar.json", {"model": {"type": "minecraft:model", "model": i("block/dragon_altar")}})
wj(f"{DT}/loot_table/blocks/dragon_altar.json", {"type": "minecraft:block", "pools": [{"rolls": 1,
  "conditions": [{"condition": "minecraft:survives_explosion"}], "entries": [{"type": "minecraft:item", "name": i("dragon_altar")}]}]})
pk = rj(f"{RES}/data/minecraft/tags/block/mineable/pickaxe.json")
if i("dragon_altar") not in pk["values"]: pk["values"].append(i("dragon_altar"))
wj(f"{RES}/data/minecraft/tags/block/mineable/pickaxe.json", pk)

# ---------- tags ----------
wj(f"{DT}/tags/block/incorrect_for_celestial_tool.json", {"values": ["#minecraft:incorrect_for_diamond_tool"]})
wj(f"{DT}/tags/item/repairs_celestial_tools.json", {"values": [i("aurora_crystal")]})
wj(f"{DT}/tags/item/repairs_aurora_armor.json", {"values": [i("aurora_crystal")]})
wj(f"{DT}/tags/item/repairs_divine_armor.json", {"values": [i("divine_ingot")]})
def tag(name, vals): wj(f"{RES}/data/minecraft/tags/item/{name}.json", {"replace": False, "values": [i(v) for v in vals]})
tag("swords", ["celestial_sword", "ether_dagger"]); tag("pickaxes", ["celestial_pickaxe"]); tag("axes", ["celestial_axe"])
tag("shovels", ["celestial_shovel"]); tag("hoes", ["celestial_hoe"])
tag("head_armor", ["aurora_helmet", "divine_helmet"]); tag("chest_armor", ["aurora_chestplate", "divine_chestplate"])
tag("leg_armor", ["aurora_leggings", "divine_leggings"]); tag("foot_armor", ["aurora_boots", "divine_boots"])

# ---------- recetas ----------
def shaped(name, pattern, key, result, count=1):
    wj(f"{DT}/recipe/{name}.json", {"type": "minecraft:crafting_shaped", "category": "equipment", "pattern": pattern,
       "key": {k: (v if ":" in v else i(v)) for k, v in key.items()}, "result": {"id": i(result), "count": count}})
A = "aurora_crystal"
shaped("celestial_sword", ["A", "F", "S"], {"A": A, "F": "solar_fragment", "S": "minecraft:stick"}, "celestial_sword")
shaped("ether_dagger", ["E", "S"], {"E": "ether_shard", "S": "minecraft:stick"}, "ether_dagger")
shaped("light_bow", [" AS", "F S", " AS"], {"A": A, "F": "solar_fragment", "S": "minecraft:string"}, "light_bow")
shaped("celestial_pickaxe", ["AAA", " S ", " S "], {"A": A, "S": "minecraft:stick"}, "celestial_pickaxe")
shaped("celestial_axe", ["AA", "AS", " S"], {"A": A, "S": "minecraft:stick"}, "celestial_axe")
shaped("celestial_shovel", ["A", "S", "S"], {"A": A, "S": "minecraft:stick"}, "celestial_shovel")
shaped("celestial_hoe", ["AA", " S", " S"], {"A": A, "S": "minecraft:stick"}, "celestial_hoe")
shaped("aurora_helmet", ["AAA", "A A"], {"A": A}, "aurora_helmet")
shaped("aurora_chestplate", ["A A", "AAA", "AAA"], {"A": A}, "aurora_chestplate")
shaped("aurora_leggings", ["AAA", "A A", "A A"], {"A": A}, "aurora_leggings")
shaped("aurora_boots", ["A A", "A A"], {"A": A}, "aurora_boots")
I = "divine_ingot"
shaped("divine_helmet", ["III", "IDI"], {"I": I, "D": "dragon_scale"}, "divine_helmet")
shaped("divine_chestplate", ["I I", "IHI", "III"], {"I": I, "H": "dragon_heart"}, "divine_chestplate")
shaped("divine_leggings", ["III", "IDI", "I I"], {"I": I, "D": "dragon_scale"}, "divine_leggings")
shaped("divine_boots", ["I I", "D D"], {"I": I, "D": "dragon_scale"}, "divine_boots")

# ---------- loot de criaturas ----------
def it(n, w, lo=1, hi=1, chance=None):
    e = {"type": "minecraft:item", "name": n if ":" in n else i(n), "weight": w}
    fn = []
    if hi > 1 or lo > 1: fn.append({"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": lo, "max": hi}})
    if fn: e["functions"] = fn
    return e
def pool(entries, rolls=1, chance=None):
    p = {"rolls": rolls, "entries": entries}
    if chance is not None: p["conditions"] = [{"condition": "minecraft:random_chance", "chance": chance}]
    return p
def loot(n, pools): wj(f"{DT}/loot_table/entities/{n}.json", {"type": "minecraft:entity", "pools": pools})
loot("guardian_angel", [pool([it("celestial_essence", 1, 1, 3)]), pool([it("minecraft:amethyst_shard", 1, 1, 3)], 1, 0.6), pool([it("aurora_crystal", 1)], 1, 0.15)])
loot("celestial_griffin", [pool([it("minecraft:feather", 1, 2, 4)]), pool([it("minecraft:beef", 1, 1, 3)]), pool([it("celestial_essence", 1, 1, 2)], 1, 0.4)])
loot("cloud_spirit", [pool([it("solid_cloud", 1, 1, 2)]), pool([it("celestial_essence", 1)], 1, 0.35)])
loot("crystal_golem", [pool([it("aurora_crystal", 1, 1, 3)]), pool([it("luminous_crystal", 1, 1, 2)]), pool([it("ether_shard", 1, 1, 2)], 1, 0.5), pool([it("celestial_essence", 1, 1, 3)])])
loot("celestial_harpy", [pool([it("minecraft:feather", 1, 1, 3)]), pool([it("minecraft:bone", 1, 0, 2)]), pool([it("celestial_essence", 1)], 1, 0.3)])
loot("luminous_deer", [pool([it("minecraft:leather", 1, 0, 2)]), pool([it("minecraft:beef", 1, 1, 2)]), pool([it("celestial_essence", 1, 1, 2)], 1, 0.5)])
loot("sky_serpent", [pool([it("minecraft:spider_eye", 1, 1, 2)]), pool([it("celestial_essence", 1, 1, 2)]), pool([it("ether_shard", 1)], 1, 0.3)])
loot("celestial_dragon", [pool([it("dragon_scale", 1, 8, 14)]), pool([it("divine_ingot", 1, 3, 5)]), pool([it("dragon_heart", 1)]),
    pool([it("solar_fragment", 1, 4, 8)]), pool([it("minecraft:experience_bottle", 1, 24, 40)]), pool([it("minecraft:enchanted_golden_apple", 1)], 1, 0.5)])

# ---------- spawn por bioma ----------
def sp(t, w, lo, hi): return {"type": i(t), "weight": w, "minCount": lo, "maxCount": hi}
SPAWN = {
 "celestial_meadows": ({"creature": [sp("luminous_deer", 6, 1, 3), sp("cloud_spirit", 8, 1, 2), sp("celestial_griffin", 2, 1, 1)]}, {"monster": [sp("celestial_harpy", 2, 1, 1)]}),
 "cloud_forest": ({"creature": [sp("cloud_spirit", 10, 1, 3), sp("luminous_deer", 3, 1, 2), sp("celestial_griffin", 3, 1, 1)]}, {"monster": [sp("sky_serpent", 3, 1, 1), sp("celestial_harpy", 3, 1, 2)]}),
 "sacred_mountains": ({"creature": [sp("guardian_angel", 4, 1, 1), sp("celestial_griffin", 4, 1, 1)]}, {"monster": [sp("crystal_golem", 3, 1, 1), sp("celestial_harpy", 4, 1, 2)]}),
 "luminous_gardens": ({"creature": [sp("luminous_deer", 12, 2, 4), sp("cloud_spirit", 6, 1, 2), sp("guardian_angel", 2, 1, 1)]}, {}),
 "crystal_isles": ({"creature": [sp("cloud_spirit", 4, 1, 2)]}, {"monster": [sp("crystal_golem", 6, 1, 1), sp("sky_serpent", 2, 1, 1)]}),
 "sky_ruins": ({"creature": [sp("guardian_angel", 3, 1, 1)]}, {"monster": [sp("crystal_golem", 4, 1, 1), sp("celestial_harpy", 6, 1, 2), sp("sky_serpent", 4, 1, 1)]})}
for b, (c, m) in SPAWN.items():
    p = f"{DT}/worldgen/biome/{b}.json"; d = rj(p)
    d["spawners"]["creature"] = c.get("creature", []); d["spawners"]["monster"] = m.get("monster", [])
    wj(p, d)

# ---------- idiomas ----------
NEW = {
 "entity.guardian_angel": ("Ángel Guardián", "Guardian Angel"), "entity.celestial_griffin": ("Grifo Celestial", "Celestial Griffin"),
 "entity.celestial_dragon": ("Dragón Celestial", "Celestial Dragon"), "entity.cloud_spirit": ("Espíritu de las Nubes", "Cloud Spirit"),
 "entity.crystal_golem": ("Gólem de Cristal", "Crystal Golem"), "entity.celestial_harpy": ("Arpía Celestial", "Celestial Harpy"),
 "entity.luminous_deer": ("Ciervo Luminoso", "Luminous Deer"), "entity.sky_serpent": ("Serpiente de las Alturas", "Sky Serpent"),
 "block.dragon_altar": ("Altar del Dragón", "Dragon Altar"),
 "item.dragon_scale": ("Escama del Dragón", "Dragon Scale"), "item.dragon_heart": ("Corazón del Dragón", "Dragon Heart"),
 "item.celestial_sword": ("Espada Celestial", "Celestial Sword"), "item.ether_dagger": ("Daga de Éter", "Ether Dagger"),
 "item.light_bow": ("Arco de Luz", "Bow of Light"), "item.celestial_pickaxe": ("Pico Celestial", "Celestial Pickaxe"),
 "item.celestial_axe": ("Hacha Celestial", "Celestial Axe"), "item.celestial_shovel": ("Pala Celestial", "Celestial Shovel"),
 "item.celestial_hoe": ("Azada Celestial", "Celestial Hoe"),
 "item.aurora_helmet": ("Casco de Cristal de Aurora", "Aurora Crystal Helmet"), "item.aurora_chestplate": ("Peto de Cristal de Aurora", "Aurora Crystal Chestplate"),
 "item.aurora_leggings": ("Pantalones de Cristal de Aurora", "Aurora Crystal Leggings"), "item.aurora_boots": ("Botas de Cristal de Aurora", "Aurora Crystal Boots"),
 "item.divine_helmet": ("Casco Divino", "Divine Helmet"), "item.divine_chestplate": ("Peto Divino", "Divine Chestplate"),
 "item.divine_leggings": ("Pantalones Divinos", "Divine Leggings"), "item.divine_boots": ("Botas Divinas", "Divine Boots"),
 "message.dragon_phase_1": ("El Dragón Celestial despierta", "The Celestial Dragon awakens"),
 "message.dragon_phase_2": ("¡El Dragón Celestial alza el vuelo!", "The Celestial Dragon takes flight!"),
 "message.dragon_phase_3": ("¡El Dragón Celestial entra en furia!", "The Celestial Dragon is enraged!"),
 "message.cooldown": ("Habilidad en enfriamiento", "Ability on cooldown"),
 "message.altar_needs_fragment": ("Necesitas un Fragmento Solar", "You need a Solar Fragment"),
 "message.dragon_exists": ("El Dragón Celestial ya está despierto", "The Celestial Dragon is already awake")}
for lang, idx in (("es_es", 0), ("en_us", 1)):
    p = f"{AS}/lang/{lang}.json"; d = rj(p)
    for k, v in NEW.items():
        pre, rest = k.split(".", 1); d[f"{pre}.{NS}.{rest}"] = v[idx]
    wj(p, d)

# ---------- fabric.mod.json: entrada de cliente ----------
fm = rj(f"{RES}/fabric.mod.json")
fm["entrypoints"]["client"] = ["com.celestialdimension.client.CelestialDimensionClient"]
fm["description"] = "Aventura completa: el Reino Celestial, biomas, estructuras, criaturas, el Dragon Celestial y equipamiento."
wj(f"{RES}/fabric.mod.json", fm)

rd = open(f"{ROOT}/README.md").read()
open(f"{ROOT}/README.md", "w").write(rd + """
## Etapas 4 a 8
- Etapa 4: 9 estructuras (ver arriba) con loot tables. /locate structure celestial_dimension:<nombre>
- Etapa 5: 8 criaturas con modelo 3D propio, textura PNG pintada desde el mismo diseno, animaciones, IA, drops y aparicion por bioma.
  Invocar: /summon celestial_dimension:celestial_harpy (etc.)
- Etapa 6: Dragon Celestial (3 fases, vuelo/aterrizaje, rayos, lluvia de energia, onda de choque, invocacion de arpias, barra de jefe).
  Se invoca con un Fragmento Solar sobre el Altar del Dragon (centro del Santuario del Dragon Celestial).
- Etapa 7: armaduras de Cristal de Aurora y Divina (bono de set), Espada Celestial (rafaga), Daga de Eter (salto), Arco de Luz, 4 herramientas.
- Etapa 8: particulas (portal, cristales, altar, criaturas). Sonidos: vanilla (los propios quedan fuera por peticion).
""")
print("stage5b ok")
