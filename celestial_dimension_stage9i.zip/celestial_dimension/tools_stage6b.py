import os, json, zlib, struct, random, math
ROOT = "/home/claude/cd/celestial_dimension"
NS = "celestial_dimension"
RES = f"{ROOT}/src/main/resources"
AS = f"{RES}/assets/{NS}"
DT = f"{RES}/data/{NS}"
def wj(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "w", encoding="utf-8").write(json.dumps(obj, indent=2, ensure_ascii=False) + "\n")
def rj(p): return json.load(open(p, encoding="utf-8"))
def i(n): return f"{NS}:{n}"
def png(path, W, H, px):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    raw = b"".join(b"\x00" + b"".join(bytes(px[y][x]) for x in range(W)) for y in range(H))
    def ch(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    open(path, "wb").write(b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", W, H, 8, 6, 0, 0, 0))
                           + ch(b"IDAT", zlib.compress(raw, 9)) + ch(b"IEND", b""))
def cl(v): return max(0, min(255, int(v)))
def sh(c, d): return (cl(c[0] + d), cl(c[1] + d), cl(c[2] + d), 255)
def canvas(): return [[(0, 0, 0, 0) for _ in range(16)] for _ in range(16)]
def put(px, x, y, c):
    if 0 <= x < 16 and 0 <= y < 16: px[y][x] = c
def line(px, x0, y0, x1, y1, c):
    n = max(abs(x1 - x0), abs(y1 - y0), 1)
    for k in range(n + 1): put(px, round(x0 + (x1 - x0) * k / n), round(y0 + (y1 - y0) * k / n), c)

STEM = (70, 170, 130, 255); STEM2 = (45, 130, 105, 255)
# ---------- texturas de vegetacion ----------
def t_tuft():
    px = canvas(); r = random.Random(1)
    for x, h in ((2, 7), (4, 10), (6, 8), (7, 12), (9, 9), (11, 11), (13, 7)):
        for k in range(h):
            c = sh((90, 205, 190), 30 * k // h - 14 + r.randint(-6, 6)); put(px, x + (1 if k > h - 3 else 0) * (1 if x % 2 else -1), 15 - k, c)
    return px
def t_fern():
    px = canvas(); line(px, 8, 15, 8, 6, STEM2)
    for k in range(5):
        y = 14 - k * 2; ln = 5 - k // 2
        for s in (-1, 1):
            for j in range(1, ln + 1): put(px, 8 + s * j, y - j // 2, sh((60, 190, 170), 10 * j))
    for (x, y) in ((3, 8), (13, 8), (5, 6), (11, 6), (8, 5)): put(px, x, y, (170, 255, 245, 255))
    return px
def t_bloom():
    px = canvas(); line(px, 8, 15, 8, 8, STEM); put(px, 6, 13, STEM2); put(px, 10, 12, STEM2); put(px, 7, 12, STEM2)
    for (x, y) in ((8, 3), (6, 5), (10, 5), (7, 7), (9, 7), (8, 4), (7, 5), (9, 5)): put(px, x, y, sh((70, 140, 255), 12 if y < 5 else 0))
    put(px, 8, 5, (255, 225, 110, 255)); put(px, 8, 6, (255, 200, 80, 255)); return px
def t_lily():
    px = canvas(); line(px, 8, 15, 8, 8, STEM)
    for (x, y) in ((8, 2), (8, 3), (7, 4), (9, 4), (5, 5), (11, 5), (6, 6), (10, 6), (4, 7), (12, 7), (7, 5), (9, 5), (8, 4), (8, 5), (8, 6), (7, 6), (9, 6), (6, 7), (10, 7)):
        put(px, x, y, sh((255, 205, 80), -20 if y > 5 else 10))
    for (x, y) in ((8, 6), (8, 7)): put(px, x, y, (255, 120, 40, 255))
    put(px, 6, 12, STEM2); put(px, 10, 11, STEM2); return px
def t_orchid():
    px = canvas(); line(px, 4, 15, 6, 9, STEM); line(px, 6, 9, 10, 5, STEM); line(px, 10, 5, 12, 6, STEM)
    for (cx, cy) in ((6, 8), (9, 5), (12, 6)):
        for dx, dy in ((0, 0), (-1, 0), (1, 0), (0, -1), (0, 1)): put(px, cx + dx, cy + dy, sh((190, 100, 240), 10 if dy < 0 else -5))
        put(px, cx, cy, (255, 240, 255, 255))
    put(px, 5, 13, STEM2); put(px, 3, 12, STEM2); return px
def t_cotton():
    px = canvas(); r = random.Random(7)
    for x in (4, 8, 12): line(px, x, 15, x, 9, STEM2)
    for (cx, cy) in ((4, 7), (8, 5), (12, 7), (6, 9), (10, 9), (8, 8)):
        for dx in range(-2, 3):
            for dy in range(-2, 3):
                if dx * dx + dy * dy <= 4: put(px, cx + dx, cy + dy, sh((245, 250, 255), -r.randint(0, 18) - (8 if dy > 0 else 0)))
    return px
def t_sprout():
    px = canvas()
    for x, h, c in ((4, 7, (110, 225, 255)), (7, 12, (150, 240, 255)), (10, 9, (100, 215, 250)), (12, 6, (170, 245, 255))):
        for k in range(h):
            w = 2 if k < h - 3 else 1
            for dx in range(w): put(px, x + dx, 15 - k, sh(c, -10 if dx else 18))
        put(px, x, 15 - h, (235, 255, 255, 255))
    return px
def t_tulip():
    px = canvas(); line(px, 8, 15, 8, 8, STEM); put(px, 7, 12, STEM2); put(px, 6, 11, STEM2); put(px, 9, 13, STEM2); put(px, 10, 12, STEM2)
    for (x, y) in ((6, 4), (7, 3), (8, 3), (9, 3), (10, 4), (6, 5), (7, 5), (8, 5), (9, 5), (10, 5), (7, 6), (8, 6), (9, 6), (8, 7), (7, 4), (8, 4), (9, 4)):
        put(px, x, y, sh((200, 190, 255), 25 if y < 5 else -10))
    put(px, 8, 4, (255, 255, 255, 255)); return px
def t_sapling():
    px = canvas(); r = random.Random(3)
    line(px, 8, 15, 8, 9, (130, 100, 70, 255)); put(px, 7, 13, (110, 85, 60, 255))
    for dx in range(-3, 4):
        for dy in range(-3, 3):
            if dx * dx + dy * dy * 1.3 <= 9: put(px, 8 + dx, 6 + dy, sh((70, 190, 165), r.randint(-14, 14) + (10 if dy < 0 else 0)))
    put(px, 6, 5, (170, 255, 235, 255)); put(px, 10, 7, (170, 255, 235, 255)); return px
def t_leaves():
    px = canvas(); r = random.Random(11)
    for y in range(16):
        for x in range(16):
            if r.random() < 0.22: continue
            n = r.randint(-16, 16)
            if (x + y) % 5 == 0: n += 26
            put(px, x, y, sh((72, 182, 160), n))
    return px
PLANTS = {"grass_tuft": t_tuft, "glow_fern": t_fern, "azure_bloom": t_bloom, "sun_lily": t_lily, "aether_orchid": t_orchid,
          "cloud_cotton": t_cotton, "crystal_sprout": t_sprout, "moon_tulip": t_tulip, "celestial_sapling": t_sapling}
for n, f in PLANTS.items():
    png(f"{AS}/textures/block/{n}.png", 16, 16, f())
    wj(f"{AS}/blockstates/{n}.json", {"variants": {"": {"model": i(f"block/{n}")}}})
    wj(f"{AS}/models/block/{n}.json", {"parent": "minecraft:block/cross", "textures": {"cross": i(f"block/{n}")}})
    wj(f"{AS}/models/item/{n}.json", {"parent": "minecraft:item/generated", "textures": {"layer0": i(f"block/{n}")}})
    wj(f"{AS}/items/{n}.json", {"model": {"type": "minecraft:model", "model": i(f"item/{n}")}})
    wj(f"{DT}/loot_table/blocks/{n}.json", {"type": "minecraft:block", "pools": [{"rolls": 1,
       "conditions": [{"condition": "minecraft:survives_explosion"}], "entries": [{"type": "minecraft:item", "name": i(n)}]}]})
png(f"{AS}/textures/block/celestial_leaves.png", 16, 16, t_leaves())
wj(f"{DT}/loot_table/blocks/celestial_leaves.json", {"type": "minecraft:block", "pools": [
  {"rolls": 1, "conditions": [{"condition": "minecraft:survives_explosion"}], "entries": [{"type": "minecraft:item", "name": i("celestial_leaves")}]},
  {"rolls": 1, "conditions": [{"condition": "minecraft:random_chance", "chance": 0.1}], "entries": [{"type": "minecraft:item", "name": i("celestial_sapling")}]},
  {"rolls": 1, "conditions": [{"condition": "minecraft:random_chance", "chance": 0.2}], "entries": [{"type": "minecraft:item", "name": "minecraft:stick"}]}]})

# ---------- huevos de aparicion ----------
EGG = {"guardian_angel": ((240, 240, 255), (255, 215, 90)), "celestial_griffin": ((205, 160, 90), (245, 245, 250)),
 "celestial_dragon": ((60, 105, 200), (255, 215, 90)), "cloud_spirit": ((240, 246, 255), (110, 170, 245)),
 "crystal_golem": ((135, 148, 185), (110, 225, 255)), "celestial_harpy": ((150, 120, 190), (255, 150, 200)),
 "luminous_deer": ((235, 225, 200), (120, 235, 235)), "sky_serpent": ((60, 190, 160), (160, 110, 230)),
 "celestial_pig": ((140, 195, 240), (255, 200, 220)), "celestial_cow": ((235, 245, 255), (95, 150, 220)),
 "celestial_sheep": ((232, 244, 255), (255, 215, 120)), "celestial_chicken": ((240, 248, 255), (90, 200, 250)),
 "celestial_llama": ((238, 236, 225), (150, 120, 230)), "celestial_goat": ((232, 242, 255), (235, 200, 110)),
 "cloud_manta": ((120, 180, 245), (235, 245, 255)), "celestial_pegasus": ((240, 246, 255), (255, 215, 90))}
spans = {3: (7, 8), 4: (6, 9), 5: (5, 10), 6: (4, 11), 7: (4, 11), 8: (4, 11), 9: (4, 11), 10: (5, 10), 11: (6, 9), 12: (7, 8)}
for name, (a, b) in EGG.items():
    px = canvas(); r = random.Random(sum(map(ord, name)))
    for y, (x0, x1) in spans.items():
        for x in range(x0, x1 + 1):
            edge = x in (x0, x1) or y in (3, 12)
            px[y][x] = sh(a, -45 if edge else (22 if (x - 4 < 3 and y < 7) else 0))
    for _ in range(9):
        y = r.randint(4, 11); x0, x1 = spans[y]; x = r.randint(x0 + 1, x1 - 1)
        px[y][x] = sh(b, 0)
    png(f"{AS}/textures/item/{name}_spawn_egg.png", 16, 16, px)
    wj(f"{AS}/models/item/{name}_spawn_egg.json", {"parent": "minecraft:item/generated", "textures": {"layer0": i(f"item/{name}_spawn_egg")}})
    wj(f"{AS}/items/{name}_spawn_egg.json", {"model": {"type": "minecraft:model", "model": i(f"item/{name}_spawn_egg")}})

# ---------- arboles nuevos ----------
def prov(n): return {"type": "minecraft:simple_state_provider", "state": {"Name": i(n)}}
def tree(name, trunk, foliage, size):
    wj(f"{DT}/worldgen/configured_feature/{name}.json", {"type": "minecraft:tree", "config": {
      "trunk_provider": prov("celestial_log"), "foliage_provider": prov("celestial_leaves"), "dirt_provider": prov("celestial_dirt"),
      "trunk_placer": trunk, "foliage_placer": foliage, "minimum_size": size, "ignore_vines": True, "decorators": []}})
size2 = {"type": "minecraft:two_layers_feature_size", "limit": 1, "lower_size": 0, "upper_size": 1}
tree("celestial_pine", {"type": "minecraft:straight_trunk_placer", "base_height": 8, "height_rand_a": 3, "height_rand_b": 2},
     {"type": "minecraft:spruce_foliage_placer", "radius": 2, "offset": 0, "trunk_height": {"type": "minecraft:uniform", "min_inclusive": 1, "max_inclusive": 2}}, size2)
tree("celestial_umbrella", {"type": "minecraft:forking_trunk_placer", "base_height": 5, "height_rand_a": 2, "height_rand_b": 2},
     {"type": "minecraft:acacia_foliage_placer", "radius": 2, "offset": 0}, size2)
tree("giant_celestial_tree", {"type": "minecraft:giant_trunk_placer", "base_height": 16, "height_rand_a": 4, "height_rand_b": 6},
     {"type": "minecraft:mega_pine_foliage_placer", "radius": 0, "offset": 0, "crown_height": {"type": "minecraft:uniform", "min_inclusive": 5, "max_inclusive": 9}},
     {"type": "minecraft:two_layers_feature_size", "limit": 1, "lower_size": 1, "upper_size": 2})

def hr(lo, hi): return {"type": "minecraft:height_range", "height": {"type": "minecraft:uniform", "min_inclusive": {"absolute": lo}, "max_inclusive": {"absolute": hi}}}
scan = {"type": "minecraft:environment_scan", "direction_of_search": "down", "target_condition": {"type": "minecraft:solid"},
        "allowed_search_condition": {"type": "minecraft:matching_blocks", "blocks": "minecraft:air"}, "max_steps": 24}
def on(b): return {"type": "minecraft:block_predicate_filter", "predicate": {"type": "minecraft:matching_blocks", "blocks": i(b), "offset": [0, -1, 0]}}
def placed(name, feat, count, base):
    wj(f"{DT}/worldgen/placed_feature/{name}.json", {"feature": i(feat), "placement": [{"type": "minecraft:count", "count": count},
       {"type": "minecraft:in_square"}, hr(55, 175), scan, on(base), {"type": "minecraft:biome"}]})
for p in PLANTS:
    if p == "celestial_sapling": continue
    wj(f"{DT}/worldgen/configured_feature/plant_{p}.json", {"type": "minecraft:simple_block", "config": {"to_place": prov(p)}})

# vegetacion por bioma: (placed_name, feature, count, base)
VEG = {
 "celestial_meadows": [("m_pine", "celestial_pine", 2, "celestial_grass"), ("m_tuft", "plant_grass_tuft", 30, "celestial_grass"),
    ("m_bloom", "plant_azure_bloom", 10, "celestial_grass"), ("m_tulip", "plant_moon_tulip", 6, "celestial_grass"), ("m_cotton", "plant_cloud_cotton", 5, "celestial_grass")],
 "cloud_forest": [("f_giant", "giant_celestial_tree", 2, "celestial_grass"), ("f_umbrella", "celestial_umbrella", 4, "celestial_grass"),
    ("f_fern", "plant_glow_fern", 14, "celestial_grass"), ("f_cotton", "plant_cloud_cotton", 10, "celestial_grass"),
    ("f_orchid", "plant_aether_orchid", 4, "celestial_grass"), ("f_tuft", "plant_grass_tuft", 20, "celestial_grass")],
 "sacred_mountains": [("s_sprout", "plant_crystal_sprout", 8, "celestial_marble"), ("s_tulip", "plant_moon_tulip", 3, "celestial_marble")],
 "luminous_gardens": [("g_bloom", "plant_azure_bloom", 25, "celestial_grass"), ("g_lily", "plant_sun_lily", 18, "celestial_grass"),
    ("g_orchid", "plant_aether_orchid", 14, "celestial_grass"), ("g_fern", "plant_glow_fern", 16, "celestial_grass"),
    ("g_tulip", "plant_moon_tulip", 14, "celestial_grass"), ("g_tuft", "plant_grass_tuft", 25, "celestial_grass"),
    ("g_umbrella", "celestial_umbrella", 4, "celestial_grass"), ("g_pine", "celestial_pine", 3, "celestial_grass")],
 "crystal_isles": [("c_sprout", "plant_crystal_sprout", 20, "celestial_sand"), ("c_tulip", "plant_moon_tulip", 6, "celestial_sand")],
 "sky_ruins": [("r_fern", "plant_glow_fern", 6, "ancient_stone"), ("r_tuft", "plant_grass_tuft", 6, "ancient_stone")]}
for b, lst in VEG.items():
    d = rj(f"{DT}/worldgen/biome/{b}.json")
    for (pn, feat, c, base) in lst:
        placed(pn, feat, c, base)
        if i(pn) not in d["features"][9]: d["features"][9].append(i(pn))
    wj(f"{DT}/worldgen/biome/{b}.json", d)

# ---------- aparicion (rara para hostiles) ----------
def sp(t, w, lo, hi): return {"type": i(t), "weight": w, "minCount": lo, "maxCount": hi}
CRE = {
 "celestial_meadows": [("luminous_deer", 5, 1, 3), ("cloud_spirit", 6, 1, 2), ("celestial_griffin", 1, 1, 1), ("celestial_pig", 8, 2, 4),
    ("celestial_cow", 8, 2, 4), ("celestial_sheep", 8, 2, 4), ("celestial_chicken", 8, 2, 4), ("celestial_llama", 3, 1, 3),
    ("celestial_goat", 3, 1, 3), ("cloud_manta", 3, 1, 2), ("celestial_pegasus", 2, 1, 2)],
 "cloud_forest": [("cloud_spirit", 8, 1, 3), ("luminous_deer", 3, 1, 2), ("celestial_griffin", 2, 1, 1), ("celestial_pig", 4, 2, 3),
    ("celestial_sheep", 4, 2, 3), ("celestial_chicken", 6, 2, 4), ("cloud_manta", 8, 1, 3), ("celestial_pegasus", 3, 1, 2), ("celestial_llama", 2, 1, 2)],
 "sacred_mountains": [("guardian_angel", 3, 1, 1), ("celestial_griffin", 3, 1, 1), ("celestial_goat", 10, 2, 4), ("celestial_llama", 6, 1, 3),
    ("celestial_sheep", 3, 2, 3), ("celestial_pegasus", 2, 1, 2), ("cloud_manta", 2, 1, 2)],
 "luminous_gardens": [("luminous_deer", 10, 2, 4), ("cloud_spirit", 5, 1, 2), ("guardian_angel", 2, 1, 1), ("celestial_pig", 5, 2, 3),
    ("celestial_cow", 5, 2, 3), ("celestial_sheep", 5, 2, 3), ("celestial_chicken", 8, 2, 4), ("celestial_goat", 3, 1, 2),
    ("cloud_manta", 5, 1, 2), ("celestial_pegasus", 2, 1, 2)],
 "crystal_isles": [("cloud_spirit", 4, 1, 2), ("cloud_manta", 6, 1, 2), ("celestial_goat", 3, 1, 2), ("celestial_llama", 2, 1, 2)],
 "sky_ruins": [("guardian_angel", 3, 1, 1), ("celestial_goat", 4, 1, 2), ("celestial_llama", 2, 1, 2)]}
MON = {
 "celestial_meadows": [("celestial_harpy", 1, 1, 1)],
 "cloud_forest": [("sky_serpent", 1, 1, 1), ("celestial_harpy", 1, 1, 1)],
 "sacred_mountains": [("crystal_golem", 2, 1, 1), ("celestial_harpy", 1, 1, 1)],
 "luminous_gardens": [],
 "crystal_isles": [("crystal_golem", 3, 1, 1), ("sky_serpent", 1, 1, 1)],
 "sky_ruins": [("crystal_golem", 3, 1, 1), ("celestial_harpy", 2, 1, 1), ("sky_serpent", 2, 1, 1)]}
for b in CRE:
    d = rj(f"{DT}/worldgen/biome/{b}.json")
    d["spawners"]["creature"] = [sp(*x) for x in CRE[b]]
    d["spawners"]["monster"] = [sp(*x) for x in MON[b]]
    wj(f"{DT}/worldgen/biome/{b}.json", d)

# ---------- botin de las criaturas nuevas ----------
def it(n, w=1, lo=1, hi=1):
    e = {"type": "minecraft:item", "name": n if ":" in n else i(n), "weight": w}
    if hi > 1 or lo != 1: e["functions"] = [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": lo, "max": hi}}]
    return e
def pool(entries, chance=None):
    p = {"rolls": 1, "entries": entries}
    if chance is not None: p["conditions"] = [{"condition": "minecraft:random_chance", "chance": chance}]
    return p
def loot(n, pools): wj(f"{DT}/loot_table/entities/{n}.json", {"type": "minecraft:entity", "pools": pools})
loot("celestial_pig", [pool([it("minecraft:porkchop", 1, 1, 3)]), pool([it("celestial_essence")], 0.3)])
loot("celestial_cow", [pool([it("minecraft:leather", 1, 0, 2)]), pool([it("minecraft:beef", 1, 1, 3)]), pool([it("celestial_essence")], 0.3)])
loot("celestial_sheep", [pool([it("minecraft:light_blue_wool", 1, 1, 2)]), pool([it("minecraft:mutton", 1, 1, 2)]), pool([it("celestial_essence")], 0.3)])
loot("celestial_chicken", [pool([it("minecraft:feather", 1, 0, 2)]), pool([it("minecraft:chicken")]), pool([it("celestial_essence")], 0.2)])
loot("celestial_llama", [pool([it("minecraft:leather", 1, 0, 2)]), pool([it("minecraft:light_blue_carpet")], 0.4), pool([it("celestial_essence")], 0.4)])
loot("celestial_goat", [pool([it("minecraft:leather", 1, 0, 1)]), pool([it("minecraft:mutton", 1, 1, 2)]), pool([it("celestial_essence")], 0.4)])
loot("cloud_manta", [pool([it("minecraft:feather", 1, 1, 2)]), pool([it("solid_cloud", 1, 1, 3)]), pool([it("celestial_essence")], 0.5)])
loot("celestial_pegasus", [pool([it("minecraft:leather", 1, 1, 3)]), pool([it("minecraft:feather", 1, 2, 4)]), pool([it("celestial_essence", 1, 1, 2)], 0.6)])

# ---------- idiomas ----------
NEW = {
 "entity.celestial_pig": ("Cerdo Celestial", "Celestial Pig"), "entity.celestial_cow": ("Vaca Celestial", "Celestial Cow"),
 "entity.celestial_sheep": ("Oveja Celestial", "Celestial Sheep"), "entity.celestial_chicken": ("Gallina Celestial", "Celestial Chicken"),
 "entity.celestial_llama": ("Llama Celestial", "Celestial Llama"), "entity.celestial_goat": ("Cabra Celestial", "Celestial Goat"),
 "entity.cloud_manta": ("Manta de Nubes", "Cloud Manta"), "entity.celestial_pegasus": ("Pegaso Celeste", "Celestial Pegasus"),
 "block.celestial_sapling": ("Brote celestial", "Celestial Sapling"), "block.grass_tuft": ("Mata de hierba celestial", "Celestial Grass Tuft"),
 "block.glow_fern": ("Helecho luminoso", "Glow Fern"), "block.azure_bloom": ("Flor azur", "Azure Bloom"),
 "block.sun_lily": ("Lirio solar", "Sun Lily"), "block.aether_orchid": ("Orquídea de éter", "Aether Orchid"),
 "block.cloud_cotton": ("Algodón de nube", "Cloud Cotton"), "block.crystal_sprout": ("Brote de cristal", "Crystal Sprout"),
 "block.moon_tulip": ("Tulipán lunar", "Moon Tulip")}
for name in EGG:
    es_n = rj(f"{AS}/lang/es_es.json").get(f"entity.{NS}.{name}"); en_n = rj(f"{AS}/lang/en_us.json").get(f"entity.{NS}.{name}")
    if name in ("celestial_pig", "celestial_cow", "celestial_sheep", "celestial_chicken", "celestial_llama", "celestial_goat", "cloud_manta", "celestial_pegasus"):
        es_n, en_n = NEW[f"entity.{name}"]
    NEW[f"item.{name}_spawn_egg"] = (f"Huevo de aparición: {es_n}", f"{en_n} Spawn Egg")
for lang, idx in (("es_es", 0), ("en_us", 1)):
    p = f"{AS}/lang/{lang}.json"; d = rj(p)
    for k, v in NEW.items():
        pre, rest = k.split(".", 1); d[f"{pre}.{NS}.{rest}"] = v[idx]
    wj(p, d)

rd = open(f"{ROOT}/README.md").read()
open(f"{ROOT}/README.md", "w").write(rd + """
## Vegetacion y animales celestiales
- Plantas: brote celestial (crece solo o con polvo de hueso), mata de hierba, helecho luminoso, flor azur, lirio solar, orquidea de eter,
  algodon de nube, brote de cristal, tulipan lunar. Arboles: normal, pequeno, pino, sombrilla y gigante (todos de tronco y hojas celestiales).
- Animales pacificos: cerdo, vaca, oveja, gallina, llama y cabra celestiales, Manta de Nubes (voladora) y Pegaso Celeste (montura voladora).
  Se crian con comida natural del Overworld (zanahoria/patata/remolacha, trigo, semillas, heno, manzana).
- Huevos de aparicion para las 16 criaturas.
""")
print("stage6b ok")
