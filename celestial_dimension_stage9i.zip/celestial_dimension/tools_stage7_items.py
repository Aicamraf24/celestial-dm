import os, math, random, zlib, struct
ROOT = "/home/claude/cd/celestial_dimension"
IT = f"{ROOT}/src/main/resources/assets/celestial_dimension/textures/item"

def png(path, px):
    W = H = 16
    raw = b"".join(b"\x00" + b"".join(bytes(px[y][x] if px[y][x] else (0, 0, 0, 0)) for x in range(W)) for y in range(H))
    def ch(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    open(path, "wb").write(b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", W, H, 8, 6, 0, 0, 0))
                           + ch(b"IDAT", zlib.compress(raw, 9)) + ch(b"IEND", b""))
def cl(v): return max(0, min(255, int(round(v))))
def mul(c, k): return (cl(c[0] * k), cl(c[1] * k), cl(c[2] * k), 255)
def add(c, d): return (cl(c[0] + d), cl(c[1] + d), cl(c[2] + d), 255)
def mix(a, b, t): return (cl(a[0] + (b[0] - a[0]) * t), cl(a[1] + (b[1] - a[1]) * t), cl(a[2] + (b[2] - a[2]) * t), 255)
def ramp(base):  # 5 tonos: 0 sombra .. 4 brillo
    return [mul(base, 0.50), mul(base, 0.75), (*base[:3], 255), add(mul(base, 1.12), 22), add(mul(base, 1.2), 85)]

def canvas(): return [[None] * 16 for _ in range(16)]
def put(px, x, y, c):
    if 0 <= x < 16 and 0 <= y < 16: px[y][x] = c
def line(a, b):
    (x0, y0), (x1, y1) = a, b
    n = max(abs(x1 - x0), abs(y1 - y0), 1)
    return [(round(x0 + (x1 - x0) * k / n), round(y0 + (y1 - y0) * k / n)) for k in range(n + 1)]
def outline(px, strength=0.28):
    out = [[None] * 16 for _ in range(16)]
    for y in range(16):
        for x in range(16):
            if px[y][x] is None:
                best = None
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < 16 and 0 <= ny < 16 and px[ny][nx] is not None:
                        best = px[ny][nx]; break
                if best: out[y][x] = (cl(best[0] * strength), cl(best[1] * strength), cl(best[2] * strength + 8), 255)
    for y in range(16):
        for x in range(16):
            if out[y][x]: px[y][x] = out[y][x]
    return px
def sparkle(px, x, y, c=(255, 255, 255, 255)):
    put(px, x, y, c)
    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        if 0 <= x + dx < 16 and 0 <= y + dy < 16 and px[y + dy][x + dx] is None: put(px, x + dx, y + dy, (*c[:3], 255) if False else mix(c, (150, 200, 255), 0.6))

GOLD = ramp((235, 190, 60)); WOOD = ramp((140, 95, 55))

def handle(px, pts):
    for k, (x, y) in enumerate(pts): put(px, x, y, WOOD[2] if k % 2 else WOOD[1])
    put(px, pts[0][0], pts[0][1], WOOD[0])

def blade(px, R, p_tip, p_base, width=2):
    pts = line(p_tip, p_base)
    for k, (x, y) in enumerate(pts):
        put(px, x, y, R[3]); put(px, x + 1, y, R[1])
        if width == 3: put(px, x + 1, y, R[2]); put(px, x + 2, y, R[1])
        if k % 3 == 0: put(px, x, y, R[4])
    x, y = pts[0]; put(px, x, y, R[4]); put(px, x + 1, y, R[3])

def sword(base, long=True):
    px = canvas(); R = ramp(base)
    if long:
        blade(px, R, (14, 1), (6, 9)); gc = [(3, 6), (4, 7), (5, 8), (6, 9), (7, 10), (8, 11), (9, 12)] if False else line((4, 7), (8, 11))
        hand = line((5, 10), (2, 13)); pom = [(1, 14), (2, 14), (1, 13)]
    else:
        blade(px, R, (12, 3), (7, 8)); gc = line((5, 7), (9, 11)); hand = line((6, 9), (3, 12)); pom = [(2, 13), (2, 12)]
    for k, (x, y) in enumerate(gc): put(px, x, y, GOLD[3] if k % 2 else GOLD[2]); put(px, x, y + 1, GOLD[1])
    handle(px, hand)
    for (x, y) in pom: put(px, x, y, GOLD[2])
    return outline(px)

def pickaxe(base):
    px = canvas(); R = ramp(base)
    handle(px, line((2, 14), (10, 6)))
    arc = line((3, 7), (4, 5)) + line((4, 5), (6, 3)) + line((6, 3), (9, 2)) + line((9, 2), (12, 3)) + line((12, 3), (13, 6)) + line((13, 6), (13, 8))
    for (x, y) in arc: put(px, x, y, R[3]); put(px, x, y + 1, R[1]) if px[y + 1][x] is None else None
    for (x, y) in line((6, 3), (10, 2)): put(px, x, y, R[4])
    for (x, y) in ((8, 4), (9, 5), (10, 5), (9, 4)): put(px, x, y, GOLD[2])  # abrazadera
    return outline(px)

def axe(base):
    px = canvas(); R = ramp(base)
    handle(px, line((2, 14), (10, 5)))
    rows = {1: (9, 11), 2: (8, 13), 3: (8, 14), 4: (8, 14), 5: (9, 14), 6: (10, 13), 7: (10, 12)}
    for y, (a, b) in rows.items():
        for x in range(a, b + 1):
            put(px, x, y, R[4] if y == 1 or (x == a and y < 5) else (R[3] if x < b - 1 else (R[2] if x < b else R[1])))
    for x in range(13, 15): put(px, x, 3, R[4]); put(px, x, 4, R[4])
    for (x, y) in ((9, 5), (9, 4)): put(px, x, y, GOLD[2])
    return outline(px)

def shovel(base):
    px = canvas(); R = ramp(base)
    handle(px, line((2, 14), (10, 6)))
    rows = {1: (12, 13), 2: (11, 14), 3: (11, 14), 4: (11, 14), 5: (11, 14), 6: (12, 13)}
    for y, (a, b) in rows.items():
        for x in range(a, b + 1): put(px, x, y, R[4] if y == 1 or x == a else (R[1] if x == b else R[3] if y < 4 else R[2]))
    for (x, y) in ((10, 7), (11, 6)): put(px, x, y, GOLD[2])
    return outline(px)

def hoe(base):
    px = canvas(); R = ramp(base)
    handle(px, line((2, 14), (11, 5)))
    for x in range(6, 13): put(px, x, 2, R[4] if x < 9 else R[3]); put(px, x, 3, R[2] if x > 6 else R[3])
    put(px, 6, 4, R[2]); put(px, 6, 5, R[1]); put(px, 12, 4, R[1])
    for (x, y) in ((11, 5), (10, 4)): put(px, x, y, GOLD[2])
    return outline(px)

def bow(base):
    px = canvas(); R = ramp(base)
    limb = [(10, 1), (8, 2), (6, 3), (5, 5), (4, 7), (4, 9), (5, 11), (6, 13), (8, 14), (10, 14)]
    pts = []
    for a, b in zip(limb, limb[1:]): pts += line(a, b)
    for (x, y) in pts: put(px, x, y, R[3]); put(px, x + 1, y, R[1])
    for (x, y) in line((10, 1), (6, 3)): put(px, x, y, R[4])
    for (x, y) in line((10, 2), (10, 13)): put(px, x, y, (225, 235, 255, 255))
    for (x, y) in ((4, 7), (4, 8), (4, 9)): put(px, x, y, GOLD[2]); put(px, x + 1, y, GOLD[1])
    sparkle(px, 12, 3, (255, 255, 230, 255))
    return outline(px)

def armor(kind, base, gem):
    px = canvas(); R = ramp(base)
    spans = {
     "helmet": {3: [(5, 10)], 4: [(4, 11)], 5: [(3, 12)], 6: [(3, 12)], 7: [(3, 12)], 8: [(3, 5), (10, 12)], 9: [(3, 5), (10, 12)], 10: [(3, 4), (11, 12)]},
     "chest": {2: [(3, 5), (10, 12)], 3: [(2, 5), (7, 8) if False else (10, 13)], 4: [(2, 6), (9, 13)], 5: [(2, 13)], 6: [(2, 13)], 7: [(2, 13)], 8: [(2, 4), (5, 10), (11, 13)],
               9: [(2, 4), (5, 10), (11, 13)], 10: [(5, 10)], 11: [(5, 10)], 12: [(5, 10)], 13: [(5, 10)]},
     "legs": {2: [(4, 11)], 3: [(4, 11)], 4: [(4, 11)], 5: [(4, 11)], 6: [(4, 7), (8, 11)], 7: [(4, 7), (8, 11)], 8: [(4, 6), (9, 11)], 9: [(4, 6), (9, 11)],
              10: [(4, 6), (9, 11)], 11: [(4, 6), (9, 11)], 12: [(4, 6), (9, 11)], 13: [(3, 6), (9, 12)]},
     "boots": {6: [(3, 6), (9, 12)], 7: [(3, 6), (9, 12)], 8: [(3, 6), (9, 12)], 9: [(3, 6), (9, 12)], 10: [(2, 6), (9, 13)], 11: [(1, 6), (9, 14)], 12: [(1, 6), (9, 14)]}}[kind]
    top = min(spans); bot = max(spans)
    for y, sp in spans.items():
        for (a, b) in sp:
            for x in range(a, b + 1):
                if y == top or x == a: t = 4 if (y == top and x != b) else 3
                elif x == b or y == bot: t = 1
                else: t = 2
                if (x + y) % 5 == 0 and t == 2: t = 3
                put(px, x, y, R[t])
    trimy = {"helmet": [7], "chest": [11], "legs": [3], "boots": [6]}[kind]
    for y in trimy:
        for x in range(16):
            if px[y][x] is not None: put(px, x, y, GOLD[3] if x % 2 == 0 else GOLD[2])
    if kind == "legs":
        for (x, y) in ((5, 9), (10, 9)): put(px, x, y, GOLD[3])
    gx, gy = {"helmet": (7, 4), "chest": (7, 6), "legs": (7, 4), "boots": (4, 8)}[kind]
    gR = ramp(gem)
    put(px, gx, gy, gR[4]); put(px, gx + 1, gy, gR[3]); put(px, gx, gy + 1, gR[2]); put(px, gx + 1, gy + 1, gR[1])
    return outline(px)

# ---------- materiales ----------
def essence():
    px = canvas()
    for y in range(16):
        for x in range(16):
            d = math.hypot(x - 7.5, y - 7.5)
            if d < 4.6:
                t = d / 4.6
                c = mix((255, 252, 220), (255, 190, 70), min(1, t * t * 1.15))
                if x - 7.5 + y - 7.5 > 2.5: c = mul(c, 0.86)
                put(px, x, y, (*c[:3], 255))
    for (x, y) in ((6, 6), (7, 5)): put(px, x, y, (255, 255, 255, 255))
    outline(px, 0.34)
    for (x, y) in ((8, 1), (8, 14), (1, 8), (14, 8)): sparkle(px, x, y, (200, 245, 255, 255))
    return px
def aurora():
    px = canvas(); R = ramp((70, 210, 235))
    poly = {1: (7, 8), 2: (6, 9), 3: (5, 10), 4: (4, 11), 5: (4, 11), 6: (4, 11), 7: (4, 11), 8: (5, 10), 9: (5, 10), 10: (6, 9), 11: (6, 9), 12: (7, 8), 13: (7, 8)}
    for y, (a, b) in poly.items():
        for x in range(a, b + 1):
            if y <= 4: t = 3 if x <= 8 else 2
            else: t = 2 if x < 8 else 1
            if y >= 9: t = max(0, t - 1)
            put(px, x, y, R[t])
    for (x, y) in line((5, 5), (7, 3)): put(px, x, y, R[4])
    for y in range(5, 12): put(px, 7 + (0 if y < 9 else 0), y, mix(R[2], R[3], 0.5)) if False else None
    for (x, y) in ((6, 6), (6, 7)): put(px, x, y, R[4])
    outline(px, 0.30); sparkle(px, 13, 3, (230, 255, 255, 255)); put(px, 2, 12, (200, 245, 255, 255))
    return px
def ether():
    px = canvas(); R = ramp((165, 100, 245))
    for (x, y) in line((3, 13), (11, 3)):
        put(px, x, y, R[3]); put(px, x + 1, y, R[2]); put(px, x + 2, y, R[1])
    for (x, y) in line((5, 13), (13, 8)): put(px, x, y, R[3] if y < 11 else R[2]); put(px, x, y + 1, R[1])
    put(px, 11, 3, R[4]); put(px, 12, 3, R[3]); put(px, 12, 2, R[4])
    for (x, y) in ((5, 10), (6, 9), (7, 8)): put(px, x, y, R[4])
    outline(px, 0.30); sparkle(px, 14, 3, (240, 220, 255, 255)); put(px, 2, 8, (225, 200, 255, 255))
    return px
def ingot():
    px = canvas(); G = ramp((240, 190, 55))
    for y, (a, b) in {5: (6, 14), 6: (5, 13), 7: (4, 12)}.items():
        for x in range(a, b + 1): put(px, x, y, G[4] if y == 5 or x == a else G[3])
    for y in range(8, 12):
        for x in range(4, 13): put(px, x, y, G[2] if y < 11 else G[1])
    for y, xs in {6: (14, 14), 7: (13, 13), 8: (13, 13), 9: (13, 13), 10: (13, 13)}.items(): put(px, xs[0], y, G[1])
    for y in range(8, 11): put(px, 13, y, G[0])
    for x in range(4, 13): put(px, x, 8, G[3])
    V = ramp((180, 110, 255)); put(px, 7, 9, V[4]); put(px, 8, 9, V[3]); put(px, 7, 10, V[2]); put(px, 8, 10, V[1])
    outline(px, 0.30); sparkle(px, 13, 3, (255, 255, 220, 255))
    return px
def solar():
    px = canvas(); O = ramp((255, 150, 40))
    for y in range(16):
        for x in range(16):
            d = abs(x - 7.5) + abs(y - 7.5) * 0.9
            if d < 5.8:
                t = d / 5.8; c = mix((255, 245, 170), (240, 110, 30), t ** 1.2)
                if (x - y) > 1.5 and t > 0.5: c = mul(c, 0.82)
                put(px, x, y, (*c[:3], 255))
    for (x, y) in ((7, 7), (8, 7), (7, 8)): put(px, x, y, (255, 255, 235, 255))
    outline(px, 0.34)
    for (x, y) in ((8, 0), (8, 14), (0, 8), (14, 8), (2, 2), (13, 2), (2, 13), (13, 13)): put(px, x, y, (255, 205, 80, 255))
    return px
def scale():
    px = canvas(); B = ramp((70, 130, 225))
    rows = {2: (6, 9), 3: (4, 11), 4: (3, 12), 5: (2, 13), 6: (2, 13), 7: (2, 13), 8: (2, 13), 9: (3, 12), 10: (4, 11), 11: (5, 10), 12: (6, 9), 13: (7, 8)}
    for y, (a, b) in rows.items():
        for x in range(a, b + 1):
            t = 3 if (y == min(rows) or x == a) else (1 if (x == b or y >= 12) else 2)
            put(px, x, y, B[t])
    for (x, y) in line((4, 5), (8, 9)) + line((8, 9), (11, 5)): put(px, x, y, B[1])
    for (x, y) in line((8, 9), (8, 12)): put(px, x, y, B[1])
    for (x, y) in ((5, 4), (6, 3), (7, 3), (5, 6)): put(px, x, y, B[4])
    for (x, y) in line((3, 7), (4, 7)): put(px, x, y, GOLD[3])
    return outline(px, 0.28)
def heart():
    px = canvas(); H = ramp((215, 40, 95))
    rows = {3: [(3, 6), (9, 12)], 4: [(2, 7), (8, 13)], 5: [(2, 13)], 6: [(2, 13)], 7: [(3, 12)], 8: [(4, 11)], 9: [(5, 10)], 10: [(6, 9)], 11: [(7, 8)]}
    for y, sp in rows.items():
        for a, b in sp:
            for x in range(a, b + 1):
                t = 3 if (y <= 4 and x < 8) else (2 if y <= 7 else 1)
                if x >= 10 and y > 5: t = max(0, t - 1)
                put(px, x, y, H[t])
    for (x, y) in ((3, 4), (4, 4), (3, 5), (4, 3)): put(px, x, y, H[4])
    for (x, y) in line((8, 4), (8, 9)): put(px, x, y, H[0])
    for (x, y) in line((6, 8), (9, 11)) + line((6, 6), (6, 7)): put(px, x, y, GOLD[2])
    return outline(px, 0.30)
def egg(a, b, seed):
    px = canvas(); r = random.Random(seed)
    spans = {2: (7, 8), 3: (6, 9), 4: (5, 10), 5: (4, 11), 6: (4, 11), 7: (3, 12), 8: (3, 12), 9: (3, 12), 10: (4, 11), 11: (4, 11), 12: (5, 10), 13: (6, 9)}
    A = ramp(a)
    for y, (x0, x1) in spans.items():
        for x in range(x0, x1 + 1):
            t = 3 if (x - x0 < 3 and y < 8) else (1 if (x1 - x < 2 or y > 11) else 2)
            put(px, x, y, A[t])
    B = ramp(b)
    for _ in range(8):
        y = r.randint(4, 12); x0, x1 = spans[y]; x = r.randint(x0 + 1, x1 - 2)
        for dx, dy in ((0, 0), (1, 0), (0, 1)):
            if px[y + dy][x + dx] is not None: put(px, x + dx, y + dy, B[2 if dy == 0 else 1])
    for (x, y) in ((5, 5), (6, 4), (5, 6)): put(px, x, y, add(A[4], 20))
    return outline(px, 0.30)

AUR = (70, 205, 232); DIV = (245, 195, 65)
SET = {
 "celestial_sword": sword(AUR), "ether_dagger": sword((170, 105, 245), long=False), "celestial_pickaxe": pickaxe(AUR),
 "celestial_axe": axe(AUR), "celestial_shovel": shovel(AUR), "celestial_hoe": hoe(AUR), "light_bow": bow((250, 225, 120)),
 "celestial_essence": essence(), "aurora_crystal": aurora(), "ether_shard": ether(), "divine_ingot": ingot(), "solar_fragment": solar(),
 "dragon_scale": scale(), "dragon_heart": heart()}
for k, nm in (("helmet", "helmet"), ("chest", "chestplate"), ("legs", "leggings"), ("boots", "boots")):
    SET[f"aurora_{nm}"] = armor(k, AUR, (255, 245, 170))
    SET[f"divine_{nm}"] = armor(k, DIV, (175, 105, 255))
EGG = {"guardian_angel": ((240, 240, 255), (255, 215, 90)), "celestial_griffin": ((205, 160, 90), (245, 245, 250)),
 "celestial_dragon": ((60, 105, 200), (255, 215, 90)), "cloud_spirit": ((240, 246, 255), (110, 170, 245)),
 "crystal_golem": ((135, 148, 185), (110, 225, 255)), "celestial_harpy": ((150, 120, 190), (255, 150, 200)),
 "luminous_deer": ((235, 225, 200), (120, 235, 235)), "sky_serpent": ((60, 190, 160), (160, 110, 230)),
 "celestial_pig": ((140, 195, 240), (255, 200, 220)), "celestial_cow": ((235, 245, 255), (95, 150, 220)),
 "celestial_sheep": ((232, 244, 255), (255, 215, 120)), "celestial_chicken": ((240, 248, 255), (90, 200, 250)),
 "celestial_llama": ((238, 236, 225), (150, 120, 230)), "celestial_goat": ((232, 242, 255), (235, 200, 110)),
 "cloud_manta": ((120, 180, 245), (235, 245, 255)), "celestial_pegasus": ((240, 246, 255), (255, 215, 90))}
for n, (a, b) in EGG.items(): SET[f"{n}_spawn_egg"] = egg(a, b, sum(map(ord, n)))
for n, px in SET.items(): png(f"{IT}/{n}.png", px)
print(len(SET), "iconos")
